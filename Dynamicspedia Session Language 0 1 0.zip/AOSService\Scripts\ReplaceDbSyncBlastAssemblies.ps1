PARAM (
    [Parameter(Mandatory=$true)]
    $log,
    [Parameter(Mandatory=$true)]
    [ValidateScript({Test-Path $_})]
    $webroot,
    [Parameter(Mandatory=$true)]
    [ValidateScript({Test-Path $_})]
    $packageDirectory
)

$ErrorActionPreference = 'Stop'

Import-Module "$PSScriptRoot\AosCommon.psm1" -Force -DisableNameChecking
Import-Module "$PSScriptRoot\AosEnvironmentUtilities.psm1" -Force -DisableNameChecking

$WebConfigPath = "$webroot\web.config"
$DbSyncBlastFolder = "$PSScriptRoot\DbSyncBlast"
$DbSyncVersionTestFile = "Microsoft.Dynamics.AX.Data.Management.Sync.dll"

Initialize-Log $log

function Replace-Files([string] $sourceFolder, [string[]] $sourceFiles, [string[]] $destinationFolders, [string] $backupFolderName, [hashtable] $backedUpFiles)
{
    $useBackup = (-not [String]::IsNullOrWhiteSpace($backupFolderName))

    foreach ($directory in $destinationFolders)
    {
        if ($useBackup)
        {
            $backupFolder = Join-Path $directory $backupFolderName

            if (-not (Test-Path $backupFolder))
            {
                Write-Log "Creating folder '$backupFolder'"
                New-Item -ItemType Directory -Path $backupFolder
            }
        }

        foreach ($file in $sourceFiles)
        {
            $sourcePath = Join-Path $sourceFolder $file
            $targetPath = Join-Path $directory $file

            if ($useBackup)
            {
                if (Test-Path $targetPath)
                {
                    $backupPath = Join-Path $backupFolder "$file.bak"

                    Write-Log "Copying file from: '$sourcePath' to '$targetPath', backing up target to '$backupPath'"

                    Copy-Item -Path $targetPath -Destination $backupPath -Force
                    $backedUpFiles[$targetPath] = $backupPath
                }
                else
                {
                    Write-Log "Copying file from: '$sourcePath' to '$targetPath'. Target file does not exist, skipping backup."

                    # Empty value means the file is new - delete/rename when restoring backup
                    $backedUpFiles[$targetPath] = ""
                }
            }
            else
            {
                Write-Log "Copying file from: '$sourcePath' to '$targetPath'. No backup folder specified, skipping backup."
            }

            Copy-Item -Path $sourcePath -Destination $targetPath -Force
                                
            Write-Log "Copy file succeeded."
        }
    }
}

function Restore-Backup([hashtable] $backedUpFiles)
{
    foreach ($file in $backedUpFiles.GetEnumerator())
    {
        try
        {
            if (-not [String]::IsNullOrWhiteSpace($file.Value))
            {
                Write-Log "Restoring backup from '$($file.Value)' to '$($file.Key)'"

                Copy-Item -Path $file.Value -Destination $file.Key -Force
                
                Write-Log "Restored successfully."
            }
            else
            {
                $renameTo = "$($file.Key).dbsyncblast_failed"

                Write-Log "Restoring backup for '$($file.Key)', which is newly created - renaming to '$renameTo' instead of deleting."

                Rename-Item -Path $file.Key -NewName $renameTo

                Write-Log "Renamed successfully."
            }
        }
        catch
        {
            Write-Exception $_
            Write-Log "Failed to restore backup for '$($file.Key)'"
        }
    }
}

function Test-RequiredPaths
{
    foreach ($path in $args)
    {
        if (-not (Test-Path $path))
        {
            Write-Log "Path '$path' not found, skipping DbSyncBlast."
            return $false
        }
    }

    return $true
}

function Get-FileVersion([string] $file)
{
    $fileInfo = Get-ChildItem -File $file

    if ($fileInfo -eq $null -or $fileInfo.VersionInfo -eq $null)
    {
        Write-Log "Could not get version info for '$fileInfo', skipping DbSyncBlast."
        return $null
    }

    return $fileInfo.VersionInfo
}

filter VersionsToDictionary
{
    begin { $dict = @{} }
    process { $dict[[int]($_.Split('.')[-1])] = $_ } # e.g. 7.0.30100.4970 --> $dict[4970] = 7.0.30100.4970
    end { return $dict }
}

$DbSyncBlastMinPlatformVersion = 5030 #PU20
$script:PlatformBuildVersion = 0
function Get-DbSyncApplicableVersionPath
{
    if (-not (Test-RequiredPaths $DbSyncBlastFolder))
    {
        return $null
    }
    
    # Default to no replace
    $dbSyncApplicableVersionPath = $null
            
    $platformVersionInfo = Get-ProductPlatformBuildFullVersion

    if ($platformVersionInfo -ne $null)
    {
        Write-Log "Current platform build: $platformVersionInfo"

        $dbSyncVersions = Get-ChildItem -Path $DbSyncBlastFolder -Directory -Name | VersionsToDictionary
        Write-Log "Found DbSyncBlast builds for platform builds >= $($dbSyncVersions.Keys -join ', ')."
        $invalidDbSyncBlastVersions = $dbSyncVersions.GetEnumerator() | ?{$_.Key -lt $DbSyncBlastMinPlatformVersion}
        if ($invalidDbSyncBlastVersions.Count -gt 0)
        {
            Write-Log "Skipping invalid DbSyncBlast builds: $($invalidDbSyncBlastVersions.Values -join ', '). Minimum supported platform build is $DbSyncBlastMinPlatformVersion."

            $dbSyncVersions = $dbSyncVersions.GetEnumerator() | ?{$_.Key -ge $DbSyncBlastMinPlatformVersion}
        }
        
        $script:PlatformBuildVersion = $platformVersionInfo.Build
        $useDbSyncPlatformVersion = [int](($dbSyncVersions.Keys | ?{$_ -le $script:PlatformBuildVersion} | measure -Max).Maximum)
        if ($useDbSyncPlatformVersion -ne 0)
        {
            Write-Log "Using DbSyncBlast build $($dbSyncVersions[$useDbSyncPlatformVersion])"
            $dbSyncApplicableVersionPath = Join-Path $DbSyncBlastFolder $dbSyncVersions[$useDbSyncPlatformVersion]
        }
        else
        {
            Write-Log "No applicable version found, skipping DbSyncBlast."
        }
    }
    
    return $dbSyncApplicableVersionPath
}

$EnsureMajorVersion = 7
$EnsureMinorVersion = 0
function Assert-IsNewerVersion([string] $newFile, [string] $oldFile)
{
    if (-not (Test-RequiredPaths $newFile $oldFile))
    {
        return $false
    }

    $newFileVersionInfo = Get-FileVersion -File $newFile
    $oldFileVersionInfo = Get-FileVersion -File $oldFile

    if ($newFileVersionInfo -eq $null -or $oldFileVersionInfo -eq $null)
    {
        return $false
    }

    Write-Log "Version of '$oldFile': $($oldFileVersionInfo.FileVersion)"
    Write-Log "Version of '$newFile': $($newFileVersionInfo.FileVersion)"

    if ($newFileVersionInfo.FileMajorPart -ne $EnsureMajorVersion -or $oldFileVersionInfo.FileMajorPart -ne $EnsureMajorVersion `
    -or $newFileVersionInfo.FileMinorPart -ne $EnsureMinorVersion -or $oldFileVersionInfo.FileMinorPart -ne $EnsureMinorVersion)
    {
        # If e.g. major version is changed from 7 to 10, we need to decide what to do. Skipping for now.
        Write-Log "Unexpected major or minor version, expected $EnsureMajorVersion.$EnsureMinorVersion.x.y. Skipping DbSyncBlast."
        return $false
    }

    $versionDiff = $newFileVersionInfo.FileBuildPart - $oldFileVersionInfo.FileBuildPart

    if ($versionDiff -lt 0)
    {
        Write-Log "Selected DbSyncBlast build version is lower than what is installed, skipping DbSyncBlast."
        return $false
    }

    if ($versionDiff -eq 0)
    {
        Write-Log "Selected DbSyncBlast build already installed, skipping DbSyncBlast."
        return $false
    }

    return $true
}

function Update-WebConfig
{
    # Update the Monitoring.ETWManifests key, adding Microsoft.Dynamics.ApplicationPlatform.DatabaseSynchronize.man if it does not exist in the list
    $key = "Monitoring.ETWManifests"
    $manFileName = "Microsoft.Dynamics.ApplicationPlatform.DatabaseSynchronize.man"

    # Check for PU20-21
    if ($script:PlatformBuildVersion -ge 5030 -and $script:PlatformBuildVersion -le 5073) {

        [System.Xml.XmlDocument] $xmlDoc = new-object System.Xml.XmlDocument
        $xmlDoc.Load($WebConfigPath)
        $node = $xmlDoc.SelectSingleNode("//add[@key='$key']")
        $oldValueSplit = $node.Value -split ";"

        if ($oldValueSplit -notcontains $manFileName)
        {
            Write-Log "Updating $key, adding $manFileName"
            $node.Value += ";$manFileName"
            $xmlDoc.Save($WebConfigPath)
        }
        else
        {
            Write-Log "Not updating $key, $manFileName already exists."
        }
    }
    else
    {
        Write-Log "Not updating $key, platform is not PU20 or PU21."
    }
}

try
{
    Write-Log "DbSyncBlast assembly replacement check: Start"

    $error.Clear()

    if (-not (Get-IsFlightEnabled "DbSyncBlastDisabled"))
    {
        $dbSyncApplicableVersionPath = Get-DbSyncApplicableVersionPath

        if ($dbSyncApplicableVersionPath -ne $null)
        {
            if (Assert-IsNewerVersion "$dbSyncApplicableVersionPath\$DbSyncVersionTestFile" "$webroot\bin\$DbSyncVersionTestFile")
            {
                # The list of assemblies to be replaced.
                # Microsoft.Dynamics.ApplicationPlatform.DatabaseSynchronize.Instrumentation.dll should be included in both lists.
                $sourceFiles = Get-ChildItem -Path $dbSyncApplicableVersionPath -File -Name
                $sourceFilesNoMan = $sourceFiles | ?{-not $_.EndsWith(".man")}
                $sourceFilesMan   = $sourceFiles | ?{     $_.EndsWith(".man") -or $_.EndsWith(".Instrumentation.dll")}

                Write-Log "Non-instrumentation files to blast: $sourceFilesNoMan"
                Write-Log "Instrumentation files to blast: $sourceFilesMan"

                # Build a destination directory list
                $ETWManifestPath = "$(Split-Path -parent $PSScriptRoot)\ETWManifest"
                if (-not (Test-Path $ETWManifestPath))
                {
                    Write-Log "Creating folder '$ETWManifestPath'"
                    New-Item -ItemType Directory -Path $ETWManifestPath
                }
                $copyNoManToDirectories = @(
                    "$webroot\bin",
                    "$packageDirectory\ApplicationPlatform\bin",
                    "$packageDirectory\bin")
                $copyManToDirectories = @(
                    "$webroot\Monitoring",
                    "$webroot\bin\Monitoring",
                    "$packageDirectory\Plugins\Monitoring",
                    "$ETWManifestPath\")

                Write-Log "Blasting non-instrumentation files to these locations: $copyNoManToDirectories"
                Write-Log "Blasting instrumentation files to these locations: $copyManToDirectories"

                # Backup to Original the first time, then to Last on subsequent runs
                $originalBackupFolder = "DbSyncOriginalBackup"
                $lastBackupFolder = "DbSyncLastBackup"
                Write-Log "Default backup folder is $originalBackupFolder"
                $backupFolder = $originalBackupFolder
                foreach ($directory in $copyNoManToDirectories)
                {
                    $originalBackupPath = Join-Path $directory $originalBackupFolder
                    if (Test-Path $originalBackupPath)
                    {
                        Write-Log "Found '$originalBackupPath', changing backup folder to $lastBackupFolder"
                        $backupFolder = $lastBackupFolder
                        break
                    }
                }
                
                $backedUpFiles = @{}
                try
                {
                    Replace-Files $dbSyncApplicableVersionPath $sourceFilesNoMan $copyNoManToDirectories $backupFolder $backedUpFiles
                    Replace-Files $dbSyncApplicableVersionPath $sourceFilesMan   $copyManToDirectories
                }
                catch
                {
                    # We do not want to leave mixed versions in case blast fails, so we do our best to return to the original state.
                    # However, this should not happen as we normally blast to a staging folder. Instead, the backed up files should
                    # be used if DbSync itself fails because of a regression.
                    Write-Exception $_
                    Restore-Backup $backedUpFiles
                    throw
                }

                Update-WebConfig

                Write-Log "DbSyncBlast assembly replacement succeeded."
            }
        }
    }
    else 
    {
       Write-Log "Skipping DbSyncBlast because of DbSyncBlastDisabled flight."
    } 
}
catch
{
    # Write the exception and that this process failed.  
    # Do not throw as this should not cause the deployment or update to fail.
    Write-Exception $_
    Write-Log "DbSyncBlast assembly replacement failed, see $log for details."
}
finally
{
    Write-Log "DbSyncBlast assembly replacement check: Stop"
}

# SIG # Begin signature block
# MIIjswYJKoZIhvcNAQcCoIIjpDCCI6ACAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCA9lsBXtv4PSpQ8
# U3CeeKm0RJfsYRAgHAy25FBy3TGUAqCCDYUwggYDMIID66ADAgECAhMzAAABUptA
# n1BWmXWIAAAAAAFSMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMTkwNTAyMjEzNzQ2WhcNMjAwNTAyMjEzNzQ2WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQCxp4nT9qfu9O10iJyewYXHlN+WEh79Noor9nhM6enUNbCbhX9vS+8c/3eIVazS
# YnVBTqLzW7xWN1bCcItDbsEzKEE2BswSun7J9xCaLwcGHKFr+qWUlz7hh9RcmjYS
# kOGNybOfrgj3sm0DStoK8ljwEyUVeRfMHx9E/7Ca/OEq2cXBT3L0fVnlEkfal310
# EFCLDo2BrE35NGRjG+/nnZiqKqEh5lWNk33JV8/I0fIcUKrLEmUGrv0CgC7w2cjm
# bBhBIJ+0KzSnSWingXol/3iUdBBy4QQNH767kYGunJeY08RjHMIgjJCdAoEM+2mX
# v1phaV7j+M3dNzZ/cdsz3oDfAgMBAAGjggGCMIIBfjAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQU3f8Aw1sW72WcJ2bo/QSYGzVrRYcw
# VAYDVR0RBE0wS6RJMEcxLTArBgNVBAsTJE1pY3Jvc29mdCBJcmVsYW5kIE9wZXJh
# dGlvbnMgTGltaXRlZDEWMBQGA1UEBRMNMjMwMDEyKzQ1NDEzNjAfBgNVHSMEGDAW
# gBRIbmTlUAXTgqoXNzcitW2oynUClTBUBgNVHR8ETTBLMEmgR6BFhkNodHRwOi8v
# d3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NybC9NaWNDb2RTaWdQQ0EyMDExXzIw
# MTEtMDctMDguY3JsMGEGCCsGAQUFBwEBBFUwUzBRBggrBgEFBQcwAoZFaHR0cDov
# L3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9jZXJ0cy9NaWNDb2RTaWdQQ0EyMDEx
# XzIwMTEtMDctMDguY3J0MAwGA1UdEwEB/wQCMAAwDQYJKoZIhvcNAQELBQADggIB
# AJTwROaHvogXgixWjyjvLfiRgqI2QK8GoG23eqAgNjX7V/WdUWBbs0aIC3k49cd0
# zdq+JJImixcX6UOTpz2LZPFSh23l0/Mo35wG7JXUxgO0U+5drbQht5xoMl1n7/TQ
# 4iKcmAYSAPxTq5lFnoV2+fAeljVA7O43szjs7LR09D0wFHwzZco/iE8Hlakl23ZT
# 7FnB5AfU2hwfv87y3q3a5qFiugSykILpK0/vqnlEVB0KAdQVzYULQ/U4eFEjnis3
# Js9UrAvtIhIs26445Rj3UP6U4GgOjgQonlRA+mDlsh78wFSGbASIvK+fkONUhvj8
# B8ZHNn4TFfnct+a0ZueY4f6aRPxr8beNSUKn7QW/FQmn422bE7KfnqWncsH7vbNh
# G929prVHPsaa7J22i9wyHj7m0oATXJ+YjfyoEAtd5/NyIYaE4Uu0j1EhuYUo5VaJ
# JnMaTER0qX8+/YZRWrFN/heps41XNVjiAawpbAa0fUa3R9RNBjPiBnM0gvNPorM4
# dsV2VJ8GluIQOrJlOvuCrOYDGirGnadOmQ21wPBoGFCWpK56PxzliKsy5NNmAXcE
# x7Qb9vUjY1WlYtrdwOXTpxN4slzIht69BaZlLIjLVWwqIfuNrhHKNDM9K+v7vgrI
# bf7l5/665g0gjQCDCN6Q5sxuttTAEKtJeS/pkpI+DbZ/MIIHejCCBWKgAwIBAgIK
# YQ6Q0gAAAAAAAzANBgkqhkiG9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNV
# BAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jv
# c29mdCBDb3Jwb3JhdGlvbjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlm
# aWNhdGUgQXV0aG9yaXR5IDIwMTEwHhcNMTEwNzA4MjA1OTA5WhcNMjYwNzA4MjEw
# OTA5WjB+MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UE
# BxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSgwJgYD
# VQQDEx9NaWNyb3NvZnQgQ29kZSBTaWduaW5nIFBDQSAyMDExMIICIjANBgkqhkiG
# 9w0BAQEFAAOCAg8AMIICCgKCAgEAq/D6chAcLq3YbqqCEE00uvK2WCGfQhsqa+la
# UKq4BjgaBEm6f8MMHt03a8YS2AvwOMKZBrDIOdUBFDFC04kNeWSHfpRgJGyvnkmc
# 6Whe0t+bU7IKLMOv2akrrnoJr9eWWcpgGgXpZnboMlImEi/nqwhQz7NEt13YxC4D
# dato88tt8zpcoRb0RrrgOGSsbmQ1eKagYw8t00CT+OPeBw3VXHmlSSnnDb6gE3e+
# lD3v++MrWhAfTVYoonpy4BI6t0le2O3tQ5GD2Xuye4Yb2T6xjF3oiU+EGvKhL1nk
# kDstrjNYxbc+/jLTswM9sbKvkjh+0p2ALPVOVpEhNSXDOW5kf1O6nA+tGSOEy/S6
# A4aN91/w0FK/jJSHvMAhdCVfGCi2zCcoOCWYOUo2z3yxkq4cI6epZuxhH2rhKEmd
# X4jiJV3TIUs+UsS1Vz8kA/DRelsv1SPjcF0PUUZ3s/gA4bysAoJf28AVs70b1FVL
# 5zmhD+kjSbwYuER8ReTBw3J64HLnJN+/RpnF78IcV9uDjexNSTCnq47f7Fufr/zd
# sGbiwZeBe+3W7UvnSSmnEyimp31ngOaKYnhfsi+E11ecXL93KCjx7W3DKI8sj0A3
# T8HhhUSJxAlMxdSlQy90lfdu+HggWCwTXWCVmj5PM4TasIgX3p5O9JawvEagbJjS
# 4NaIjAsCAwEAAaOCAe0wggHpMBAGCSsGAQQBgjcVAQQDAgEAMB0GA1UdDgQWBBRI
# bmTlUAXTgqoXNzcitW2oynUClTAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTAL
# BgNVHQ8EBAMCAYYwDwYDVR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBRyLToCMZBD
# uRQFTuHqp8cx0SOJNDBaBgNVHR8EUzBRME+gTaBLhklodHRwOi8vY3JsLm1pY3Jv
# c29mdC5jb20vcGtpL2NybC9wcm9kdWN0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFf
# MDNfMjIuY3JsMF4GCCsGAQUFBwEBBFIwUDBOBggrBgEFBQcwAoZCaHR0cDovL3d3
# dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFf
# MDNfMjIuY3J0MIGfBgNVHSAEgZcwgZQwgZEGCSsGAQQBgjcuAzCBgzA/BggrBgEF
# BQcCARYzaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9kb2NzL3ByaW1h
# cnljcHMuaHRtMEAGCCsGAQUFBwICMDQeMiAdAEwAZQBnAGEAbABfAHAAbwBsAGkA
# YwB5AF8AcwB0AGEAdABlAG0AZQBuAHQALiAdMA0GCSqGSIb3DQEBCwUAA4ICAQBn
# 8oalmOBUeRou09h0ZyKbC5YR4WOSmUKWfdJ5DJDBZV8uLD74w3LRbYP+vj/oCso7
# v0epo/Np22O/IjWll11lhJB9i0ZQVdgMknzSGksc8zxCi1LQsP1r4z4HLimb5j0b
# pdS1HXeUOeLpZMlEPXh6I/MTfaaQdION9MsmAkYqwooQu6SpBQyb7Wj6aC6VoCo/
# KmtYSWMfCWluWpiW5IP0wI/zRive/DvQvTXvbiWu5a8n7dDd8w6vmSiXmE0OPQvy
# CInWH8MyGOLwxS3OW560STkKxgrCxq2u5bLZ2xWIUUVYODJxJxp/sfQn+N4sOiBp
# mLJZiWhub6e3dMNABQamASooPoI/E01mC8CzTfXhj38cbxV9Rad25UAqZaPDXVJi
# hsMdYzaXht/a8/jyFqGaJ+HNpZfQ7l1jQeNbB5yHPgZ3BtEGsXUfFL5hYbXw3MYb
# BL7fQccOKO7eZS/sl/ahXJbYANahRr1Z85elCUtIEJmAH9AAKcWxm6U/RXceNcbS
# oqKfenoi+kiVH6v7RyOA9Z74v2u3S5fi63V4GuzqN5l5GEv/1rMjaHXmr/r8i+sL
# gOppO6/8MO0ETI7f33VtY5E90Z1WTk+/gFcioXgRMiF670EKsT/7qMykXcGhiJtX
# cVZOSEXAQsmbdlsKgEhr/Xmfwb1tbWrJUnMTDXpQzTGCFYQwghWAAgEBMIGVMH4x
# CzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRt
# b25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01p
# Y3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTECEzMAAAFSm0CfUFaZdYgAAAAA
# AVIwDQYJYIZIAWUDBAIBBQCggdowGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQw
# HAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIJV6
# 8Qo4Tp0k/zDHAeUoglJNyQ4jMbn4KHAQ6QxSVI5dMG4GCisGAQQBgjcCAQwxYDBe
# oECAPgBBAHUAdABvAFUAcABnAHIAYQBkAGUAQwBvAG4AZgBpAGcAQQBvAHMAUwBl
# AHIAdgBpAGMAZQAuAHAAcwAxoRqAGGh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbTAN
# BgkqhkiG9w0BAQEFAASCAQBQjzZQrvhwZIl59QAkSHLGRkL5MyqPQijAR4zSnd3o
# e2bkSmTk/Myf3eg9qkGRY4dh1jL/EjhhKGVS+6zFZ0YzYnQEcoyfrnz06oU4h5FN
# 6oopgVJhOhfZbuzFjDZ5KE+VAIyiWaSYH/NQEBpmQk6qDBi3S7rvZe8p4IJXc1n2
# ZDHpTW336T8aeu5tWDbHx/y+fnVmewfgiuE+VnxDh0MfcZUgiLX83qgTGpZFdzsN
# BqhKTyYDynZ1+wFIzQEkKqENMSw7lZ8oGc+4ChFNX9DGtCx8G/H+7iB2nr6dK4/Z
# uKdCtvNImv4B+R7MlnSn5zZXuKmYtcoxJO+/Nu7fQfM9oYIS4jCCEt4GCisGAQQB
# gjcDAwExghLOMIISygYJKoZIhvcNAQcCoIISuzCCErcCAQMxDzANBglghkgBZQME
# AgEFADCCAVEGCyqGSIb3DQEJEAEEoIIBQASCATwwggE4AgEBBgorBgEEAYRZCgMB
# MDEwDQYJYIZIAWUDBAIBBQAEIBvNYjQ/hCr4cIjqJb9LY9AGbELimpq5JeIyEuHo
# 6RBmAgZdwsFjNhsYEzIwMTkxMjAzMDMyMzQ3LjA2N1owBIACAfSggdCkgc0wgcox
# CzAJBgNVBAYTAlVTMQswCQYDVQQIEwJXQTEQMA4GA1UEBxMHUmVkbW9uZDEeMBwG
# A1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMS0wKwYDVQQLEyRNaWNyb3NvZnQg
# SXJlbGFuZCBPcGVyYXRpb25zIExpbWl0ZWQxJjAkBgNVBAsTHVRoYWxlcyBUU1Mg
# RVNOOkZGMDYtNEJDMy1COURBMSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFt
# cCBTZXJ2aWNloIIOOTCCBPEwggPZoAMCAQICEzMAAAEUNSdF6rbIbE8AAAAAARQw
# DQYJKoZIhvcNAQELBQAwfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0
# b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3Jh
# dGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwHhcN
# MTkxMDIzMjMxOTM3WhcNMjEwMTIxMjMxOTM3WjCByjELMAkGA1UEBhMCVVMxCzAJ
# BgNVBAgTAldBMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQg
# Q29ycG9yYXRpb24xLTArBgNVBAsTJE1pY3Jvc29mdCBJcmVsYW5kIE9wZXJhdGlv
# bnMgTGltaXRlZDEmMCQGA1UECxMdVGhhbGVzIFRTUyBFU046RkYwNi00QkMzLUI5
# REExJTAjBgNVBAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZpY2UwggEiMA0G
# CSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCdvi0k88S1dkCr0Rb9Vgwts1CaVvWj
# i4j8Z6oJteo97xmiVPQbsXEbI7B8SEULpdsTxnLpWlk0lfGayBLb6mqwYyqS+e1i
# Skkl6pOdFuh00sfjHmOGhKhww2Tyx4NpoHBnAc/qbL4YATCnVrywYDOzs27m67Mv
# lKLiL9KHovfG1r7FHzyp1tbKQhctJWk8QEwSPUZGZt5MDTpd1Dh1z5zVQ2gz2A5I
# TBvVMWOoNY3L6co/9NVg4FoGrU9CT45rbX8d2x+DRXLSluVNn5CYse/fEhRVrZO6
# UiMKYMfTFsNWk5gf/0Bfr5IMCpfKdAltdzcMjqG2+OfDwURGNJmbfIz/AgMBAAGj
# ggEbMIIBFzAdBgNVHQ4EFgQUUFSPcOb+hJN3LEanWWXcI4uJPAIwHwYDVR0jBBgw
# FoAU1WM6XIoxkPNDe3xGG8UzaFqFbVUwVgYDVR0fBE8wTTBLoEmgR4ZFaHR0cDov
# L2NybC5taWNyb3NvZnQuY29tL3BraS9jcmwvcHJvZHVjdHMvTWljVGltU3RhUENB
# XzIwMTAtMDctMDEuY3JsMFoGCCsGAQUFBwEBBE4wTDBKBggrBgEFBQcwAoY+aHR0
# cDovL3d3dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0cy9NaWNUaW1TdGFQQ0FfMjAx
# MC0wNy0wMS5jcnQwDAYDVR0TAQH/BAIwADATBgNVHSUEDDAKBggrBgEFBQcDCDAN
# BgkqhkiG9w0BAQsFAAOCAQEAGSKMNfc4B8frM9Abi+4YqtynPH8Q8GppZluhR0AH
# 3mPEUPfiKWGM4nxWqr9VgJIFmgCh5hm/ssthGNHpnwVDWHe387yhXMIFFafhZJqf
# FnOk02md5bK6sNVQTdgq1pW/E7lEIaWFTE+O8WkNYg+hZEunA5G+zfam+dO1gE0g
# eM303kGkS5PsbGRdnhqxddE+0S/+qhgC6d2Nvu0NYU3zc9WF5wp7esRcYCCJz+OD
# TrPecbLtawY0u7EwelI+eUx76jFg8+Er7x+USdAPDhHeGLItI0nDf9zyxFrzvChq
# aNnbbHFK8kkCqVZb+570CBJTP6HPUblA/QN8rqhnplTnGjCCBnEwggRZoAMCAQIC
# CmEJgSoAAAAAAAIwDQYJKoZIhvcNAQELBQAwgYgxCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xMjAwBgNVBAMTKU1pY3Jvc29mdCBSb290IENlcnRp
# ZmljYXRlIEF1dGhvcml0eSAyMDEwMB4XDTEwMDcwMTIxMzY1NVoXDTI1MDcwMTIx
# NDY1NVowfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNV
# BAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQG
# A1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwggEiMA0GCSqGSIb3
# DQEBAQUAA4IBDwAwggEKAoIBAQCpHQ28dxGKOiDs/BOX9fp/aZRrdFQQ1aUKAIKF
# ++18aEssX8XD5WHCdrc+Zitb8BVTJwQxH0EbGpUdzgkTjnxhMFmxMEQP8WCIhFRD
# DNdNuDgIs0Ldk6zWczBXJoKjRQ3Q6vVHgc2/JGAyWGBG8lhHhjKEHnRhZ5FfgVSx
# z5NMksHEpl3RYRNuKMYa+YaAu99h/EbBJx0kZxJyGiGKr0tkiVBisV39dx898Fd1
# rL2KQk1AUdEPnAY+Z3/1ZsADlkR+79BL/W7lmsqxqPJ6Kgox8NpOBpG2iAg16Hgc
# sOmZzTznL0S6p/TcZL2kAcEgCZN4zfy8wMlEXV4WnAEFTyJNAgMBAAGjggHmMIIB
# 4jAQBgkrBgEEAYI3FQEEAwIBADAdBgNVHQ4EFgQU1WM6XIoxkPNDe3xGG8UzaFqF
# bVUwGQYJKwYBBAGCNxQCBAweCgBTAHUAYgBDAEEwCwYDVR0PBAQDAgGGMA8GA1Ud
# EwEB/wQFMAMBAf8wHwYDVR0jBBgwFoAU1fZWy4/oolxiaNE9lJBb186aGMQwVgYD
# VR0fBE8wTTBLoEmgR4ZFaHR0cDovL2NybC5taWNyb3NvZnQuY29tL3BraS9jcmwv
# cHJvZHVjdHMvTWljUm9vQ2VyQXV0XzIwMTAtMDYtMjMuY3JsMFoGCCsGAQUFBwEB
# BE4wTDBKBggrBgEFBQcwAoY+aHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraS9j
# ZXJ0cy9NaWNSb29DZXJBdXRfMjAxMC0wNi0yMy5jcnQwgaAGA1UdIAEB/wSBlTCB
# kjCBjwYJKwYBBAGCNy4DMIGBMD0GCCsGAQUFBwIBFjFodHRwOi8vd3d3Lm1pY3Jv
# c29mdC5jb20vUEtJL2RvY3MvQ1BTL2RlZmF1bHQuaHRtMEAGCCsGAQUFBwICMDQe
# MiAdAEwAZQBnAGEAbABfAFAAbwBsAGkAYwB5AF8AUwB0AGEAdABlAG0AZQBuAHQA
# LiAdMA0GCSqGSIb3DQEBCwUAA4ICAQAH5ohRDeLG4Jg/gXEDPZ2joSFvs+umzPUx
# vs8F4qn++ldtGTCzwsVmyWrf9efweL3HqJ4l4/m87WtUVwgrUYJEEvu5U4zM9GAS
# inbMQEBBm9xcF/9c+V4XNZgkVkt070IQyK+/f8Z/8jd9Wj8c8pl5SpFSAK84Dxf1
# L3mBZdmptWvkx872ynoAb0swRCQiPM/tA6WWj1kpvLb9BOFwnzJKJ/1Vry/+tuWO
# M7tiX5rbV0Dp8c6ZZpCM/2pif93FSguRJuI57BlKcWOdeyFtw5yjojz6f32WapB4
# pm3S4Zz5Hfw42JT0xqUKloakvZ4argRCg7i1gJsiOCC1JeVk7Pf0v35jWSUPei45
# V3aicaoGig+JFrphpxHLmtgOR5qAxdDNp9DvfYPw4TtxCd9ddJgiCGHasFAeb73x
# 4QDf5zEHpJM692VHeOj4qEir995yfmFrb3epgcunCaw5u+zGy9iCtHLNHfS4hQEe
# gPsbiSpUObJb2sgNVZl6h3M7COaYLeqN4DMuEin1wC9UJyH3yKxO2ii4sanblrKn
# QqLJzxlBTeCG+SqaoxFmMNO7dDJL32N79ZmKLxvHIa9Zta7cRDyXUHHXodLFVeNp
# 3lfB0d4wwP3M5k37Db9dT+mdHhk4L7zPWAUu7w2gUDXa7wknHNWzfjUeCLraNtvT
# X4/edIhJEqGCAsswggI0AgEBMIH4oYHQpIHNMIHKMQswCQYDVQQGEwJVUzELMAkG
# A1UECBMCV0ExEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBD
# b3Jwb3JhdGlvbjEtMCsGA1UECxMkTWljcm9zb2Z0IElyZWxhbmQgT3BlcmF0aW9u
# cyBMaW1pdGVkMSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVTTjpGRjA2LTRCQzMtQjlE
# QTElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgU2VydmljZaIjCgEBMAcG
# BSsOAwIaAxUA4ATkl0QTu3uFAmVR+pqOPC6L4GeggYMwgYCkfjB8MQswCQYDVQQG
# EwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwG
# A1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQg
# VGltZS1TdGFtcCBQQ0EgMjAxMDANBgkqhkiG9w0BAQUFAAIFAOGQLwcwIhgPMjAx
# OTEyMDMwODQ3MDNaGA8yMDE5MTIwNDA4NDcwM1owdDA6BgorBgEEAYRZCgQBMSww
# KjAKAgUA4ZAvBwIBADAHAgEAAgIgJTAHAgEAAgISOzAKAgUA4ZGAhwIBADA2Bgor
# BgEEAYRZCgQCMSgwJjAMBgorBgEEAYRZCgMCoAowCAIBAAIDB6EgoQowCAIBAAID
# AYagMA0GCSqGSIb3DQEBBQUAA4GBAFUGaKV3xFNedL16WUMZCml5XVMXn3bmcEtp
# LNlBPYkh6rzim8EM05mwKLuFf2chdeDMwv7xRqEbPcbnyZnTOba8joVdx6frKYUQ
# 4MkWmQXGbA7PYdit1ebGTvTjuTRLYziRyiLkvfmiUXxsp4B5+50SSlVtgVZykD6k
# IZBnIGDcMYIDDTCCAwkCAQEwgZMwfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldh
# c2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBD
# b3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIw
# MTACEzMAAAEUNSdF6rbIbE8AAAAAARQwDQYJYIZIAWUDBAIBBQCgggFKMBoGCSqG
# SIb3DQEJAzENBgsqhkiG9w0BCRABBDAvBgkqhkiG9w0BCQQxIgQgt0DaJpT143ye
# Fe/4xWhcq5/NyQJjbpxXXRuRmZASfnYwgfoGCyqGSIb3DQEJEAIvMYHqMIHnMIHk
# MIG9BCBMEX+t50VMGPQQXEsFWfGBi8gat6mIS7jV9Lz5rc3rOjCBmDCBgKR+MHwx
# CzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRt
# b25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1p
# Y3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwAhMzAAABFDUnReq2yGxPAAAAAAEU
# MCIEICvF4pAfZAyEleU60MHaZwF4uYFEZJDkPN65I85+V4w9MA0GCSqGSIb3DQEB
# CwUABIIBAEBzInyu4tST4ub2WSb83xblKFmOAWTy44VfnV5YbZtvdcuCsAIAoeVp
# 8Cc6LeuvnYPlRl/r5DS8iOrmwDzkvouBDgC6s5HqWqGK4pXJHZVAI9Jjuz1af6fB
# 295egZg8wI94TijuC7r5cbjBlS4ZR33rPBAZaeMs24OepaWWXKqU4GR50zAUetx1
# +WDVha3n0fMvicfVdMBJDhFWiIhbCdopxaklODLO4iPw1Qr+HZI7suxz1NaecBn9
# 9r0JPFrnUQrLpwD+jSX5yMxiMplMbSD8kJvCz0dfee6tt0I52QmR+9KxtloiAQc/
# HkAxjNrgVZHyDQ8FRf9Df3wVS4dsDpE=
# SIG # End signature block
