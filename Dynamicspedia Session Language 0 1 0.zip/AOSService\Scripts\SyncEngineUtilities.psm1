﻿
function Get-SyncEngineConnectionString([string]$sqlServer, [string]$sqlUser, [string]$sqlPwd, [string]$sqlDB)
{
    return "Data Source=$sqlServer; " +
        "Integrated Security=False; " +
        "User Id=$sqlUser; " +
        "Password='`"$sqlPwd`"'; " +
        "Initial Catalog=$sqlDB"
}

function Get-SanitizedSyncEngineArguments([string]$arguments)
{
    return $arguments -replace "Password='`".+?`"'", "Password='`"*************`"'"
}

function Invoke-DbSyncPreReq([string]$LogDir, [string]$metadataDirectory, [string]$connectionstring, [bool]$useLegacyIds)
{
    $webroot = Get-AosWebSitePhysicalPath
    [xml]$web = Get-Content "$($webroot)\web.config"

    Write-Output 'Update Web.Config file - set Safe Mode On'
    ($web.configuration.appSettings.add | where key -eq 'Aos.SafeMode' | select -First 1).Value  = 'True'
    $web.Save("$($webroot)\web.config")

    #Sync Engine - Pre Req

    $command = Join-Path $metadataDirectory "Bin\SyncEngine.exe"
    $syncMode = "additivetablesync"
    if ($useLegacyIds)
    {
        $syncMode = "additivetablesync,legacyids"
    }

    $arguments = "-syncmode=$syncMode -metadatabinaries=$metadataDirectory -connect=`"$connectionstring`" -verbosity=`"Diagnostic`""

    #Sync Engine - Additive Table Sync
    Write-Output 'Starting SyncEngine to trigger additive tables sync'
    Write-Output $command (Get-SanitizedSyncEngineArguments $arguments)

    $additiveSyncLogFile = "$LogDir\additivesync.log"
    $additiveSyncErrorFile = "$LogDir\additivesync.error.log"

    $process = Start-Process $command -ArgumentList $arguments -PassThru -Wait -RedirectStandardOutput $additiveSyncLogFile -RedirectStandardError $additiveSyncErrorFile
        
    # Adding new syncMode to SyncEngine is not fully backwards compatable as old versions of the exe throw an argument exception
    # Checking if the parameter -syncmode=additivetablesync is not understood by SyncEngine and ignoring.
    $additiveSyncLog = Get-Content $additiveSyncLogFile
    $additiveSyncError = Get-Content $additiveSyncErrorFile

    if (($process.ExitCode -ne 0) -and (($additiveSyncLog| %{$_ -match 'System.ArgumentException: Invalid sync mode argument -syncmode=additivetablesync'}) -contains $true))
    {
        Clear-Content $additiveSyncErrorFile
        Clear-Content $additiveSyncLogFile
        Write-Output "Parameter -syncmode=additivetablesync is not recognised by this version of SyncEngine. Skipping additive table sync."
    }

    #Sync Engine - Partial sync of select tables + kernel sync
    $syncList = "BATCHJOBRECURRENCECOUNT,BATCHJOBACTIVEPERIOD,BATCH,BATCHHISTORY,BATCHJOB,BATCHJOBHISTORY,EVENTCUD,EVENTCUDLINES,INTEGRATIONACTIVITYRUNTIMETABLE,RELEASEUPDATECHANGETRACKINGTABLES,RELEASEUPDATECONFIGURATION,RELEASEUPDATEDISABLEDINDEXES,RELEASEUPDATESCRIPTDEPENDENCY,RELEASEUPDATESCRIPTS,RELEASEUPDATESCRIPTSERRORLOG,RELEASEUPDATESCRIPTSLOG,RELEASEUPDATESCRIPTSUSEDTABLES,RELEASEUPDATEVERSIONS,SYSDATABASELOG,SYSDATABASELOGLINES,SYSDATACACHECONFIGURATIONTABLE,SYSDATACHANGEDETECTIONEVENTTABLE,SYSDATASHARINGFOREIGNKEYTABLE,SYSDATASHARINGISSUES,SYSDATASHARINGORGANIZATION,SYSDATASHARINGORGANIZATIONENABLED,SYSDATASHARINGPOLICY,SYSDATASHARINGPOLICYSTAGING,SYSDATASHARINGRULE,SYSDATASHARINGRULEENABLED,SYSDATASHARINGRULEISSUES,SYSDATASHARINGTABLEFIELD,SYSDATASHARINGTABLEFIELDENABLED,SYSDATASHARINGTESTFKINKEY,SYSDATASHARINGTESTFOREIGNKEYTABLE,SYSDATASHARINGTESTTABLE,SYSFLIGHTING,SYSUSERINFO,SYSUSERLOG,USERGUID,USERINFO,SYSCLIENTPERF,SYSTEMJOBPARAMETERS"

    $syncMode = "partiallist"
    if ($useLegacyIds)
    {
        $syncMode = "partiallist,legacyids"
    }

    $arguments = "-syncmode=$syncMode -synclist=$syncList -metadatabinaries=$metadataDirectory -connect=`"$connectionstring`" -verbosity=`"Diagnostic`""

    Write-Output 'Starting SyncEngine to trigger the kernal tables sync and partial sync of select system tables'
    Write-Output $command (Get-SanitizedSyncEngineArguments $arguments)

    $partialSyncLogFile = "$LogDir\partialsync.log"
    $partialSyncErrorFile = "$LogDir\partialsync.error.log"

    $process = Start-Process $command -ArgumentList $arguments -PassThru -Wait -RedirectStandardOutput $partialSyncLogFile -RedirectStandardError $partialSyncErrorFile

    #Update Web.Config file - set Safe Mode Off
    [xml]$web = Get-Content "$($webroot)\web.config"
    ($web.configuration.appSettings.add | where key -eq 'Aos.SafeMode' | select -First 1).Value  = 'False'
    $web.Save("$($webroot)\web.config")

    if ($additiveSyncError -ne $null)
    {
        Write-Error 'Failed pre requisities for running the data upgrade. Please fix the issues in the error log and retry the step'
        throw $additiveSyncError
    }

    $partialSyncError = Get-Content $partialSyncErrorFile
    if (($process.ExitCode -ne 0) -or $partialSyncError -ne $null)
    {
        Write-Error 'Failed pre requisities for running the data upgrade. Please fix the issues in the error log and retry the step'
        throw $partialSyncError
    }
}

Export-ModuleMember -Function *

# SIG # Begin signature block
# MIIjtgYJKoZIhvcNAQcCoIIjpzCCI6MCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCB2Ie7/Qb0hGVfD
# 6AVxive1bJmu3TD9ni4Pv7NHVDq7rqCCDYUwggYDMIID66ADAgECAhMzAAABUptA
# n1BWmXWIAAAAAAFSMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMTkwNTAyMjEzNzQ2WhcNMjAwNTAyMjEzNzQ2WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQCxp4nT9qfu9O10iJyewYXHlN+WEh79Noor9nhM6enUNbCbhX9vS+8c/3eIVazS
# YnVBTqLzW7xWN1bCcItDbsEzKEE2BswSun7J9xCaLwcGHKFr+qWUlz7hh9RcmjYS
# kOGNybOfrgj3sm0DStoK8ljwEyUVeRfMHx9E/7Ca/OEq2cXBT3L0fVnlEkfal310
# EFCLDo2BrE35NGRjG+/nnZiqKqEh5lWNk33JV8/I0fIcUKrLEmUGrv0CgC7w2cjm
# bBhBIJ+0KzSnSWingXol/3iUdBBy4QQNH767kYGunJeY08RjHMIgjJCdAoEM+2mX
# v1phaV7j+M3dNzZ/cdsz3oDfAgMBAAGjggGCMIIBfjAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQU3f8Aw1sW72WcJ2bo/QSYGzVrRYcw
# VAYDVR0RBE0wS6RJMEcxLTArBgNVBAsTJE1pY3Jvc29mdCBJcmVsYW5kIE9wZXJh
# dGlvbnMgTGltaXRlZDEWMBQGA1UEBRMNMjMwMDEyKzQ1NDEzNjAfBgNVHSMEGDAW
# gBRIbmTlUAXTgqoXNzcitW2oynUClTBUBgNVHR8ETTBLMEmgR6BFhkNodHRwOi8v
# d3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NybC9NaWNDb2RTaWdQQ0EyMDExXzIw
# MTEtMDctMDguY3JsMGEGCCsGAQUFBwEBBFUwUzBRBggrBgEFBQcwAoZFaHR0cDov
# L3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9jZXJ0cy9NaWNDb2RTaWdQQ0EyMDEx
# XzIwMTEtMDctMDguY3J0MAwGA1UdEwEB/wQCMAAwDQYJKoZIhvcNAQELBQADggIB
# AJTwROaHvogXgixWjyjvLfiRgqI2QK8GoG23eqAgNjX7V/WdUWBbs0aIC3k49cd0
# zdq+JJImixcX6UOTpz2LZPFSh23l0/Mo35wG7JXUxgO0U+5drbQht5xoMl1n7/TQ
# 4iKcmAYSAPxTq5lFnoV2+fAeljVA7O43szjs7LR09D0wFHwzZco/iE8Hlakl23ZT
# 7FnB5AfU2hwfv87y3q3a5qFiugSykILpK0/vqnlEVB0KAdQVzYULQ/U4eFEjnis3
# Js9UrAvtIhIs26445Rj3UP6U4GgOjgQonlRA+mDlsh78wFSGbASIvK+fkONUhvj8
# B8ZHNn4TFfnct+a0ZueY4f6aRPxr8beNSUKn7QW/FQmn422bE7KfnqWncsH7vbNh
# G929prVHPsaa7J22i9wyHj7m0oATXJ+YjfyoEAtd5/NyIYaE4Uu0j1EhuYUo5VaJ
# JnMaTER0qX8+/YZRWrFN/heps41XNVjiAawpbAa0fUa3R9RNBjPiBnM0gvNPorM4
# dsV2VJ8GluIQOrJlOvuCrOYDGirGnadOmQ21wPBoGFCWpK56PxzliKsy5NNmAXcE
# x7Qb9vUjY1WlYtrdwOXTpxN4slzIht69BaZlLIjLVWwqIfuNrhHKNDM9K+v7vgrI
# bf7l5/665g0gjQCDCN6Q5sxuttTAEKtJeS/pkpI+DbZ/MIIHejCCBWKgAwIBAgIK
# YQ6Q0gAAAAAAAzANBgkqhkiG9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNV
# BAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jv
# c29mdCBDb3Jwb3JhdGlvbjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlm
# aWNhdGUgQXV0aG9yaXR5IDIwMTEwHhcNMTEwNzA4MjA1OTA5WhcNMjYwNzA4MjEw
# OTA5WjB+MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UE
# BxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSgwJgYD
# VQQDEx9NaWNyb3NvZnQgQ29kZSBTaWduaW5nIFBDQSAyMDExMIICIjANBgkqhkiG
# 9w0BAQEFAAOCAg8AMIICCgKCAgEAq/D6chAcLq3YbqqCEE00uvK2WCGfQhsqa+la
# UKq4BjgaBEm6f8MMHt03a8YS2AvwOMKZBrDIOdUBFDFC04kNeWSHfpRgJGyvnkmc
# 6Whe0t+bU7IKLMOv2akrrnoJr9eWWcpgGgXpZnboMlImEi/nqwhQz7NEt13YxC4D
# dato88tt8zpcoRb0RrrgOGSsbmQ1eKagYw8t00CT+OPeBw3VXHmlSSnnDb6gE3e+
# lD3v++MrWhAfTVYoonpy4BI6t0le2O3tQ5GD2Xuye4Yb2T6xjF3oiU+EGvKhL1nk
# kDstrjNYxbc+/jLTswM9sbKvkjh+0p2ALPVOVpEhNSXDOW5kf1O6nA+tGSOEy/S6
# A4aN91/w0FK/jJSHvMAhdCVfGCi2zCcoOCWYOUo2z3yxkq4cI6epZuxhH2rhKEmd
# X4jiJV3TIUs+UsS1Vz8kA/DRelsv1SPjcF0PUUZ3s/gA4bysAoJf28AVs70b1FVL
# 5zmhD+kjSbwYuER8ReTBw3J64HLnJN+/RpnF78IcV9uDjexNSTCnq47f7Fufr/zd
# sGbiwZeBe+3W7UvnSSmnEyimp31ngOaKYnhfsi+E11ecXL93KCjx7W3DKI8sj0A3
# T8HhhUSJxAlMxdSlQy90lfdu+HggWCwTXWCVmj5PM4TasIgX3p5O9JawvEagbJjS
# 4NaIjAsCAwEAAaOCAe0wggHpMBAGCSsGAQQBgjcVAQQDAgEAMB0GA1UdDgQWBBRI
# bmTlUAXTgqoXNzcitW2oynUClTAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTAL
# BgNVHQ8EBAMCAYYwDwYDVR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBRyLToCMZBD
# uRQFTuHqp8cx0SOJNDBaBgNVHR8EUzBRME+gTaBLhklodHRwOi8vY3JsLm1pY3Jv
# c29mdC5jb20vcGtpL2NybC9wcm9kdWN0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFf
# MDNfMjIuY3JsMF4GCCsGAQUFBwEBBFIwUDBOBggrBgEFBQcwAoZCaHR0cDovL3d3
# dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFf
# MDNfMjIuY3J0MIGfBgNVHSAEgZcwgZQwgZEGCSsGAQQBgjcuAzCBgzA/BggrBgEF
# BQcCARYzaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9kb2NzL3ByaW1h
# cnljcHMuaHRtMEAGCCsGAQUFBwICMDQeMiAdAEwAZQBnAGEAbABfAHAAbwBsAGkA
# YwB5AF8AcwB0AGEAdABlAG0AZQBuAHQALiAdMA0GCSqGSIb3DQEBCwUAA4ICAQBn
# 8oalmOBUeRou09h0ZyKbC5YR4WOSmUKWfdJ5DJDBZV8uLD74w3LRbYP+vj/oCso7
# v0epo/Np22O/IjWll11lhJB9i0ZQVdgMknzSGksc8zxCi1LQsP1r4z4HLimb5j0b
# pdS1HXeUOeLpZMlEPXh6I/MTfaaQdION9MsmAkYqwooQu6SpBQyb7Wj6aC6VoCo/
# KmtYSWMfCWluWpiW5IP0wI/zRive/DvQvTXvbiWu5a8n7dDd8w6vmSiXmE0OPQvy
# CInWH8MyGOLwxS3OW560STkKxgrCxq2u5bLZ2xWIUUVYODJxJxp/sfQn+N4sOiBp
# mLJZiWhub6e3dMNABQamASooPoI/E01mC8CzTfXhj38cbxV9Rad25UAqZaPDXVJi
# hsMdYzaXht/a8/jyFqGaJ+HNpZfQ7l1jQeNbB5yHPgZ3BtEGsXUfFL5hYbXw3MYb
# BL7fQccOKO7eZS/sl/ahXJbYANahRr1Z85elCUtIEJmAH9AAKcWxm6U/RXceNcbS
# oqKfenoi+kiVH6v7RyOA9Z74v2u3S5fi63V4GuzqN5l5GEv/1rMjaHXmr/r8i+sL
# gOppO6/8MO0ETI7f33VtY5E90Z1WTk+/gFcioXgRMiF670EKsT/7qMykXcGhiJtX
# cVZOSEXAQsmbdlsKgEhr/Xmfwb1tbWrJUnMTDXpQzTGCFYcwghWDAgEBMIGVMH4x
# CzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRt
# b25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01p
# Y3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTECEzMAAAFSm0CfUFaZdYgAAAAA
# AVIwDQYJYIZIAWUDBAIBBQCggdowGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQw
# HAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIIbn
# U4pNMXgk48XgEbPed5NW2r9vVnP/sANNmzGjicjOMG4GCisGAQQBgjcCAQwxYDBe
# oECAPgBBAHUAdABvAFUAcABnAHIAYQBkAGUAQwBvAG4AZgBpAGcAQQBvAHMAUwBl
# AHIAdgBpAGMAZQAuAHAAcwAxoRqAGGh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbTAN
# BgkqhkiG9w0BAQEFAASCAQBot+RoQR0QPorG/C370NQAqxSmtLyYb4l7Jv46Ky4j
# zjavLFSnijrcWL+SrQ9poel4MlN0YvoPvGOY7SfveSVsCawbdbm97A5RH10dKyct
# 5R1U5vG0fXEEd9WO4IR5zoX8D7MvCk9DfloGuZjVPtjB+nhteSRugvIMjVlkPLbL
# Sw465JKwQ4pq9fQvynJJDNT4Na98nsl6cOwlm1JOJ/CzNPrUkcVLDva4E8EL/tHf
# 7U5RyvDvIwtHdaUktOkChuDrQXfL6m8LT6/DifgWwvpzs6ydkG01ja15A/kiBv9G
# ouOfOpY5lI/4yOvDTg3yX+1MXoYhdZhact1v6z5MY6reoYIS5TCCEuEGCisGAQQB
# gjcDAwExghLRMIISzQYJKoZIhvcNAQcCoIISvjCCEroCAQMxDzANBglghkgBZQME
# AgEFADCCAVEGCyqGSIb3DQEJEAEEoIIBQASCATwwggE4AgEBBgorBgEEAYRZCgMB
# MDEwDQYJYIZIAWUDBAIBBQAEIM5gX0yYawahUl29QlCtE6bSrvXWhZNkzklfFVo1
# +hnOAgZduE96NC0YEzIwMTkxMjAzMDMyMzQ3LjA0M1owBIACAfSggdCkgc0wgcox
# CzAJBgNVBAYTAlVTMQswCQYDVQQIEwJXQTEQMA4GA1UEBxMHUmVkbW9uZDEeMBwG
# A1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMS0wKwYDVQQLEyRNaWNyb3NvZnQg
# SXJlbGFuZCBPcGVyYXRpb25zIExpbWl0ZWQxJjAkBgNVBAsTHVRoYWxlcyBUU1Mg
# RVNOOkE4NDEtNEJCNC1DQTkzMSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFt
# cCBTZXJ2aWNloIIOPDCCBPEwggPZoAMCAQICEzMAAAEOJpHynZLbgSkAAAAAAQ4w
# DQYJKoZIhvcNAQELBQAwfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0
# b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3Jh
# dGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwHhcN
# MTkxMDIzMjMxOTE4WhcNMjEwMTIxMjMxOTE4WjCByjELMAkGA1UEBhMCVVMxCzAJ
# BgNVBAgTAldBMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQg
# Q29ycG9yYXRpb24xLTArBgNVBAsTJE1pY3Jvc29mdCBJcmVsYW5kIE9wZXJhdGlv
# bnMgTGltaXRlZDEmMCQGA1UECxMdVGhhbGVzIFRTUyBFU046QTg0MS00QkI0LUNB
# OTMxJTAjBgNVBAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZpY2UwggEiMA0G
# CSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQDVAZeiJz2rNUm5FnQV7KLoay7FXA8r
# WMadGWHVkKp5H8oV6/716Ra9o4cQxvVKouIbywDZM5OoMx1cK3UjGCJwJJ645s8N
# dUX3jQPwUzk6jDQYrQUYhHzsdJ2ZOjWXJ2AqR7YKzfXqXAcXniLSe1lfvLFPctK2
# 5h7RYHTNldEglHnEYyyUSC2KELbHyJ/x4RUlGL0Z41GCBzLxmmnQXRD8VQz9mx39
# O51Mz6QBVpIBlBhcHldUqWgslL1z25uqfYXKLpR3S2pclEj/EwrWhG/OSCZBhpg0
# dbq++nzYbdhXUctNZwMI7UrKxRtcA55DNMB/ETColAHWaBei/yuEO4TjAgMBAAGj
# ggEbMIIBFzAdBgNVHQ4EFgQUQeSkq9TmIF5Sa0eX1Ip3K/9T39kwHwYDVR0jBBgw
# FoAU1WM6XIoxkPNDe3xGG8UzaFqFbVUwVgYDVR0fBE8wTTBLoEmgR4ZFaHR0cDov
# L2NybC5taWNyb3NvZnQuY29tL3BraS9jcmwvcHJvZHVjdHMvTWljVGltU3RhUENB
# XzIwMTAtMDctMDEuY3JsMFoGCCsGAQUFBwEBBE4wTDBKBggrBgEFBQcwAoY+aHR0
# cDovL3d3dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0cy9NaWNUaW1TdGFQQ0FfMjAx
# MC0wNy0wMS5jcnQwDAYDVR0TAQH/BAIwADATBgNVHSUEDDAKBggrBgEFBQcDCDAN
# BgkqhkiG9w0BAQsFAAOCAQEABkb5SfYYqCqg0oIbDwzIe0nM84CqpbfjqLodi7Bd
# VtfMCCuAefUzJ9PmS2xZHq8MuNOl5y+pHDJN7ZibsyEThoeD0HopVG3PXVn9QXmj
# lbDYRxMr3e7KGeqRtJdTrDMcnx/fNy7mHj27MmmuhcHBTOyPjU+D+RnTybqgQrMi
# T0pY1LVM+PxxjCaOxSLc6eCZGNvAcRqGQJaqpGa8uCEIpGhdpbpIv1UWtIVrjOsz
# AmLVoINL/YjYYE7a/ZtmFseNgyZzvWwzNYSd4XvXtMrYc/VOyUBeigfVKW1X734L
# 51a6VViSIpuhD7x8LBlLjB687bvoH5QhPw4Rnb2Z90EESTCCBnEwggRZoAMCAQIC
# CmEJgSoAAAAAAAIwDQYJKoZIhvcNAQELBQAwgYgxCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xMjAwBgNVBAMTKU1pY3Jvc29mdCBSb290IENlcnRp
# ZmljYXRlIEF1dGhvcml0eSAyMDEwMB4XDTEwMDcwMTIxMzY1NVoXDTI1MDcwMTIx
# NDY1NVowfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNV
# BAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQG
# A1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwggEiMA0GCSqGSIb3
# DQEBAQUAA4IBDwAwggEKAoIBAQCpHQ28dxGKOiDs/BOX9fp/aZRrdFQQ1aUKAIKF
# ++18aEssX8XD5WHCdrc+Zitb8BVTJwQxH0EbGpUdzgkTjnxhMFmxMEQP8WCIhFRD
# DNdNuDgIs0Ldk6zWczBXJoKjRQ3Q6vVHgc2/JGAyWGBG8lhHhjKEHnRhZ5FfgVSx
# z5NMksHEpl3RYRNuKMYa+YaAu99h/EbBJx0kZxJyGiGKr0tkiVBisV39dx898Fd1
# rL2KQk1AUdEPnAY+Z3/1ZsADlkR+79BL/W7lmsqxqPJ6Kgox8NpOBpG2iAg16Hgc
# sOmZzTznL0S6p/TcZL2kAcEgCZN4zfy8wMlEXV4WnAEFTyJNAgMBAAGjggHmMIIB
# 4jAQBgkrBgEEAYI3FQEEAwIBADAdBgNVHQ4EFgQU1WM6XIoxkPNDe3xGG8UzaFqF
# bVUwGQYJKwYBBAGCNxQCBAweCgBTAHUAYgBDAEEwCwYDVR0PBAQDAgGGMA8GA1Ud
# EwEB/wQFMAMBAf8wHwYDVR0jBBgwFoAU1fZWy4/oolxiaNE9lJBb186aGMQwVgYD
# VR0fBE8wTTBLoEmgR4ZFaHR0cDovL2NybC5taWNyb3NvZnQuY29tL3BraS9jcmwv
# cHJvZHVjdHMvTWljUm9vQ2VyQXV0XzIwMTAtMDYtMjMuY3JsMFoGCCsGAQUFBwEB
# BE4wTDBKBggrBgEFBQcwAoY+aHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraS9j
# ZXJ0cy9NaWNSb29DZXJBdXRfMjAxMC0wNi0yMy5jcnQwgaAGA1UdIAEB/wSBlTCB
# kjCBjwYJKwYBBAGCNy4DMIGBMD0GCCsGAQUFBwIBFjFodHRwOi8vd3d3Lm1pY3Jv
# c29mdC5jb20vUEtJL2RvY3MvQ1BTL2RlZmF1bHQuaHRtMEAGCCsGAQUFBwICMDQe
# MiAdAEwAZQBnAGEAbABfAFAAbwBsAGkAYwB5AF8AUwB0AGEAdABlAG0AZQBuAHQA
# LiAdMA0GCSqGSIb3DQEBCwUAA4ICAQAH5ohRDeLG4Jg/gXEDPZ2joSFvs+umzPUx
# vs8F4qn++ldtGTCzwsVmyWrf9efweL3HqJ4l4/m87WtUVwgrUYJEEvu5U4zM9GAS
# inbMQEBBm9xcF/9c+V4XNZgkVkt070IQyK+/f8Z/8jd9Wj8c8pl5SpFSAK84Dxf1
# L3mBZdmptWvkx872ynoAb0swRCQiPM/tA6WWj1kpvLb9BOFwnzJKJ/1Vry/+tuWO
# M7tiX5rbV0Dp8c6ZZpCM/2pif93FSguRJuI57BlKcWOdeyFtw5yjojz6f32WapB4
# pm3S4Zz5Hfw42JT0xqUKloakvZ4argRCg7i1gJsiOCC1JeVk7Pf0v35jWSUPei45
# V3aicaoGig+JFrphpxHLmtgOR5qAxdDNp9DvfYPw4TtxCd9ddJgiCGHasFAeb73x
# 4QDf5zEHpJM692VHeOj4qEir995yfmFrb3epgcunCaw5u+zGy9iCtHLNHfS4hQEe
# gPsbiSpUObJb2sgNVZl6h3M7COaYLeqN4DMuEin1wC9UJyH3yKxO2ii4sanblrKn
# QqLJzxlBTeCG+SqaoxFmMNO7dDJL32N79ZmKLxvHIa9Zta7cRDyXUHHXodLFVeNp
# 3lfB0d4wwP3M5k37Db9dT+mdHhk4L7zPWAUu7w2gUDXa7wknHNWzfjUeCLraNtvT
# X4/edIhJEqGCAs4wggI3AgEBMIH4oYHQpIHNMIHKMQswCQYDVQQGEwJVUzELMAkG
# A1UECBMCV0ExEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBD
# b3Jwb3JhdGlvbjEtMCsGA1UECxMkTWljcm9zb2Z0IElyZWxhbmQgT3BlcmF0aW9u
# cyBMaW1pdGVkMSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVTTjpBODQxLTRCQjQtQ0E5
# MzElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgU2VydmljZaIjCgEBMAcG
# BSsOAwIaAxUAkmNDHJXWmEV6IeyFeEIwunwyChWggYMwgYCkfjB8MQswCQYDVQQG
# EwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwG
# A1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQg
# VGltZS1TdGFtcCBQQ0EgMjAxMDANBgkqhkiG9w0BAQUFAAIFAOGQSRcwIhgPMjAx
# OTEyMDMxMDM4MTVaGA8yMDE5MTIwNDEwMzgxNVowdzA9BgorBgEEAYRZCgQBMS8w
# LTAKAgUA4ZBJFwIBADAKAgEAAgIRtgIB/zAHAgEAAgISCjAKAgUA4ZGalwIBADA2
# BgorBgEEAYRZCgQCMSgwJjAMBgorBgEEAYRZCgMCoAowCAIBAAIDB6EgoQowCAIB
# AAIDAYagMA0GCSqGSIb3DQEBBQUAA4GBAEk6v3/wlTnN4hmVpokY4e7QRpb5Sx7u
# Wi+P6zen5lhXAc2awtldDjOCpG4Vajpbtc6Q4CHvfV/NW9xaN5fkGFAGOw3W8Y7K
# EstHTf8GGQEGJZP5zn/FA8S62LFBGJAsgHPlAmaWvbxxmitSyg0zi+SgSlhwlnEV
# UqeZckWCH5M0MYIDDTCCAwkCAQEwgZMwfDELMAkGA1UEBhMCVVMxEzARBgNVBAgT
# Cldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29m
# dCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENB
# IDIwMTACEzMAAAEOJpHynZLbgSkAAAAAAQ4wDQYJYIZIAWUDBAIBBQCgggFKMBoG
# CSqGSIb3DQEJAzENBgsqhkiG9w0BCRABBDAvBgkqhkiG9w0BCQQxIgQgG/k+zLQU
# 81ZYe2ImcRdGl5IAKrBWXzNjtoWfqelTOQAwgfoGCyqGSIb3DQEJEAIvMYHqMIHn
# MIHkMIG9BCBov/ePn2+tW9RhI4KYLWIbl3PTY0wpFNVTqYIUWkveMDCBmDCBgKR+
# MHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMT
# HU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwAhMzAAABDiaR8p2S24EpAAAA
# AAEOMCIEIPYeLs+jFq7Blvz6pPacXsTsuBDrbGh0tDI6oYb9fo0mMA0GCSqGSIb3
# DQEBCwUABIIBAJtU7O5zkMBSTZR815q2z5xyR71FvpoLnTJfRlypPKU3ML+gldZo
# e9lYBjGg4y4bxf4wh9xVA9pTsEU7nvnGlLY0bXEgPjGTDnx61Sy0bZRFdnG/HS1T
# Y9+nWB6zsQ0nOi4S3UUWLjCH8cQGtNEt+ir1aXjfR9DlSbpGwJm39LIiyWxSNfnx
# vcXJYpG8D0+Qqumt/iRFZTP24YAWW356toZs8+qdZm8hjzB3skpm/9tS5Gf3DnyB
# L/n49dWEJCOTH2L4Er7dbHQxlxhiSvreUJLnBZZ0Q1eUer2rqGxgrgtq1OTBYT+X
# CWHcZ4rhPwC81VCjphB/2RIPLm6BMOg0acM=
# SIG # End signature block
