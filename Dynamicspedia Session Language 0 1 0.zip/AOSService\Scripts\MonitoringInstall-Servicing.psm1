<#
.SYNOPSIS
    Functions to manage the Monitoring Agent during servicing.

.DESCRIPTION
    Contains a set of functions used by the Dynamics 365 for Finance and Operations
    Enterprise Edition servicing process to interact with the Geneva Monitoring Agent.

.NOTES
    Requires PowerShell 3.0 or later.

    Configure Write-Message by calling Set-WriteMessageLogFilePath to set a
    file to send output to.

    Copyright © 2019 Microsoft. All rights reserved.
#>

# Module level variables to control default behavior of Write-Message.
[string]$Script:WriteMessageLogFilePath = $null

<#
.SYNOPSIS
    Set module level variable to control default behavior of Write-Message.
    Set to the full path of the file to append output to (default is null).
#>
function Set-WriteMessageLogFilePath
{
    [CmdletBinding()]
    Param([string]$Path)

    $Script:WriteMessageLogFilePath = $Path
}

<#
.SYNOPSIS
    Write messages to log file and/or output.
#>
function Write-Message
{
    [CmdletBinding()]
    Param(
        [parameter(Mandatory = $false, ValueFromPipeline = $true)][string[]]$Message,
        [switch]$Vrb,
        [string]$LogFilePath = $Script:WriteMessageLogFilePath)

    Process
    {
        if ($LogFilePath)
        {
            $Message | ForEach-Object { "$([DateTime]::UtcNow.ToString("yyyy-MM-dd HH:mm:ss")): $($_)" | Out-File -FilePath $LogFilePath -Append }
        }

        # Verbose messages only goes to log file.
        if (!$Vrb)
        {
            $Message | Write-Output
        }
    }
}

<#
.SYNOPSIS
    Returns the registry path for the MonitoringInstall settings.
#>
function Get-MonitoringInstallRegistryPath
{
    return "HKLM:\SOFTWARE\Microsoft\Dynamics\AX\Diagnostics\MonitoringInstall"
}

<#
.SYNOPSIS
    Returns the scheduled task path for the MonitoringInstall tasks.
#>
function Get-MonitoringInstallTaskPath
{
    # Task path must begin and end with "\" for Get-ScheduledTask to work.
    return "\Microsoft\Dynamics\AX\Diagnostics\"
}

<#
.SYNOPSIS
    Read the Monitoring installation path from registry.
#>
function Get-MonitoringInstallPath()
{
    $RegistryPath = Get-MonitoringInstallRegistryPath
    $InstallPathKey = "InstallPath"
    $InstallPath = $null

    if (Test-Path -LiteralPath $RegistryPath -ErrorAction SilentlyContinue)
    {
        $RegistryKey = Get-Item -LiteralPath $RegistryPath -ErrorAction SilentlyContinue
        if ($RegistryKey)
        {
            $InstallPath = $RegistryKey.GetValue($InstallPathKey)
            if (!$InstallPath)
            {
                Write-Message "Warning: Could not read MonitoringInstall registry key $($InstallPathKey) from: $($RegistryPath)" -Vrb
            }
        }
        else
        {
            Write-Message "Warning: Could not read MonitoringInstall registry keys from: $($RegistryPath)" -Vrb
        }
    }
    else
    {
        Write-Message "Warning: Could not find MonitoringInstall registry path: $($RegistryPath)" -Vrb
    }

    return $InstallPath
}

<#
.SYNOPSIS
    Get the default Monitoring installation path.
#>
function Get-MonitoringInstallPathDefault()
{
    if ($env:SERVICEDRIVE)
    {
        $InstallPath = Join-Path -Path "$($env:SERVICEDRIVE)" -ChildPath "Monitoring"
    }
    else
    {
        $InstallPath = Join-Path -Path "$($env:SystemDrive)" -ChildPath "Monitoring"
    }

    return $InstallPath
}

<#
.SYNOPSIS
    Read the Monitoring manifest path from registry.
#>
function Get-MonitoringManifestPath()
{
    $RegistryPath = Get-MonitoringInstallRegistryPath
    $ManifestPathKey = "ManifestPath"
    $ManifestPath = $null

    if (Test-Path -LiteralPath $RegistryPath -ErrorAction SilentlyContinue)
    {
        $RegistryKey = Get-Item -LiteralPath $RegistryPath -ErrorAction SilentlyContinue
        if ($RegistryKey)
        {
            $ManifestPath = $RegistryKey.GetValue($ManifestPathKey)
            if (!$ManifestPath)
            {
                Write-Message "Warning: Could not read MonitoringInstall registry key $($ManifestPathKey) from: $($RegistryPath)" -Vrb
            }
        }
        else
        {
            Write-Message "Warning: Could not read MonitoringInstall registry key: $($RegistryPath)" -Vrb
        }
    }
    else
    {
        Write-Message "Warning: Could not find MonitoringInstall registry path: $($RegistryPath)" -Vrb
    }

    return $ManifestPath
}

<#
.SYNOPSIS
    Get the default Monitoring manifest path.
#>
function Get-MonitoringManifestPathDefault()
{
    $InstallPath = Get-MonitoringInstallPath
    if (!$InstallPath)
    {
        $InstallPath = Get-MonitoringInstallPathDefault
    }

    $ManifestPath = Join-Path -Path $InstallPath -ChildPath "Instrumentation"

    return $ManifestPath
}

<#
.SYNOPSIS
    Create task for MonitoringInstall.exe action and run as SYSTEM.
#>
function Invoke-MonitoringInstallAsSystem([string]$MonitoringInstallFilePath, [string]$LogPath, [string]$Action, [int]$MaxWaitSec = 300, [int]$MaxLogLines = 100, [switch]$UseExistingTask)
{
    try
    {
        $TaskPath = Get-MonitoringInstallTaskPath
        $TaskName = "MonitoringInstall-$($Action)"
        $MonitoringInstallPath = Split-Path -Path $MonitoringInstallFilePath -Parent

        if ($LogPath)
        {
            if (!(Test-Path -Path $LogPath))
            {
                New-Item -Path $LogPath -ItemType Directory | Out-Null
            }

            $LogFilePath = Join-Path -Path $LogPath -ChildPath "$($TaskName)_$([DateTime]::UtcNow.ToString("yyyyMMddHHmmss")).log"
        }
        else
        {
            # Default to using the log file path in the MonitoringInstall folder.
            $LogFilePath = Join-Path -Path $MonitoringInstallPath -ChildPath "$($TaskName).log"
        }

        Write-Message "Getting the $($TaskName) task..." -Vrb
        $ExistingTask = Get-ScheduledTask -TaskPath $TaskPath -TaskName $TaskName -ErrorAction SilentlyContinue
        if ($ExistingTask)
        {
            if ($UseExistingTask)
            {
                Write-Message "Using existing $($TaskName) task found (State: $($ExistingTask.State))." -Vrb
                $Task = $ExistingTask
            }
            else
            {
                Write-Message "Existing $($TaskName) task found, but it will be replaced (State: $($ExistingTask.State))." -Vrb
            }
        }

        if (!$Task)
        {
            Write-Message "Creating $($TaskName) task to run as SYSTEM." -Vrb
            $TaskAction = New-ScheduledTaskAction -Execute $MonitoringInstallFilePath -Argument "/$($Action) /id:SingleAgent /log:$LogFilePath" -WorkingDirectory $MonitoringInstallPath
            $TaskSettings = New-ScheduledTaskSettingsSet -ExecutionTimeLimit (New-TimeSpan -Seconds $MaxWaitSec)
            $Task = Register-ScheduledTask -TaskPath $TaskPath -TaskName $TaskName -User "SYSTEM" -Action $TaskAction -Settings $TaskSettings -Force
        }

        Write-Message "Starting the $($TaskName) task..." -Vrb
        $Task | Start-ScheduledTask
        $ScheduledTask = $Task | Get-ScheduledTask
        Write-Message "Scheduled task started (State: $($ScheduledTask.State))." -Vrb

        Write-Message "Waiting up to $($MaxWaitSec) seconds for the $($TaskName) task to complete..." -Vrb
        [int]$WaitedSec = 0
        while ($ScheduledTask.State -ine "Ready" -and $WaitedSec -lt $MaxWaitSec)
        {
            Start-Sleep -Seconds 1
            $WaitedSec += 1
            $ScheduledTask = $Task | Get-ScheduledTask
        }

        # Check if task completed.
        if ($ScheduledTask.State -ine "Ready")
        {
            $ErrorMessage = "Exceeded timeout after waiting $($WaitedSec) seconds for the $($TaskName) task to complete (State: $($ScheduledTask.State))."
            Write-Message "Error: $($ErrorMessage)" -Vrb
            throw $ErrorMessage
        }
        else
        {
            Write-Message "Completed the $($TaskName) task after waiting $($WaitedSec) seconds (State: $($ScheduledTask.State))." -Vrb
            $TaskInfo = $ScheduledTask | Get-ScheduledTaskInfo
            if ($TaskInfo)
            {
                # Note: Currently the MonitoringInstall exit code cannot be used to determine success or failure.
                Write-Message "The exit code of the $($TaskName) task run at $($TaskInfo.LastRunTime.ToString("u")) is: $($TaskInfo.LastTaskResult)." -Vrb
            }
            else
            {
                Write-Message "Warning: No task run information could be found from the $($TaskName) task." -Vrb
            }
        }

        # Check log content.
        if (Test-Path -Path $LogFilePath -ErrorAction SilentlyContinue)
        {
            $LogContent = Get-Content -Path $LogFilePath -Tail $MaxLogLines
            if ($LogContent)
            {
                Write-Message "The MonitoringInstall $($Action) action log file exists at: $($LogFilePath)" -Vrb
                Write-Message "Contents of log (Last $($MaxLogLines)):" -Vrb
                foreach ($Line in $LogContent)
                {
                    Write-Message $Line -Vrb
                }

                Write-Message "*** End of Log ***" -Vrb
            }
            else
            {
                Write-Message "Warning: The MonitoringInstall $($Action) action did not write any contents to log file at: $($LogFilePath)" -Vrb
            }
        }
        else
        {
            Write-Message "Warning: The MonitoringInstall $($Action) action did not produce any log file at: $($LogFilePath)" -Vrb
        }
    }
    catch
    {
        Write-Message "Error: Failed to run MonitoringInstall $($Action) action: $($_.Message)." -Vrb
        throw
    }
    finally
    {
        # If task was triggered, make sure it is stopped.
        if ($ScheduledTask)
        {
            $ScheduledTask = $ScheduledTask | Get-ScheduledTask

            if ($ScheduledTask -and $ScheduledTask.State -ieq "Running")
            {
                Write-Message "Stopping the $($ScheduledTask.TaskName) task as it is still running." -Vrb
                $ScheduledTask | Stop-ScheduledTask
            }
        }
    }
}

<#
.SYNOPSIS
    Stop Monitoring Agent ETW sessions and processes.
#>
function Stop-MonitoringAgent([int]$MaxWaitSec = 300, [string]$LogPath, [switch]$SkipIfNotInstalled)
{
    $InstallPath = Get-MonitoringInstallPath
    if (!$InstallPath)
    {
        # Return without action if Monitoring Install path was not found in registry and skip switch specified.
        if ($SkipIfNotInstalled)
        {
            Write-Message "No Monitoring Install path found in registry. No attempt to stop the Monitoring Agent will be made." -Vrb
            return
        }
        else
        {
            $InstallPath = Get-MonitoringInstallPathDefault
            Write-Message "Warning: No Monitoring Install path found in registry. Using default: $($InstallPath)." -Vrb
        }
    }

    $MonitoringInstallPath = Join-Path -Path $InstallPath -ChildPath "MonitoringInstall"
    if (!(Test-Path -Path $MonitoringInstallPath -ErrorAction SilentlyContinue))
    {
        throw "No MonitoringInstall folder found at: $($MonitoringInstallPath)"
    }

    $MonitoringInstallFilePath = Join-Path -Path $MonitoringInstallPath -ChildPath "MonitoringInstall.exe"
    if (!(Test-Path -Path $MonitoringInstallFilePath -ErrorAction SilentlyContinue))
    {
        throw "No MonitoringInstall.exe file found at: $($MonitoringInstallFilePath)"
    }

    # Stop the Monitoring Install task if it is running.
    # This must be done before attempting to stop Monitoring Agent as it could otherwise
    # be triggering a start of Monitoring Agent after attempting to stop it.
    try
    {
        Write-Message "Stopping Monitoring Install task..."
        Stop-MonitoringInstallTask -MaxWaitSec $MaxWaitSec
    }
    catch
    {
        # This may not be a problem that requires the update process to stop.
        Write-Message "Warning: Failed to stop the MonitoringInstall task: $($_.Message)."
    }

    # Stop Monitoring ETW Sessions as SYSTEM.
    try
    {
        Write-Message "Stopping Monitoring ETW Sessions..."
        Invoke-MonitoringInstallAsSystem -MonitoringInstallFilePath $MonitoringInstallFilePath -Action "StopSessions" -LogPath $LogPath
    }
    catch
    {
        # This may not be a problem that requires the update process to stop.
        Write-Message "Warning: MonitoringInstall failed to stop Monitoring ETW Sessions: $($_.Message)."
    }

    # Stop Monitoring Agent processes as SYSTEM.
    try
    {
        Write-Message "Stopping Monitoring Agent processes..."

        $StopAgentAction = "StopAgents"

        # Determine if MonitoringInstall.exe has the new and improved StopAgentLauncher action.
        # First released with MonitoringInstall.exe 9.3.1789.0 in January 2019.
        # Note: The old StopAgent doesn't actually stop the MonAgentLauncher process, so the other
        # Monitoring Agent processes will be restarted if it does not forcefully terminate it in time.
        $MonitoringInstallFile = Get-Item -Path $MonitoringInstallFilePath
        if ($MonitoringInstallFile.VersionInfo.FileVersion)
        {
            if ($MonitoringInstallFile.VersionInfo.FileMajorPart -ge 9 -and $MonitoringInstallFile.VersionInfo.FileMinorPart -ge 3 -and $MonitoringInstallFile.VersionInfo.FileBuildPart -ge 1789)
            {
                Write-Message "Using MonitoringInstall.exe $($MonitoringInstallFile.VersionInfo.FileVersion) with StopAgentLauncher action." -Vrb
                $StopAgentAction = "StopAgentLauncher"
            }
            else
            {
                Write-Message "Using MonitoringInstall.exe $($MonitoringInstallFile.VersionInfo.FileVersion) with StopAgents action." -Vrb
            }
        }
        else
        {
            Write-Message "Using MonitoringInstall.exe which has no file version information with StopAgents action." -Vrb
        }

        Invoke-MonitoringInstallAsSystem -MonitoringInstallFilePath $MonitoringInstallFilePath -Action $StopAgentAction -LogPath $LogPath
    }
    catch
    {
        # Not being able to stop the Monitoring Agent processes is a fatal problem.
        Write-Message "Error: MonitoringInstall failed to stop Monitoring Agent processes: $($_.Message)." -Vrb
        throw
    }
    finally
    {
        # Log any running Monitoring Agent processes after stop.
        try
        {
            $Processes = Get-MonitoringAgentProcesses
            if ($Processes.Count -gt 0)
            {
                Write-Message "Found $($Processes.Count) Monitoring Agent processes running after stop:" -Vrb
                foreach ($Process in $Processes)
                {
                    Write-Message "- $($Process.Id): $($Process.Name) started at $($Process.StartTime.Tostring("u"))." -Vrb
                }
            }
            else
            {
                Write-Message "Found no Monitoring Agent processes running after stop." -Vrb
            }
        }
        catch
        {
            Write-Message "Warning: Unable to get Monitoring Agent processes running: ($_)" -Vrb
        }
    }
}

<#
.SYNOPSIS
    Start the task to register ETW events, build configurations, and start the Monitoring Agent.
#>
function Start-MonitoringAgent([int]$MaxWaitSec = 300, [switch]$SkipIfNotInstalled)
{
    $TaskPath = Get-MonitoringInstallTaskPath
    $TaskName = "MonitoringInstall"

    Write-Message "Getting the $($TaskName) task..." -Vrb
    $Task = Get-ScheduledTask -TaskPath $TaskPath -TaskName $TaskName -ErrorAction SilentlyContinue
    if (!$Task)
    {
        # Very old installations created the task in the root path.
        Write-Message "Warning: No '$($TaskName)' task found in path '$($TaskPath)'. Looking for task in all paths..." -Vrb
        $Task = Get-ScheduledTask | Where-Object -FilterScript { $_.TaskName -ieq $TaskName } | Select-Object -First 1
    }

    If ($Task)
    {
        Write-Message "The $($TaskName) task was found (State: $($Task.State))." -Vrb
        Write-Message "Starting the $($TaskName) task..." -Vrb
        $Task | Start-ScheduledTask
        $ScheduledTask = $Task | Get-ScheduledTask
        Write-Message "Scheduled task started (State: $($ScheduledTask.State))." -Vrb

        if ($MaxWaitSec -gt 0)
        {
            Write-Message "Waiting up to $($MaxWaitSec) seconds for the $($TaskName) task to complete..." -Vrb

            [int]$WaitedSec = 0
            while ($ScheduledTask.State -ine "Ready" -and $WaitedSec -lt $MaxWaitSec)
            {
                Start-Sleep -Seconds 1
                $WaitedSec += 1
                $ScheduledTask = $Task | Get-ScheduledTask
            }

            # Log any running Monitoring Agent processes after start.
            try
            {
                $Processes = Get-MonitoringAgentProcesses
                if ($Processes.Count -gt 0)
                {
                    Write-Message "Found $($Processes.Count) Monitoring Agent processes running after start:" -Vrb
                    foreach ($Process in $Processes)
                    {
                        Write-Message "- $($Process.Id): $($Process.Name) started at $($Process.StartTime.Tostring("u"))." -Vrb
                    }
                }
                else
                {
                    Write-Message "Found no Monitoring Agent processes running after start." -Vrb
                }
            }
            catch
            {
                Write-Message "Warning: Unable to get Monitoring Agent processes running: ($_)" -Vrb
            }

            # Check if task completed.
            if ($ScheduledTask.State -ine "Ready")
            {
                $ErrorMessage = "Exceeded timeout after waiting $($WaitedSec) seconds for the $($TaskName) task to complete (State: $($ScheduledTask.State))."
                Write-Message "Error: $($ErrorMessage)" -Vrb
                throw $ErrorMessage
            }
            else
            {
                Write-Message "Completed the $($TaskName) task after waiting $($WaitedSec) seconds (State: $($ScheduledTask.State))." -Vrb
                $TaskInfo = $ScheduledTask | Get-ScheduledTaskInfo
                if ($TaskInfo)
                {
                    # Note: Currently the MonitoringInstall exit code cannot be used to determine success or failure.
                    Write-Message "The exit code of the $($TaskName) task run at $($TaskInfo.LastRunTime.ToString("u")) is: $($TaskInfo.LastTaskResult)." -Vrb
                }
                else
                {
                    Write-Message "Warning: No task run information could be found from the $($TaskName) task." -Vrb
                }
            }
        }
        else
        {
            Write-Message "Not waiting for the $($TaskName) task to complete." -Vrb
        }
    }
    else
    {
        # Only throw if Monitoring Install task was not found and no skip switch was specified.
        if ($SkipIfNotInstalled)
        {
            Write-Message "No Monitoring Install task found. No attempt to start the Monitoring Agent will be made." -Vrb
        }
        else
        {
            # Throw if the scheduled task is not found.
            throw "No scheduled task with the name '$($TaskName)' was found. Unable to start Monitoring Agent."
        }
    }
}

<#
.SYNOPSIS
    Stop the Monitoring Install task if it is currently running.
#>
function Stop-MonitoringInstallTask([int]$MaxWaitSec = 300)
{
    $TaskPath = Get-MonitoringInstallTaskPath
    $TaskName = "MonitoringInstall"

    Write-Message "Getting the $($TaskName) task..." -Vrb
    $Task = Get-ScheduledTask -TaskPath $TaskPath -TaskName $TaskName -ErrorAction SilentlyContinue
    if (!$Task)
    {
        # Very old installations created the task in the root path.
        Write-Message "Warning: No '$($TaskName)' task found in path '$($TaskPath)'. Looking for task in all paths..." -Vrb
        $Task = Get-ScheduledTask | Where-Object -FilterScript { $_.TaskName -ieq $TaskName } | Select-Object -First 1
    }

    If ($Task)
    {
        Write-Message "The $($TaskName) task was found (State: $($Task.State))." -Vrb
        if ($Task.State -ieq "Running")
        {
            Write-Message "Stopping the running $($TaskName) task..." -Vrb
            $Task | Stop-ScheduledTask
            $ScheduledTask = $Task | Get-ScheduledTask
            Write-Message "Scheduled task stopping (State: $($ScheduledTask.State))." -Vrb

            if ($MaxWaitSec -gt 0)
            {
                Write-Message "Waiting up to $($MaxWaitSec) seconds for the $($TaskName) task to stop..." -Vrb

                [int]$WaitedSec = 0
                while ($ScheduledTask.State -ine "Ready" -and $WaitedSec -lt $MaxWaitSec)
                {
                    Start-Sleep -Seconds 1
                    $WaitedSec += 1
                    $ScheduledTask = $Task | Get-ScheduledTask
                }

                # Check if task completed.
                if ($ScheduledTask.State -ine "Ready")
                {
                    $ErrorMessage = "Exceeded timeout after waiting $($WaitedSec) seconds for the $($TaskName) task to stop (State: $($ScheduledTask.State))."
                    Write-Message "Error: $($ErrorMessage)" -Vrb
                    throw $ErrorMessage
                }
                else
                {
                    Write-Message "Stopped the $($TaskName) task after waiting $($WaitedSec) seconds (State: $($ScheduledTask.State))." -Vrb

                    # Log task info only as additional information. The objective of this function is to stop
                    # the task if it is running, so the result of the task is not important.
                    $TaskInfo = $ScheduledTask | Get-ScheduledTaskInfo -ErrorAction SilentlyContinue
                    if ($TaskInfo)
                    {
                        Write-Message "The exit code of the $($TaskName) task run at $($TaskInfo.LastRunTime.ToString("u")) is: $($TaskInfo.LastTaskResult)." -Vrb
                    }
                    else
                    {
                        Write-Message "Warning: No task run information could be found from the $($TaskName) task." -Vrb
                    }
                }
            }
            else
            {
                Write-Message "Not waiting for the $($TaskName) task to stop." -Vrb
            }
        }
        else
        {
            Write-Message "Not stopping the $($TaskName) task as it is not running." -Vrb
        }
    }
    else
    {
        # If there is no task found, it is not running, and there is no action required to stop it.
        Write-Message "No Monitoring Install task was found, so there is no task to stop." -Vrb
    }
}

<#
.SYNOPSIS
    Returns the names of the Monitoring Agent processes.
#>
function Get-MonitoringAgentProcessNames
{
    return @("MonAgentLauncher", "MonAgentHost", "MonAgentManager", "MonAgentCore");
}

<#
.SYNOPSIS
    Get all Monitoring Agent processes currently running.
#>
function Get-MonitoringAgentProcesses()
{
    $AgentProcesses = @()

    $AgentProcessNames = Get-MonitoringAgentProcessNames
    foreach ($AgentProcessName in $AgentProcessNames)
    {
        $AgentProcess = Get-Process -Name $AgentProcessName -ErrorAction SilentlyContinue
        if ($AgentProcess)
        {
            if (!$AgentProcess.HasExited)
            {
                $AgentProcesses += $AgentProcess
            }
        }
    }

    return $AgentProcesses
}
# SIG # Begin signature block
# MIIjtgYJKoZIhvcNAQcCoIIjpzCCI6MCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCAMYUm4B3753drr
# QK+APSrQIgRuDo+vilvZIQcra7KgX6CCDYUwggYDMIID66ADAgECAhMzAAABUptA
# n1BWmXWIAAAAAAFSMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMTkwNTAyMjEzNzQ2WhcNMjAwNTAyMjEzNzQ2WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQCxp4nT9qfu9O10iJyewYXHlN+WEh79Noor9nhM6enUNbCbhX9vS+8c/3eIVazS
# YnVBTqLzW7xWN1bCcItDbsEzKEE2BswSun7J9xCaLwcGHKFr+qWUlz7hh9RcmjYS
# kOGNybOfrgj3sm0DStoK8ljwEyUVeRfMHx9E/7Ca/OEq2cXBT3L0fVnlEkfal310
# EFCLDo2BrE35NGRjG+/nnZiqKqEh5lWNk33JV8/I0fIcUKrLEmUGrv0CgC7w2cjm
# bBhBIJ+0KzSnSWingXol/3iUdBBy4QQNH767kYGunJeY08RjHMIgjJCdAoEM+2mX
# v1phaV7j+M3dNzZ/cdsz3oDfAgMBAAGjggGCMIIBfjAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQU3f8Aw1sW72WcJ2bo/QSYGzVrRYcw
# VAYDVR0RBE0wS6RJMEcxLTArBgNVBAsTJE1pY3Jvc29mdCBJcmVsYW5kIE9wZXJh
# dGlvbnMgTGltaXRlZDEWMBQGA1UEBRMNMjMwMDEyKzQ1NDEzNjAfBgNVHSMEGDAW
# gBRIbmTlUAXTgqoXNzcitW2oynUClTBUBgNVHR8ETTBLMEmgR6BFhkNodHRwOi8v
# d3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NybC9NaWNDb2RTaWdQQ0EyMDExXzIw
# MTEtMDctMDguY3JsMGEGCCsGAQUFBwEBBFUwUzBRBggrBgEFBQcwAoZFaHR0cDov
# L3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9jZXJ0cy9NaWNDb2RTaWdQQ0EyMDEx
# XzIwMTEtMDctMDguY3J0MAwGA1UdEwEB/wQCMAAwDQYJKoZIhvcNAQELBQADggIB
# AJTwROaHvogXgixWjyjvLfiRgqI2QK8GoG23eqAgNjX7V/WdUWBbs0aIC3k49cd0
# zdq+JJImixcX6UOTpz2LZPFSh23l0/Mo35wG7JXUxgO0U+5drbQht5xoMl1n7/TQ
# 4iKcmAYSAPxTq5lFnoV2+fAeljVA7O43szjs7LR09D0wFHwzZco/iE8Hlakl23ZT
# 7FnB5AfU2hwfv87y3q3a5qFiugSykILpK0/vqnlEVB0KAdQVzYULQ/U4eFEjnis3
# Js9UrAvtIhIs26445Rj3UP6U4GgOjgQonlRA+mDlsh78wFSGbASIvK+fkONUhvj8
# B8ZHNn4TFfnct+a0ZueY4f6aRPxr8beNSUKn7QW/FQmn422bE7KfnqWncsH7vbNh
# G929prVHPsaa7J22i9wyHj7m0oATXJ+YjfyoEAtd5/NyIYaE4Uu0j1EhuYUo5VaJ
# JnMaTER0qX8+/YZRWrFN/heps41XNVjiAawpbAa0fUa3R9RNBjPiBnM0gvNPorM4
# dsV2VJ8GluIQOrJlOvuCrOYDGirGnadOmQ21wPBoGFCWpK56PxzliKsy5NNmAXcE
# x7Qb9vUjY1WlYtrdwOXTpxN4slzIht69BaZlLIjLVWwqIfuNrhHKNDM9K+v7vgrI
# bf7l5/665g0gjQCDCN6Q5sxuttTAEKtJeS/pkpI+DbZ/MIIHejCCBWKgAwIBAgIK
# YQ6Q0gAAAAAAAzANBgkqhkiG9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNV
# BAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jv
# c29mdCBDb3Jwb3JhdGlvbjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlm
# aWNhdGUgQXV0aG9yaXR5IDIwMTEwHhcNMTEwNzA4MjA1OTA5WhcNMjYwNzA4MjEw
# OTA5WjB+MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UE
# BxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSgwJgYD
# VQQDEx9NaWNyb3NvZnQgQ29kZSBTaWduaW5nIFBDQSAyMDExMIICIjANBgkqhkiG
# 9w0BAQEFAAOCAg8AMIICCgKCAgEAq/D6chAcLq3YbqqCEE00uvK2WCGfQhsqa+la
# UKq4BjgaBEm6f8MMHt03a8YS2AvwOMKZBrDIOdUBFDFC04kNeWSHfpRgJGyvnkmc
# 6Whe0t+bU7IKLMOv2akrrnoJr9eWWcpgGgXpZnboMlImEi/nqwhQz7NEt13YxC4D
# dato88tt8zpcoRb0RrrgOGSsbmQ1eKagYw8t00CT+OPeBw3VXHmlSSnnDb6gE3e+
# lD3v++MrWhAfTVYoonpy4BI6t0le2O3tQ5GD2Xuye4Yb2T6xjF3oiU+EGvKhL1nk
# kDstrjNYxbc+/jLTswM9sbKvkjh+0p2ALPVOVpEhNSXDOW5kf1O6nA+tGSOEy/S6
# A4aN91/w0FK/jJSHvMAhdCVfGCi2zCcoOCWYOUo2z3yxkq4cI6epZuxhH2rhKEmd
# X4jiJV3TIUs+UsS1Vz8kA/DRelsv1SPjcF0PUUZ3s/gA4bysAoJf28AVs70b1FVL
# 5zmhD+kjSbwYuER8ReTBw3J64HLnJN+/RpnF78IcV9uDjexNSTCnq47f7Fufr/zd
# sGbiwZeBe+3W7UvnSSmnEyimp31ngOaKYnhfsi+E11ecXL93KCjx7W3DKI8sj0A3
# T8HhhUSJxAlMxdSlQy90lfdu+HggWCwTXWCVmj5PM4TasIgX3p5O9JawvEagbJjS
# 4NaIjAsCAwEAAaOCAe0wggHpMBAGCSsGAQQBgjcVAQQDAgEAMB0GA1UdDgQWBBRI
# bmTlUAXTgqoXNzcitW2oynUClTAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTAL
# BgNVHQ8EBAMCAYYwDwYDVR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBRyLToCMZBD
# uRQFTuHqp8cx0SOJNDBaBgNVHR8EUzBRME+gTaBLhklodHRwOi8vY3JsLm1pY3Jv
# c29mdC5jb20vcGtpL2NybC9wcm9kdWN0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFf
# MDNfMjIuY3JsMF4GCCsGAQUFBwEBBFIwUDBOBggrBgEFBQcwAoZCaHR0cDovL3d3
# dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFf
# MDNfMjIuY3J0MIGfBgNVHSAEgZcwgZQwgZEGCSsGAQQBgjcuAzCBgzA/BggrBgEF
# BQcCARYzaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9kb2NzL3ByaW1h
# cnljcHMuaHRtMEAGCCsGAQUFBwICMDQeMiAdAEwAZQBnAGEAbABfAHAAbwBsAGkA
# YwB5AF8AcwB0AGEAdABlAG0AZQBuAHQALiAdMA0GCSqGSIb3DQEBCwUAA4ICAQBn
# 8oalmOBUeRou09h0ZyKbC5YR4WOSmUKWfdJ5DJDBZV8uLD74w3LRbYP+vj/oCso7
# v0epo/Np22O/IjWll11lhJB9i0ZQVdgMknzSGksc8zxCi1LQsP1r4z4HLimb5j0b
# pdS1HXeUOeLpZMlEPXh6I/MTfaaQdION9MsmAkYqwooQu6SpBQyb7Wj6aC6VoCo/
# KmtYSWMfCWluWpiW5IP0wI/zRive/DvQvTXvbiWu5a8n7dDd8w6vmSiXmE0OPQvy
# CInWH8MyGOLwxS3OW560STkKxgrCxq2u5bLZ2xWIUUVYODJxJxp/sfQn+N4sOiBp
# mLJZiWhub6e3dMNABQamASooPoI/E01mC8CzTfXhj38cbxV9Rad25UAqZaPDXVJi
# hsMdYzaXht/a8/jyFqGaJ+HNpZfQ7l1jQeNbB5yHPgZ3BtEGsXUfFL5hYbXw3MYb
# BL7fQccOKO7eZS/sl/ahXJbYANahRr1Z85elCUtIEJmAH9AAKcWxm6U/RXceNcbS
# oqKfenoi+kiVH6v7RyOA9Z74v2u3S5fi63V4GuzqN5l5GEv/1rMjaHXmr/r8i+sL
# gOppO6/8MO0ETI7f33VtY5E90Z1WTk+/gFcioXgRMiF670EKsT/7qMykXcGhiJtX
# cVZOSEXAQsmbdlsKgEhr/Xmfwb1tbWrJUnMTDXpQzTGCFYcwghWDAgEBMIGVMH4x
# CzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRt
# b25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01p
# Y3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTECEzMAAAFSm0CfUFaZdYgAAAAA
# AVIwDQYJYIZIAWUDBAIBBQCggdowGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQw
# HAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIGHq
# VgJt7z+LG2xseWjeGQCu0ZaiCEZB46BOuH+flas5MG4GCisGAQQBgjcCAQwxYDBe
# oECAPgBBAHUAdABvAFUAcABnAHIAYQBkAGUAQwBvAG4AZgBpAGcAQQBvAHMAUwBl
# AHIAdgBpAGMAZQAuAHAAcwAxoRqAGGh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbTAN
# BgkqhkiG9w0BAQEFAASCAQBtQI9WLoLu02qkwzFmGB4J2Wc3W9nsiKiBW+fTt0zt
# 6AF3L2msgMVZtdArstN+hy2RKEiOdwRyWOtgWmNNBTEh3us8XtSwg4IpS4YzSg2X
# bCHxyLqQsbQioKapv35MQvVK4PMriQ2Ad9ha1KPq1qmCf4VojY1Dx/HI5MrRG/4q
# BenRMIwsTt00Hn9WUlFjUdTXFCoEFBxrS9qOQgwRQZ/qaE5PNarZt5YiJr0RBBV2
# GTDqouc3QY/eHm1QOA+CnYwGMimXdK3FyQYXEanM8vzKG/C+dPgwsR5YXyIjNn37
# JSOjIBKtvBjFIVqkoCTpLFG0Kdcj8BosQu/MQ8LPaaM6oYIS5TCCEuEGCisGAQQB
# gjcDAwExghLRMIISzQYJKoZIhvcNAQcCoIISvjCCEroCAQMxDzANBglghkgBZQME
# AgEFADCCAVEGCyqGSIb3DQEJEAEEoIIBQASCATwwggE4AgEBBgorBgEEAYRZCgMB
# MDEwDQYJYIZIAWUDBAIBBQAEIG5YS4kWyUPSGqEkjRliRifCsRFbKvlQYXntdlF2
# xY+1AgZdsimFxDcYEzIwMTkxMjAzMDMyMzQ2LjMwNFowBIACAfSggdCkgc0wgcox
# CzAJBgNVBAYTAlVTMQswCQYDVQQIEwJXQTEQMA4GA1UEBxMHUmVkbW9uZDEeMBwG
# A1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMS0wKwYDVQQLEyRNaWNyb3NvZnQg
# SXJlbGFuZCBPcGVyYXRpb25zIExpbWl0ZWQxJjAkBgNVBAsTHVRoYWxlcyBUU1Mg
# RVNOOjA4NDItNEJFNi1DMjlBMSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFt
# cCBTZXJ2aWNloIIOPDCCBPEwggPZoAMCAQICEzMAAAEJfoK9HnvTYSIAAAAAAQkw
# DQYJKoZIhvcNAQELBQAwfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0
# b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3Jh
# dGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwHhcN
# MTkxMDIzMjMxOTE0WhcNMjEwMTIxMjMxOTE0WjCByjELMAkGA1UEBhMCVVMxCzAJ
# BgNVBAgTAldBMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQg
# Q29ycG9yYXRpb24xLTArBgNVBAsTJE1pY3Jvc29mdCBJcmVsYW5kIE9wZXJhdGlv
# bnMgTGltaXRlZDEmMCQGA1UECxMdVGhhbGVzIFRTUyBFU046MDg0Mi00QkU2LUMy
# OUExJTAjBgNVBAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZpY2UwggEiMA0G
# CSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQC4wyEQZQIHGgkuQ/1UnrdT7jela35b
# XCpB9jYSlc+bFiXDs1LLX1Z79nkL4ZUfj+wtOrN7OyEqXV2fgiwdi0uZ/W31ozc6
# OTcY3gF+yGp0ZPTCA463zSdBCSpHpGG6c7XyYXig8cRPQuO7Rv5dFpxpPlDypMty
# 1+OlgFcZUYoMSQabW4QUu87yM3hZ7MTuTLZsuKx7+dDzJxIAbGwecCNSsPd0D2zE
# /WwR+LCInse+4UFrrYYPwJKsPMifO3UvmCF7Ld/rmyLQbGdrR6xwXMmzc4HBBOT5
# wyta6Op0CYdnUensxOJ/qgENw/fNTWPXfggms8DLsOJthTYrG2QkDSr3AgMBAAGj
# ggEbMIIBFzAdBgNVHQ4EFgQUpaSSc0yDQvxCcYjn1KjvNj9uSUYwHwYDVR0jBBgw
# FoAU1WM6XIoxkPNDe3xGG8UzaFqFbVUwVgYDVR0fBE8wTTBLoEmgR4ZFaHR0cDov
# L2NybC5taWNyb3NvZnQuY29tL3BraS9jcmwvcHJvZHVjdHMvTWljVGltU3RhUENB
# XzIwMTAtMDctMDEuY3JsMFoGCCsGAQUFBwEBBE4wTDBKBggrBgEFBQcwAoY+aHR0
# cDovL3d3dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0cy9NaWNUaW1TdGFQQ0FfMjAx
# MC0wNy0wMS5jcnQwDAYDVR0TAQH/BAIwADATBgNVHSUEDDAKBggrBgEFBQcDCDAN
# BgkqhkiG9w0BAQsFAAOCAQEAOFiHA4sHR0uQEq6TTC5G/8luBryoOQ+kFuJU5iXA
# TSXe0BrdSVzlKq3qkE6EHvrcXFgzl1KHLFi2bgsh8JiPlDLHfLmfTkFNxLEHr35M
# FTPwa9J3U4afrCk7aYsYIE0JsiDF3+RY24HHh6Sw0njIQ1K8yH5PC5+evkj+lh5k
# 6mhQf472m8Vc/fLPPtOsdyeczOEw5citXv1zUINJWwHy2m3eQl6ulxA3sgYpAzdm
# +NQtf/oi0yQ6QmkQSmd+rpbgk6tqi1j/iOg0ECRmmK0wtvfaEvjwxU67Ykxwyg18
# 8kRLhAAz6d7/S/FGrq+v07zCVJxxr0ZEoCtaTFl7zJ/qaDCCBnEwggRZoAMCAQIC
# CmEJgSoAAAAAAAIwDQYJKoZIhvcNAQELBQAwgYgxCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xMjAwBgNVBAMTKU1pY3Jvc29mdCBSb290IENlcnRp
# ZmljYXRlIEF1dGhvcml0eSAyMDEwMB4XDTEwMDcwMTIxMzY1NVoXDTI1MDcwMTIx
# NDY1NVowfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNV
# BAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQG
# A1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwggEiMA0GCSqGSIb3
# DQEBAQUAA4IBDwAwggEKAoIBAQCpHQ28dxGKOiDs/BOX9fp/aZRrdFQQ1aUKAIKF
# ++18aEssX8XD5WHCdrc+Zitb8BVTJwQxH0EbGpUdzgkTjnxhMFmxMEQP8WCIhFRD
# DNdNuDgIs0Ldk6zWczBXJoKjRQ3Q6vVHgc2/JGAyWGBG8lhHhjKEHnRhZ5FfgVSx
# z5NMksHEpl3RYRNuKMYa+YaAu99h/EbBJx0kZxJyGiGKr0tkiVBisV39dx898Fd1
# rL2KQk1AUdEPnAY+Z3/1ZsADlkR+79BL/W7lmsqxqPJ6Kgox8NpOBpG2iAg16Hgc
# sOmZzTznL0S6p/TcZL2kAcEgCZN4zfy8wMlEXV4WnAEFTyJNAgMBAAGjggHmMIIB
# 4jAQBgkrBgEEAYI3FQEEAwIBADAdBgNVHQ4EFgQU1WM6XIoxkPNDe3xGG8UzaFqF
# bVUwGQYJKwYBBAGCNxQCBAweCgBTAHUAYgBDAEEwCwYDVR0PBAQDAgGGMA8GA1Ud
# EwEB/wQFMAMBAf8wHwYDVR0jBBgwFoAU1fZWy4/oolxiaNE9lJBb186aGMQwVgYD
# VR0fBE8wTTBLoEmgR4ZFaHR0cDovL2NybC5taWNyb3NvZnQuY29tL3BraS9jcmwv
# cHJvZHVjdHMvTWljUm9vQ2VyQXV0XzIwMTAtMDYtMjMuY3JsMFoGCCsGAQUFBwEB
# BE4wTDBKBggrBgEFBQcwAoY+aHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraS9j
# ZXJ0cy9NaWNSb29DZXJBdXRfMjAxMC0wNi0yMy5jcnQwgaAGA1UdIAEB/wSBlTCB
# kjCBjwYJKwYBBAGCNy4DMIGBMD0GCCsGAQUFBwIBFjFodHRwOi8vd3d3Lm1pY3Jv
# c29mdC5jb20vUEtJL2RvY3MvQ1BTL2RlZmF1bHQuaHRtMEAGCCsGAQUFBwICMDQe
# MiAdAEwAZQBnAGEAbABfAFAAbwBsAGkAYwB5AF8AUwB0AGEAdABlAG0AZQBuAHQA
# LiAdMA0GCSqGSIb3DQEBCwUAA4ICAQAH5ohRDeLG4Jg/gXEDPZ2joSFvs+umzPUx
# vs8F4qn++ldtGTCzwsVmyWrf9efweL3HqJ4l4/m87WtUVwgrUYJEEvu5U4zM9GAS
# inbMQEBBm9xcF/9c+V4XNZgkVkt070IQyK+/f8Z/8jd9Wj8c8pl5SpFSAK84Dxf1
# L3mBZdmptWvkx872ynoAb0swRCQiPM/tA6WWj1kpvLb9BOFwnzJKJ/1Vry/+tuWO
# M7tiX5rbV0Dp8c6ZZpCM/2pif93FSguRJuI57BlKcWOdeyFtw5yjojz6f32WapB4
# pm3S4Zz5Hfw42JT0xqUKloakvZ4argRCg7i1gJsiOCC1JeVk7Pf0v35jWSUPei45
# V3aicaoGig+JFrphpxHLmtgOR5qAxdDNp9DvfYPw4TtxCd9ddJgiCGHasFAeb73x
# 4QDf5zEHpJM692VHeOj4qEir995yfmFrb3epgcunCaw5u+zGy9iCtHLNHfS4hQEe
# gPsbiSpUObJb2sgNVZl6h3M7COaYLeqN4DMuEin1wC9UJyH3yKxO2ii4sanblrKn
# QqLJzxlBTeCG+SqaoxFmMNO7dDJL32N79ZmKLxvHIa9Zta7cRDyXUHHXodLFVeNp
# 3lfB0d4wwP3M5k37Db9dT+mdHhk4L7zPWAUu7w2gUDXa7wknHNWzfjUeCLraNtvT
# X4/edIhJEqGCAs4wggI3AgEBMIH4oYHQpIHNMIHKMQswCQYDVQQGEwJVUzELMAkG
# A1UECBMCV0ExEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBD
# b3Jwb3JhdGlvbjEtMCsGA1UECxMkTWljcm9zb2Z0IElyZWxhbmQgT3BlcmF0aW9u
# cyBMaW1pdGVkMSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVTTjowODQyLTRCRTYtQzI5
# QTElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgU2VydmljZaIjCgEBMAcG
# BSsOAwIaAxUACsG8ux1nIgl0fkctgBa2jzpieACggYMwgYCkfjB8MQswCQYDVQQG
# EwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwG
# A1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQg
# VGltZS1TdGFtcCBQQ0EgMjAxMDANBgkqhkiG9w0BAQUFAAIFAOGQEeowIhgPMjAx
# OTEyMDMwNjQyNTBaGA8yMDE5MTIwNDA2NDI1MFowdzA9BgorBgEEAYRZCgQBMS8w
# LTAKAgUA4ZAR6gIBADAKAgEAAgIcpQIB/zAHAgEAAgISgTAKAgUA4ZFjagIBADA2
# BgorBgEEAYRZCgQCMSgwJjAMBgorBgEEAYRZCgMCoAowCAIBAAIDB6EgoQowCAIB
# AAIDAYagMA0GCSqGSIb3DQEBBQUAA4GBAJvNIkihpoOGGk5irLp9B9I3hcLfYmgg
# NAkFm7UvCRFGKYDIibmklV06rsSeLPLlpLAQ5aNiLsdGDMSYEpfY9LIjTPBTSVlB
# /FV/rYT998NEWtyewy8bIbt+LKHal9MPZb7T5LivwBMDnjimJMeyR/9ZV0pSWMo0
# ToCsmRgn+HUGMYIDDTCCAwkCAQEwgZMwfDELMAkGA1UEBhMCVVMxEzARBgNVBAgT
# Cldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29m
# dCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENB
# IDIwMTACEzMAAAEJfoK9HnvTYSIAAAAAAQkwDQYJYIZIAWUDBAIBBQCgggFKMBoG
# CSqGSIb3DQEJAzENBgsqhkiG9w0BCRABBDAvBgkqhkiG9w0BCQQxIgQgB/E5s1gK
# IUyNN00aY/r7K0iaZ4fy90eZ++mS+vreK6IwgfoGCyqGSIb3DQEJEAIvMYHqMIHn
# MIHkMIG9BCCCVPhhBhtKMjxiE2/c3YdDcB3+1eTbswVjXf+epZ1SjzCBmDCBgKR+
# MHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMT
# HU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwAhMzAAABCX6CvR5702EiAAAA
# AAEJMCIEIP6gKQr5P9fFgetXZqfUxtD9hmvSM3VJ04d3hbssuEfpMA0GCSqGSIb3
# DQEBCwUABIIBACOMoLPE9werLuRTHGFunQrP6cNFQMx+JiboPKaw0USibJOM3R8O
# YIy5ugX9BcEUjbp3D3/OyNkbKeyJ3XjLHA7Rm7NksK67Ze6sG0pkvv4awcbKcFEO
# WpgsQ9dlsKkWn8p+aEl6ibxxxFbu8m87ju/P5Nne/V0hv141H5BKPr+nk+HXpJUr
# q/VasUZFSa3j9LArYkmUeZQyvx1WrdSqwgqlT1xeTWp1lEtXaOplzJR2jpoMeSsE
# mW6TCrB64bW4M98/Gs01KgPpAu1Lm/a/rEAE+56eGE4sxx9W41l8Sd1M1J5nSAQA
# BEoo9BhdhPMs03Sce/Bkrmd2BgpEgEoWB6s=
# SIG # End signature block
