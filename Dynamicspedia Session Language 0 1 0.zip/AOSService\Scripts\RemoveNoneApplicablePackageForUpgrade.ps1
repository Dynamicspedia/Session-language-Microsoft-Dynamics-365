﻿
$blackListedPackage = (
"dynamicsax-appfoundationtestcommon",
"dynamicsax-appfoundationtestcommon-compile",
"dynamicsax-appfoundationtestcommon-develop",
"dynamicsax-appfoundationtestcommon-formadaptor",
"dynamicsax-application-applicationruntime",
"dynamicsax-applicationfoundation-compile",
"dynamicsax-applicationfoundation-develop",
"dynamicsax-applicationfoundation-formadaptor",
"dynamicsax-applicationfoundationformadaptor-compile",
"dynamicsax-applicationfoundationformadaptor-develop",
"dynamicsax-applicationfoundationformadaptor-formadaptor",
"dynamicsax-applicationfoundationunittests",
"dynamicsax-applicationfoundationunittests-compile",
"dynamicsax-applicationfoundationunittests-develop",
"dynamicsax-applicationfoundationunittests-formadaptor",
"dynamicsax-applicationplatform-compile",
"dynamicsax-applicationplatform-develop",
"dynamicsax-applicationplatform-formadaptor",
"dynamicsax-applicationplatformformadaptor-compile",
"dynamicsax-applicationplatformformadaptor-develop",
"dynamicsax-applicationplatformformadaptor-formadaptor",
"dynamicsax-applicationstaging",
"dynamicsax-applicationstaging-compile",
"dynamicsax-applicationstaging-develop",
"dynamicsax-applicationstagingformadaptor",
"dynamicsax-applicationstaging-formadaptor",
"dynamicsax-applicationstagingformadaptor-compile",
"dynamicsax-applicationstagingformadaptor-develop",
"dynamicsax-applicationstagingformadaptor-formadaptor",
"dynamicsax-applicationstagingtests",
"dynamicsax-applicationstagingtests-compile",
"dynamicsax-applicationstagingtests-develop",
"dynamicsax-applicationstagingtests-formadaptor",
"dynamicsax-applicationsuite-compile",
"dynamicsax-applicationsuite-develop",
"dynamicsax-applicationsuite-formadaptor",
"dynamicsax-applicationsuiteformadaptor-compile",
"dynamicsax-applicationsuiteformadaptor-develop",
"dynamicsax-applicationsuiteformadaptor-formadaptor",
"dynamicsax-applicationworkspaces-compile",
"dynamicsax-applicationworkspaces-develop",
"dynamicsax-applicationworkspacesformadaptor",
"dynamicsax-applicationworkspaces-formadaptor",
"dynamicsax-applicationworkspacesformadaptor-compile",
"dynamicsax-applicationworkspacesformadaptor-develop",
"dynamicsax-applicationworkspacesformadaptor-formadaptor",
"dynamicsax-applicationworkspacestests",
"dynamicsax-applicationworkspacestests-compile",
"dynamicsax-applicationworkspacestests-develop",
"dynamicsax-applicationworkspacestests-formadaptor",
"dynamicsax-appplatformtestcommon",
"dynamicsax-appplatformtestcommon-compile",
"dynamicsax-appplatformtestcommon-develop",
"dynamicsax-appplatformtestcommon-formadaptor",
"dynamicsax-appsuitetestcommon",
"dynamicsax-appsuitetestcommon-compile",
"dynamicsax-appsuitetestcommon-develop",
"dynamicsax-appsuitetestcommon-formadaptor",
"dynamicsax-budgetstaging",
"dynamicsax-budgetstaging-compile",
"dynamicsax-budgetstaging-develop",
"dynamicsax-budgetstagingformadaptor",
"dynamicsax-budgetstaging-formadaptor",
"dynamicsax-budgetstagingformadaptor-compile",
"dynamicsax-budgetstagingformadaptor-develop",
"dynamicsax-budgetstagingformadaptor-formadaptor",
"dynamicsax-budgetstagingtests",
"dynamicsax-budgetstagingtests-compile",
"dynamicsax-budgetstagingtests-develop",
"dynamicsax-budgetstagingtests-formadaptor",
"dynamicsax-calendar-compile",
"dynamicsax-calendar-develop",
"dynamicsax-calendarformadaptor",
"dynamicsax-calendar-formadaptor",
"dynamicsax-calendarformadaptor-compile",
"dynamicsax-calendarformadaptor-develop",
"dynamicsax-calendarformadaptor-formadaptor",
"dynamicsax-calendartests",
"dynamicsax-calendartests-compile",
"dynamicsax-calendartests-develop",
"dynamicsax-calendartests-formadaptor",
"dynamicsax-cirfoundationtests",
"dynamicsax-cirfoundationtests-compile",
"dynamicsax-cirfoundationtests-develop",
"dynamicsax-cirfoundationtests-formadaptor",
"dynamicsax-costaccounting",
"dynamicsax-costaccounting-compile",
"dynamicsax-costaccounting-develop",
"dynamicsax-costaccounting-formadaptor",
"dynamicsax-costaccountingformadaptor",
"dynamicsax-costaccountingformadaptor-compile",
"dynamicsax-costaccountingformadaptor-develop",
"dynamicsax-costaccountingformadaptor-formadaptor",
"dynamicsax-costaccountingtests",
"dynamicsax-costaccountingtests-compile",
"dynamicsax-costaccountingtests-develop",
"dynamicsax-costaccountingtests-formadaptor",
"dynamicsax-costaccountingax",
"dynamicsax-costaccountingax-compile",
"dynamicsax-costaccountingax-develop",
"dynamicsax-costaccountingax-formadaptor",
"dynamicsax-costaccountingaxformadaptor",
"dynamicsax-costaccountingaxformadaptor-compile",
"dynamicsax-costaccountingaxformadaptor-develop",
"dynamicsax-costaccountingaxformadaptor-formadaptor",
"dynamicsax-costaccountingaxtests",
"dynamicsax-costaccountingaxtests-compile",
"dynamicsax-costaccountingaxtests-develop",
"dynamicsax-costaccountingaxtests-formadaptor",
"dynamicsax-currency-compile",
"dynamicsax-currency-develop",
"dynamicsax-currencyformadaptor",
"dynamicsax-currency-formadaptor",
"dynamicsax-currencyformadaptor-compile",
"dynamicsax-currencyformadaptor-develop",
"dynamicsax-currencyformadaptor-formadaptor",
"dynamicsax-customeracceptancetests-compile",
"dynamicsax-customeracceptancetests-develop",
"dynamicsax-customeracceptancetests-formadaptor",
"dynamicsax-data-contoso",
"dynamicsax-data-demodata",
"dynamicsax-data-demovolumedata",
"dynamicsax-data-empty",
"dynamicsax-data-empty-platform",
"dynamicsax-dataimpexpapplication-compile",
"dynamicsax-dataimpexpapplication-develop",
"dynamicsax-dataimpexpapplication-formadaptor",
"dynamicsax-demodatasuite",
"dynamicsax-demodatasuite-compile",
"dynamicsax-demodatasuite-develop",
"dynamicsax-demodatasuite-formadaptor",
"dynamicsax-devtoolscustomizations",
"dynamicsax-devtoolscustomizations2",
"dynamicsax-devtoolscustomizations2-compile",
"dynamicsax-devtoolscustomizations2-develop",
"dynamicsax-devtoolscustomizations2-formadaptor",
"dynamicsax-devtoolscustomizations-compile",
"dynamicsax-devtoolscustomizations-develop",
"dynamicsax-devtoolscustomizations-formadaptor",
"dynamicsax-devtoolstestmodel",
"dynamicsax-devtoolstestmodel2",
"dynamicsax-devtoolstestmodel2-compile",
"dynamicsax-devtoolstestmodel2-develop",
"dynamicsax-devtoolstestmodel2-formadaptor",
"dynamicsax-devtoolstestmodel-compile",
"dynamicsax-devtoolstestmodel-develop",
"dynamicsax-devtoolstestmodel-formadaptor",
"dynamicsax-dimensions-compile",
"dynamicsax-dimensions-develop",
"dynamicsax-dimensionsformadaptor",
"dynamicsax-dimensions-formadaptor",
"dynamicsax-dimensionsformadaptor-compile",
"dynamicsax-dimensionsformadaptor-develop",
"dynamicsax-dimensionsformadaptor-formadaptor",
"dynamicsax-dimensionstestcommon",
"dynamicsax-dimensionstestcommon-compile",
"dynamicsax-dimensionstestcommon-develop",
"dynamicsax-dimensionstestcommon-formadaptor",
"dynamicsax-dimensionstests",
"dynamicsax-dimensionstests-compile",
"dynamicsax-dimensionstests-develop",
"dynamicsax-dimensionstests-formadaptor",
"dynamicsax-directory-compile",
"dynamicsax-directory-develop",
"dynamicsax-directory-formadaptor",
"dynamicsax-directoryformadaptor-compile",
"dynamicsax-directoryformadaptor-develop",
"dynamicsax-directoryformadaptor-formadaptor",
"dynamicsax-directorytests",
"dynamicsax-directorytests-compile",
"dynamicsax-directorytests-develop",
"dynamicsax-directorytests-formadaptor",
"dynamicsax-dispatchservice",
"dynamicsax-electronicreporting-compile",
"dynamicsax-electronicreporting-develop",
"dynamicsax-electronicreporting-formadaptor",
"dynamicsax-electronicreportingtestcommon",
"dynamicsax-electronicreportingtestcommon-compile",
"dynamicsax-electronicreportingtestcommon-develop",
"dynamicsax-electronicreportingtestcommon-formadaptor",
"dynamicsax-electronicreportingtests",
"dynamicsax-electronicreportingtests-compile",
"dynamicsax-electronicreportingtests-develop",
"dynamicsax-electronicreportingtests-formadaptor",
"dynamicsax-financialaccountingworkload",
"dynamicsax-financialaccountingworkload-compile",
"dynamicsax-financialaccountingworkload-develop",
"dynamicsax-financialaccountingworkload-formadaptor",
"dynamicsax-financialaccounting",
"dynamicsax-financialaccounting-compile",
"dynamicsax-financialaccounting-develop",
"dynamicsax-financialaccounting-formadaptor",
"dynamicsax-financialreportingadaptors",
"dynamicsax-financialreportingadaptors-compile",
"dynamicsax-financialreportingadaptors-develop",
"dynamicsax-financialreportingadaptors-formadaptor",
"dynamicsax-financialreporting-compile",
"dynamicsax-financialreporting-develop",
"dynamicsax-financialreporting-formadaptor",
"dynamicsax-financialreportingtestcommon",
"dynamicsax-financialreportingtestcommon-compile",
"dynamicsax-financialreportingtestcommon-develop",
"dynamicsax-financialreportingtestcommon-formadaptor",
"dynamicsax-financialreportingtests",
"dynamicsax-financialreportingtests-compile",
"dynamicsax-financialreportingtests-develop",
"dynamicsax-financialreportingtests-formadaptor",
"dynamicsax-fiscalbooks-compile",
"dynamicsax-fiscalbooks-develop",
"dynamicsax-fiscalbooksformadaptor",
"dynamicsax-fiscalbooks-formadaptor",
"dynamicsax-fiscalbooksformadaptor-compile",
"dynamicsax-fiscalbooksformadaptor-develop",
"dynamicsax-fiscalbooksformadaptor-formadaptor",
"dynamicsax-fiscalbookstests",
"dynamicsax-fiscalbookstests-compile",
"dynamicsax-fiscalbookstests-develop",
"dynamicsax-fiscalbookstests-formadaptor",
"dynamicsax-fleetmanagement-compile",
"dynamicsax-fleetmanagement-develop",
"dynamicsax-fleetmanagementextension-compile",
"dynamicsax-fleetmanagementextension-develop",
"dynamicsax-fleetmanagementextension-formadaptor",
"dynamicsax-fleetmanagement-formadaptor",
"dynamicsax-fleetmanagementunittests-compile",
"dynamicsax-fleetmanagementunittests-develop",
"dynamicsax-fleetmanagementunittests-formadaptor",
"dynamicsax-foundationtest",
"dynamicsax-foundationtestcommon",
"dynamicsax-foundationtestcommon-compile",
"dynamicsax-foundationtestcommon-develop",
"dynamicsax-foundationtestcommon-formadaptor",
"dynamicsax-foundationtest-compile",
"dynamicsax-foundationtest-develop",
"dynamicsax-foundationtest-formadaptor",
"dynamicsax-generalledger-compile",
"dynamicsax-generalledger-develop",
"dynamicsax-generalledgerformadaptor",
"dynamicsax-generalledger-formadaptor",
"dynamicsax-generalledgerformadaptor-compile",
"dynamicsax-generalledgerformadaptor-develop",
"dynamicsax-generalledgerformadaptor-formadaptor",
"dynamicsax-generalledgertests",
"dynamicsax-generalledgertests-compile",
"dynamicsax-generalledgertests-develop",
"dynamicsax-generalledgertests-formadaptor",
"dynamicsax-gfmtests",
"dynamicsax-gfmtests-compile",
"dynamicsax-gfmtests-develop",
"dynamicsax-gfmtests-formadaptor",
"dynamicsax-hcmtests",
"dynamicsax-hcmtests-compile",
"dynamicsax-hcmtests-develop",
"dynamicsax-hcmtests-formadaptor",
"dynamicsax-ledger-compile",
"dynamicsax-ledger-develop",
"dynamicsax-ledger-formadaptor",
"dynamicsax-ledgerformadaptor-compile",
"dynamicsax-ledgerformadaptor-develop",
"dynamicsax-ledgerformadaptor-formadaptor",
"dynamicsax-ledgertests",
"dynamicsax-ledgertests-compile",
"dynamicsax-ledgertests-develop",
"dynamicsax-ledgertests-formadaptor",
"dynamicsax-measurement-compile",
"dynamicsax-measurement-develop",
"dynamicsax-measurementformadaptor",
"dynamicsax-measurement-formadaptor",
"dynamicsax-measurementformadaptor-compile",
"dynamicsax-measurementformadaptor-develop",
"dynamicsax-measurementformadaptor-formadaptor",
"dynamicsax-measurementtests",
"dynamicsax-measurementtests-compile",
"dynamicsax-measurementtests-develop",
"dynamicsax-measurementtests-formadaptor",
"dynamicsax-meta-application-development",
"dynamicsax-meta-application-runtime",
"dynamicsax-meta-businessappplatform-development",
"dynamicsax-meta-businessappplatform-runtime",
"dynamicsax-meta-financialaccounting-development",
"dynamicsax-meta-financialaccounting-runtime",
"dynamicsax-meta-onebox-app-development",
"dynamicsax-meta-onebox-app-runtime",
"dynamicsax-meta-onebox-financialaccounting-development",
"dynamicsax-meta-onebox-financialaccounting-runtime",
"dynamicsax-meta-onebox-platform-development",
"dynamicsax-meta-onebox-platform-runtime",
"dynamicsax-meta-platform-development",
"dynamicsax-meta-platform-runtime",
"dynamicsax-OrchestrationPlugins",
"dynamicsax-organization-compile",
"dynamicsax-organization-develop",
"dynamicsax-organizationformadaptor",
"dynamicsax-organization-formadaptor",
"dynamicsax-organizationformadaptor-compile",
"dynamicsax-organizationformadaptor-develop",
"dynamicsax-organizationformadaptor-formadaptor",
"dynamicsax-organizationtests",
"dynamicsax-organizationtests-compile",
"dynamicsax-organizationtests-develop",
"dynamicsax-organizationtests-formadaptor",
"dynamicsax-payroll-compile",
"dynamicsax-payroll-develop",
"dynamicsax-payrollformadaptor",
"dynamicsax-payroll-formadaptor",
"dynamicsax-payrollformadaptor-compile",
"dynamicsax-payrollformadaptor-develop",
"dynamicsax-payrollformadaptor-formadaptor",
"dynamicsax-payrolltests",
"dynamicsax-payrolltests-compile",
"dynamicsax-payrolltests-develop",
"dynamicsax-payrolltests-formadaptor",
"dynamicsax-performancetest",
"dynamicsax-performancetest-compile",
"dynamicsax-performancetest-develop",
"dynamicsax-performancetest-formadaptor",
"dynamicsax-performancetool",
"dynamicsax-performancetool-compile",
"dynamicsax-performancetool-develop",
"dynamicsax-performancetool-formadaptor",
"dynamicsax-performancetoolunittests",
"dynamicsax-performancetoolunittests-compile",
"dynamicsax-performancetoolunittests-develop",
"dynamicsax-performancetoolunittests-formadaptor",
"dynamicsax-policy-compile",
"dynamicsax-policy-develop",
"dynamicsax-policyformadaptor",
"dynamicsax-policy-formadaptor",
"dynamicsax-policyformadaptor-compile",
"dynamicsax-policyformadaptor-develop",
"dynamicsax-policyformadaptor-formadaptor",
"dynamicsax-policytests",
"dynamicsax-policytests-compile",
"dynamicsax-policytests-develop",
"dynamicsax-policytests-formadaptor",
"dynamicsax-primitivetest",
"dynamicsax-primitivetest-compile",
"dynamicsax-primitivetest-develop",
"dynamicsax-primitivetest-formadaptor",
"dynamicsax-productconfiguration",
"dynamicsax-publicsector-compile",
"dynamicsax-publicsector-develop",
"dynamicsax-publicsectorformadaptor",
"dynamicsax-publicsector-formadaptor",
"dynamicsax-publicsectorformadaptor-compile",
"dynamicsax-publicsectorformadaptor-develop",
"dynamicsax-publicsectorformadaptor-formadaptor",
"dynamicsax-publicsectortests",
"dynamicsax-publicsectortests-compile",
"dynamicsax-publicsectortests-develop",
"dynamicsax-publicsectortests-formadaptor",
"dynamicsax-retailtests",
"dynamicsax-retailtests-compile",
"dynamicsax-retailtests-develop",
"dynamicsax-retailtests-formadaptor",
"dynamicsax-scmtests",
"dynamicsax-scmtests-compile",
"dynamicsax-scmtests-develop",
"dynamicsax-scmtests-formadaptor",
"dynamicsax-scmteststaging",
"dynamicsax-scmteststaging-compile",
"dynamicsax-scmteststaging-develop",
"dynamicsax-scmteststaging-formadaptor",
"dynamicsax-servertests",
"dynamicsax-servertests-compile",
"dynamicsax-servertests-develop",
"dynamicsax-servertests-formadaptor",
"dynamicsax-sitests",
"dynamicsax-sitests-compile",
"dynamicsax-sitests-develop",
"dynamicsax-sitests-formadaptor",
"dynamicsax-sourcedocumentation-compile",
"dynamicsax-sourcedocumentation-develop",
"dynamicsax-sourcedocumentationformadaptor",
"dynamicsax-sourcedocumentation-formadaptor",
"dynamicsax-sourcedocumentationformadaptor-compile",
"dynamicsax-sourcedocumentationformadaptor-develop",
"dynamicsax-sourcedocumentationformadaptor-formadaptor",
"dynamicsax-sourcedocumentationtypes-compile",
"dynamicsax-sourcedocumentationtypes-develop",
"dynamicsax-sourcedocumentationtypes-formadaptor",
"dynamicsax-sourcedocumentationtests",
"dynamicsax-sourcedocumentationtests-compile",
"dynamicsax-sourcedocumentationtests-develop",
"dynamicsax-sourcedocumentationtests-formadaptor",
"dynamicsax-subledger-compile",
"dynamicsax-subledger-develop",
"dynamicsax-subledgerformadaptor",
"dynamicsax-subledger-formadaptor",
"dynamicsax-subledgerformadaptor-compile",
"dynamicsax-subledgerformadaptor-develop",
"dynamicsax-subledgerformadaptor-formadaptor",
"dynamicsax-sysfake",
"dynamicsax-sysfake-compile",
"dynamicsax-sysfake-develop",
"dynamicsax-sysfake-formadaptor",
"dynamicsax-tax-compile",
"dynamicsax-tax-develop",
"dynamicsax-taxformadaptor",
"dynamicsax-tax-formadaptor",
"dynamicsax-taxformadaptor-compile",
"dynamicsax-taxformadaptor-develop",
"dynamicsax-taxformadaptor-formadaptor",
"dynamicsax-test",
"dynamicsax-test-compile",
"dynamicsax-test-develop",
"dynamicsax-testessentials-compile",
"dynamicsax-testessentials-develop",
"dynamicsax-testessentials-formadaptor",
"dynamicsax-test-formadaptor",
"dynamicsax-tutorial-compile",
"dynamicsax-tutorial-develop",
"dynamicsax-tutorial-formadaptor",
"dynamicsax-unitofmeasure-compile",
"dynamicsax-unitofmeasure-develop",
"dynamicsax-unitofmeasure-formadaptor",
"dynamicsax-unitofmeasureformadaptor-compile",
"dynamicsax-unitofmeasureformadaptor-develop",
"dynamicsax-unitofmeasureformadaptor-formadaptor",
"dynamicsax-unittests",
"dynamicsax-unittests-compile",
"dynamicsax-unittests-develop",
"dynamicsax-unittests-formadaptor",
"dynamicsax-upgrade",
"dynamicsax-upgrade-compile",
"dynamicsax-upgrade-develop",
"dynamicsax-upgrade-formadaptor")

$sourcePath = [IO.Path]::Combine($(split-Path -parent $PSScriptRoot), "Packages")
$files=get-childitem -Path:$sourcePath *.nupkg
foreach ($file in $files) 
{
    $fileName =  ($file.BaseName).Split(".")[0]
    if ($blackListedPackage -contains "$fileName")
    {
        write-output "Removing $file from packaging folder"
        remove-item $file.FullName
    }
}

# SIG # Begin signature block
# MIIjswYJKoZIhvcNAQcCoIIjpDCCI6ACAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCBQ/MgBoh93T74S
# oGaMvj2lmJHriRwzOBJxd3oxs0OkKKCCDYUwggYDMIID66ADAgECAhMzAAABUptA
# n1BWmXWIAAAAAAFSMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMTkwNTAyMjEzNzQ2WhcNMjAwNTAyMjEzNzQ2WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQCxp4nT9qfu9O10iJyewYXHlN+WEh79Noor9nhM6enUNbCbhX9vS+8c/3eIVazS
# YnVBTqLzW7xWN1bCcItDbsEzKEE2BswSun7J9xCaLwcGHKFr+qWUlz7hh9RcmjYS
# kOGNybOfrgj3sm0DStoK8ljwEyUVeRfMHx9E/7Ca/OEq2cXBT3L0fVnlEkfal310
# EFCLDo2BrE35NGRjG+/nnZiqKqEh5lWNk33JV8/I0fIcUKrLEmUGrv0CgC7w2cjm
# bBhBIJ+0KzSnSWingXol/3iUdBBy4QQNH767kYGunJeY08RjHMIgjJCdAoEM+2mX
# v1phaV7j+M3dNzZ/cdsz3oDfAgMBAAGjggGCMIIBfjAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQU3f8Aw1sW72WcJ2bo/QSYGzVrRYcw
# VAYDVR0RBE0wS6RJMEcxLTArBgNVBAsTJE1pY3Jvc29mdCBJcmVsYW5kIE9wZXJh
# dGlvbnMgTGltaXRlZDEWMBQGA1UEBRMNMjMwMDEyKzQ1NDEzNjAfBgNVHSMEGDAW
# gBRIbmTlUAXTgqoXNzcitW2oynUClTBUBgNVHR8ETTBLMEmgR6BFhkNodHRwOi8v
# d3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NybC9NaWNDb2RTaWdQQ0EyMDExXzIw
# MTEtMDctMDguY3JsMGEGCCsGAQUFBwEBBFUwUzBRBggrBgEFBQcwAoZFaHR0cDov
# L3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9jZXJ0cy9NaWNDb2RTaWdQQ0EyMDEx
# XzIwMTEtMDctMDguY3J0MAwGA1UdEwEB/wQCMAAwDQYJKoZIhvcNAQELBQADggIB
# AJTwROaHvogXgixWjyjvLfiRgqI2QK8GoG23eqAgNjX7V/WdUWBbs0aIC3k49cd0
# zdq+JJImixcX6UOTpz2LZPFSh23l0/Mo35wG7JXUxgO0U+5drbQht5xoMl1n7/TQ
# 4iKcmAYSAPxTq5lFnoV2+fAeljVA7O43szjs7LR09D0wFHwzZco/iE8Hlakl23ZT
# 7FnB5AfU2hwfv87y3q3a5qFiugSykILpK0/vqnlEVB0KAdQVzYULQ/U4eFEjnis3
# Js9UrAvtIhIs26445Rj3UP6U4GgOjgQonlRA+mDlsh78wFSGbASIvK+fkONUhvj8
# B8ZHNn4TFfnct+a0ZueY4f6aRPxr8beNSUKn7QW/FQmn422bE7KfnqWncsH7vbNh
# G929prVHPsaa7J22i9wyHj7m0oATXJ+YjfyoEAtd5/NyIYaE4Uu0j1EhuYUo5VaJ
# JnMaTER0qX8+/YZRWrFN/heps41XNVjiAawpbAa0fUa3R9RNBjPiBnM0gvNPorM4
# dsV2VJ8GluIQOrJlOvuCrOYDGirGnadOmQ21wPBoGFCWpK56PxzliKsy5NNmAXcE
# x7Qb9vUjY1WlYtrdwOXTpxN4slzIht69BaZlLIjLVWwqIfuNrhHKNDM9K+v7vgrI
# bf7l5/665g0gjQCDCN6Q5sxuttTAEKtJeS/pkpI+DbZ/MIIHejCCBWKgAwIBAgIK
# YQ6Q0gAAAAAAAzANBgkqhkiG9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNV
# BAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jv
# c29mdCBDb3Jwb3JhdGlvbjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlm
# aWNhdGUgQXV0aG9yaXR5IDIwMTEwHhcNMTEwNzA4MjA1OTA5WhcNMjYwNzA4MjEw
# OTA5WjB+MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UE
# BxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSgwJgYD
# VQQDEx9NaWNyb3NvZnQgQ29kZSBTaWduaW5nIFBDQSAyMDExMIICIjANBgkqhkiG
# 9w0BAQEFAAOCAg8AMIICCgKCAgEAq/D6chAcLq3YbqqCEE00uvK2WCGfQhsqa+la
# UKq4BjgaBEm6f8MMHt03a8YS2AvwOMKZBrDIOdUBFDFC04kNeWSHfpRgJGyvnkmc
# 6Whe0t+bU7IKLMOv2akrrnoJr9eWWcpgGgXpZnboMlImEi/nqwhQz7NEt13YxC4D
# dato88tt8zpcoRb0RrrgOGSsbmQ1eKagYw8t00CT+OPeBw3VXHmlSSnnDb6gE3e+
# lD3v++MrWhAfTVYoonpy4BI6t0le2O3tQ5GD2Xuye4Yb2T6xjF3oiU+EGvKhL1nk
# kDstrjNYxbc+/jLTswM9sbKvkjh+0p2ALPVOVpEhNSXDOW5kf1O6nA+tGSOEy/S6
# A4aN91/w0FK/jJSHvMAhdCVfGCi2zCcoOCWYOUo2z3yxkq4cI6epZuxhH2rhKEmd
# X4jiJV3TIUs+UsS1Vz8kA/DRelsv1SPjcF0PUUZ3s/gA4bysAoJf28AVs70b1FVL
# 5zmhD+kjSbwYuER8ReTBw3J64HLnJN+/RpnF78IcV9uDjexNSTCnq47f7Fufr/zd
# sGbiwZeBe+3W7UvnSSmnEyimp31ngOaKYnhfsi+E11ecXL93KCjx7W3DKI8sj0A3
# T8HhhUSJxAlMxdSlQy90lfdu+HggWCwTXWCVmj5PM4TasIgX3p5O9JawvEagbJjS
# 4NaIjAsCAwEAAaOCAe0wggHpMBAGCSsGAQQBgjcVAQQDAgEAMB0GA1UdDgQWBBRI
# bmTlUAXTgqoXNzcitW2oynUClTAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTAL
# BgNVHQ8EBAMCAYYwDwYDVR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBRyLToCMZBD
# uRQFTuHqp8cx0SOJNDBaBgNVHR8EUzBRME+gTaBLhklodHRwOi8vY3JsLm1pY3Jv
# c29mdC5jb20vcGtpL2NybC9wcm9kdWN0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFf
# MDNfMjIuY3JsMF4GCCsGAQUFBwEBBFIwUDBOBggrBgEFBQcwAoZCaHR0cDovL3d3
# dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFf
# MDNfMjIuY3J0MIGfBgNVHSAEgZcwgZQwgZEGCSsGAQQBgjcuAzCBgzA/BggrBgEF
# BQcCARYzaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9kb2NzL3ByaW1h
# cnljcHMuaHRtMEAGCCsGAQUFBwICMDQeMiAdAEwAZQBnAGEAbABfAHAAbwBsAGkA
# YwB5AF8AcwB0AGEAdABlAG0AZQBuAHQALiAdMA0GCSqGSIb3DQEBCwUAA4ICAQBn
# 8oalmOBUeRou09h0ZyKbC5YR4WOSmUKWfdJ5DJDBZV8uLD74w3LRbYP+vj/oCso7
# v0epo/Np22O/IjWll11lhJB9i0ZQVdgMknzSGksc8zxCi1LQsP1r4z4HLimb5j0b
# pdS1HXeUOeLpZMlEPXh6I/MTfaaQdION9MsmAkYqwooQu6SpBQyb7Wj6aC6VoCo/
# KmtYSWMfCWluWpiW5IP0wI/zRive/DvQvTXvbiWu5a8n7dDd8w6vmSiXmE0OPQvy
# CInWH8MyGOLwxS3OW560STkKxgrCxq2u5bLZ2xWIUUVYODJxJxp/sfQn+N4sOiBp
# mLJZiWhub6e3dMNABQamASooPoI/E01mC8CzTfXhj38cbxV9Rad25UAqZaPDXVJi
# hsMdYzaXht/a8/jyFqGaJ+HNpZfQ7l1jQeNbB5yHPgZ3BtEGsXUfFL5hYbXw3MYb
# BL7fQccOKO7eZS/sl/ahXJbYANahRr1Z85elCUtIEJmAH9AAKcWxm6U/RXceNcbS
# oqKfenoi+kiVH6v7RyOA9Z74v2u3S5fi63V4GuzqN5l5GEv/1rMjaHXmr/r8i+sL
# gOppO6/8MO0ETI7f33VtY5E90Z1WTk+/gFcioXgRMiF670EKsT/7qMykXcGhiJtX
# cVZOSEXAQsmbdlsKgEhr/Xmfwb1tbWrJUnMTDXpQzTGCFYQwghWAAgEBMIGVMH4x
# CzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRt
# b25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01p
# Y3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTECEzMAAAFSm0CfUFaZdYgAAAAA
# AVIwDQYJYIZIAWUDBAIBBQCggdowGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQw
# HAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIIYU
# eOGVPBusdIGv8yGiprQqZIvy1KUhDlvkQLWQ73vuMG4GCisGAQQBgjcCAQwxYDBe
# oECAPgBBAHUAdABvAFUAcABnAHIAYQBkAGUAQwBvAG4AZgBpAGcAQQBvAHMAUwBl
# AHIAdgBpAGMAZQAuAHAAcwAxoRqAGGh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbTAN
# BgkqhkiG9w0BAQEFAASCAQB9fTgMt8JQRHvNBDkzxGaOjr/v2ke33YcvMh99ByKL
# IjRBeJX2OEkjjgz531HP1oupWTvZwIamVqw5I/JbENd/C7hNTbFwSUVS3RKteGpu
# PEjA0I8YfydbixRGneuEJra0f0Z7Jt7Y1rUhWXv4v09scbTUcmfSCTMp9Y+PJtUX
# znBYGmboAZ/nXQsAnMH1jM++uqG1KLFvHZonXPIdaN6yeduSmu4XV4fb5h4FDkO+
# Q7qJ5Qx5P/BHo4CSxoXsgRFxryDF9H13B4ltv4kvBwhzvgbrN3Z+0Qdqkbki7GRL
# AY0WwPbMpbjvmrX7a9ygx5rGn5Wiqc8EO2q8HvWTvRtYoYIS4jCCEt4GCisGAQQB
# gjcDAwExghLOMIISygYJKoZIhvcNAQcCoIISuzCCErcCAQMxDzANBglghkgBZQME
# AgEFADCCAVEGCyqGSIb3DQEJEAEEoIIBQASCATwwggE4AgEBBgorBgEEAYRZCgMB
# MDEwDQYJYIZIAWUDBAIBBQAEINlO6L+/FLVB4j2swSTxry+QYDHeWi6GkGZXGfsA
# WARwAgZdwsFjNh0YEzIwMTkxMjAzMDMyMzQ3LjExOVowBIACAfSggdCkgc0wgcox
# CzAJBgNVBAYTAlVTMQswCQYDVQQIEwJXQTEQMA4GA1UEBxMHUmVkbW9uZDEeMBwG
# A1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMS0wKwYDVQQLEyRNaWNyb3NvZnQg
# SXJlbGFuZCBPcGVyYXRpb25zIExpbWl0ZWQxJjAkBgNVBAsTHVRoYWxlcyBUU1Mg
# RVNOOkZGMDYtNEJDMy1COURBMSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFt
# cCBTZXJ2aWNloIIOOTCCBPEwggPZoAMCAQICEzMAAAEUNSdF6rbIbE8AAAAAARQw
# DQYJKoZIhvcNAQELBQAwfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0
# b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3Jh
# dGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwHhcN
# MTkxMDIzMjMxOTM3WhcNMjEwMTIxMjMxOTM3WjCByjELMAkGA1UEBhMCVVMxCzAJ
# BgNVBAgTAldBMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQg
# Q29ycG9yYXRpb24xLTArBgNVBAsTJE1pY3Jvc29mdCBJcmVsYW5kIE9wZXJhdGlv
# bnMgTGltaXRlZDEmMCQGA1UECxMdVGhhbGVzIFRTUyBFU046RkYwNi00QkMzLUI5
# REExJTAjBgNVBAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZpY2UwggEiMA0G
# CSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCdvi0k88S1dkCr0Rb9Vgwts1CaVvWj
# i4j8Z6oJteo97xmiVPQbsXEbI7B8SEULpdsTxnLpWlk0lfGayBLb6mqwYyqS+e1i
# Skkl6pOdFuh00sfjHmOGhKhww2Tyx4NpoHBnAc/qbL4YATCnVrywYDOzs27m67Mv
# lKLiL9KHovfG1r7FHzyp1tbKQhctJWk8QEwSPUZGZt5MDTpd1Dh1z5zVQ2gz2A5I
# TBvVMWOoNY3L6co/9NVg4FoGrU9CT45rbX8d2x+DRXLSluVNn5CYse/fEhRVrZO6
# UiMKYMfTFsNWk5gf/0Bfr5IMCpfKdAltdzcMjqG2+OfDwURGNJmbfIz/AgMBAAGj
# ggEbMIIBFzAdBgNVHQ4EFgQUUFSPcOb+hJN3LEanWWXcI4uJPAIwHwYDVR0jBBgw
# FoAU1WM6XIoxkPNDe3xGG8UzaFqFbVUwVgYDVR0fBE8wTTBLoEmgR4ZFaHR0cDov
# L2NybC5taWNyb3NvZnQuY29tL3BraS9jcmwvcHJvZHVjdHMvTWljVGltU3RhUENB
# XzIwMTAtMDctMDEuY3JsMFoGCCsGAQUFBwEBBE4wTDBKBggrBgEFBQcwAoY+aHR0
# cDovL3d3dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0cy9NaWNUaW1TdGFQQ0FfMjAx
# MC0wNy0wMS5jcnQwDAYDVR0TAQH/BAIwADATBgNVHSUEDDAKBggrBgEFBQcDCDAN
# BgkqhkiG9w0BAQsFAAOCAQEAGSKMNfc4B8frM9Abi+4YqtynPH8Q8GppZluhR0AH
# 3mPEUPfiKWGM4nxWqr9VgJIFmgCh5hm/ssthGNHpnwVDWHe387yhXMIFFafhZJqf
# FnOk02md5bK6sNVQTdgq1pW/E7lEIaWFTE+O8WkNYg+hZEunA5G+zfam+dO1gE0g
# eM303kGkS5PsbGRdnhqxddE+0S/+qhgC6d2Nvu0NYU3zc9WF5wp7esRcYCCJz+OD
# TrPecbLtawY0u7EwelI+eUx76jFg8+Er7x+USdAPDhHeGLItI0nDf9zyxFrzvChq
# aNnbbHFK8kkCqVZb+570CBJTP6HPUblA/QN8rqhnplTnGjCCBnEwggRZoAMCAQIC
# CmEJgSoAAAAAAAIwDQYJKoZIhvcNAQELBQAwgYgxCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xMjAwBgNVBAMTKU1pY3Jvc29mdCBSb290IENlcnRp
# ZmljYXRlIEF1dGhvcml0eSAyMDEwMB4XDTEwMDcwMTIxMzY1NVoXDTI1MDcwMTIx
# NDY1NVowfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNV
# BAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQG
# A1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwggEiMA0GCSqGSIb3
# DQEBAQUAA4IBDwAwggEKAoIBAQCpHQ28dxGKOiDs/BOX9fp/aZRrdFQQ1aUKAIKF
# ++18aEssX8XD5WHCdrc+Zitb8BVTJwQxH0EbGpUdzgkTjnxhMFmxMEQP8WCIhFRD
# DNdNuDgIs0Ldk6zWczBXJoKjRQ3Q6vVHgc2/JGAyWGBG8lhHhjKEHnRhZ5FfgVSx
# z5NMksHEpl3RYRNuKMYa+YaAu99h/EbBJx0kZxJyGiGKr0tkiVBisV39dx898Fd1
# rL2KQk1AUdEPnAY+Z3/1ZsADlkR+79BL/W7lmsqxqPJ6Kgox8NpOBpG2iAg16Hgc
# sOmZzTznL0S6p/TcZL2kAcEgCZN4zfy8wMlEXV4WnAEFTyJNAgMBAAGjggHmMIIB
# 4jAQBgkrBgEEAYI3FQEEAwIBADAdBgNVHQ4EFgQU1WM6XIoxkPNDe3xGG8UzaFqF
# bVUwGQYJKwYBBAGCNxQCBAweCgBTAHUAYgBDAEEwCwYDVR0PBAQDAgGGMA8GA1Ud
# EwEB/wQFMAMBAf8wHwYDVR0jBBgwFoAU1fZWy4/oolxiaNE9lJBb186aGMQwVgYD
# VR0fBE8wTTBLoEmgR4ZFaHR0cDovL2NybC5taWNyb3NvZnQuY29tL3BraS9jcmwv
# cHJvZHVjdHMvTWljUm9vQ2VyQXV0XzIwMTAtMDYtMjMuY3JsMFoGCCsGAQUFBwEB
# BE4wTDBKBggrBgEFBQcwAoY+aHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraS9j
# ZXJ0cy9NaWNSb29DZXJBdXRfMjAxMC0wNi0yMy5jcnQwgaAGA1UdIAEB/wSBlTCB
# kjCBjwYJKwYBBAGCNy4DMIGBMD0GCCsGAQUFBwIBFjFodHRwOi8vd3d3Lm1pY3Jv
# c29mdC5jb20vUEtJL2RvY3MvQ1BTL2RlZmF1bHQuaHRtMEAGCCsGAQUFBwICMDQe
# MiAdAEwAZQBnAGEAbABfAFAAbwBsAGkAYwB5AF8AUwB0AGEAdABlAG0AZQBuAHQA
# LiAdMA0GCSqGSIb3DQEBCwUAA4ICAQAH5ohRDeLG4Jg/gXEDPZ2joSFvs+umzPUx
# vs8F4qn++ldtGTCzwsVmyWrf9efweL3HqJ4l4/m87WtUVwgrUYJEEvu5U4zM9GAS
# inbMQEBBm9xcF/9c+V4XNZgkVkt070IQyK+/f8Z/8jd9Wj8c8pl5SpFSAK84Dxf1
# L3mBZdmptWvkx872ynoAb0swRCQiPM/tA6WWj1kpvLb9BOFwnzJKJ/1Vry/+tuWO
# M7tiX5rbV0Dp8c6ZZpCM/2pif93FSguRJuI57BlKcWOdeyFtw5yjojz6f32WapB4
# pm3S4Zz5Hfw42JT0xqUKloakvZ4argRCg7i1gJsiOCC1JeVk7Pf0v35jWSUPei45
# V3aicaoGig+JFrphpxHLmtgOR5qAxdDNp9DvfYPw4TtxCd9ddJgiCGHasFAeb73x
# 4QDf5zEHpJM692VHeOj4qEir995yfmFrb3epgcunCaw5u+zGy9iCtHLNHfS4hQEe
# gPsbiSpUObJb2sgNVZl6h3M7COaYLeqN4DMuEin1wC9UJyH3yKxO2ii4sanblrKn
# QqLJzxlBTeCG+SqaoxFmMNO7dDJL32N79ZmKLxvHIa9Zta7cRDyXUHHXodLFVeNp
# 3lfB0d4wwP3M5k37Db9dT+mdHhk4L7zPWAUu7w2gUDXa7wknHNWzfjUeCLraNtvT
# X4/edIhJEqGCAsswggI0AgEBMIH4oYHQpIHNMIHKMQswCQYDVQQGEwJVUzELMAkG
# A1UECBMCV0ExEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBD
# b3Jwb3JhdGlvbjEtMCsGA1UECxMkTWljcm9zb2Z0IElyZWxhbmQgT3BlcmF0aW9u
# cyBMaW1pdGVkMSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVTTjpGRjA2LTRCQzMtQjlE
# QTElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgU2VydmljZaIjCgEBMAcG
# BSsOAwIaAxUA4ATkl0QTu3uFAmVR+pqOPC6L4GeggYMwgYCkfjB8MQswCQYDVQQG
# EwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwG
# A1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQg
# VGltZS1TdGFtcCBQQ0EgMjAxMDANBgkqhkiG9w0BAQUFAAIFAOGQLwcwIhgPMjAx
# OTEyMDMwODQ3MDNaGA8yMDE5MTIwNDA4NDcwM1owdDA6BgorBgEEAYRZCgQBMSww
# KjAKAgUA4ZAvBwIBADAHAgEAAgIgJTAHAgEAAgISOzAKAgUA4ZGAhwIBADA2Bgor
# BgEEAYRZCgQCMSgwJjAMBgorBgEEAYRZCgMCoAowCAIBAAIDB6EgoQowCAIBAAID
# AYagMA0GCSqGSIb3DQEBBQUAA4GBAFUGaKV3xFNedL16WUMZCml5XVMXn3bmcEtp
# LNlBPYkh6rzim8EM05mwKLuFf2chdeDMwv7xRqEbPcbnyZnTOba8joVdx6frKYUQ
# 4MkWmQXGbA7PYdit1ebGTvTjuTRLYziRyiLkvfmiUXxsp4B5+50SSlVtgVZykD6k
# IZBnIGDcMYIDDTCCAwkCAQEwgZMwfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldh
# c2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBD
# b3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIw
# MTACEzMAAAEUNSdF6rbIbE8AAAAAARQwDQYJYIZIAWUDBAIBBQCgggFKMBoGCSqG
# SIb3DQEJAzENBgsqhkiG9w0BCRABBDAvBgkqhkiG9w0BCQQxIgQg89bLOB7FzR/G
# 0n/ZoQ1TGJRNrNNpUz0l247xqpvAVSEwgfoGCyqGSIb3DQEJEAIvMYHqMIHnMIHk
# MIG9BCBMEX+t50VMGPQQXEsFWfGBi8gat6mIS7jV9Lz5rc3rOjCBmDCBgKR+MHwx
# CzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRt
# b25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1p
# Y3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwAhMzAAABFDUnReq2yGxPAAAAAAEU
# MCIEICvF4pAfZAyEleU60MHaZwF4uYFEZJDkPN65I85+V4w9MA0GCSqGSIb3DQEB
# CwUABIIBAHVX87jCVQ60zuSZEuP5FbWvKw+9cUaOBF8ZmTQ52/p8W1vncXoGNim2
# PCOZ/D8INStl4vZobhDQkOW9PajEr5gOuNY0M5h8idYPLp2ZdpGk37BdTnp27zJr
# +tAd+XW47TGWCisW8MLQnmZCuItcznlyPkGkixmOZj8qyNfQJSzqG/u6UwmjyjMj
# iBOb38wYPBX4CePJjN1b3Jamd2m6N8HJPJjAHOCuoPZDu+8rULT48sTyNnibJ+4X
# 66PJr4k4sBtsxLyl3lYwaKZKTHuFgxmZHl1EdR5TkQ0hJUD1bH1WfR/L6y/PUu9q
# oEZ7llO1IdTxUEDi/BQdN5VRuriRDJk=
# SIG # End signature block
