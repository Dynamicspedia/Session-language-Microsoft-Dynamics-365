﻿#
# Pack_AXBootstrapperApp.ps1
#

param(
	[Parameter()]
	[ValidateNotNullOrEmpty()]
	[string] $DynamicsPackageLocation=$(throw "DynamicsPackageLocation is mandatory, please provide a value"),

	[Parameter()]
	[ValidateNotNullOrEmpty()]
	[string] $WebsitePackageLocation=$(throw "WebsitePackageLocation is mandatory, please provide a value"),

	[Parameter()]
	[ValidateNotNullOrEmpty()]
	[string] $ScriptsLocation=$(throw "ScriptsLocation is mandatory, please provide a value"),

	[Parameter()]
	[ValidateNotNullOrEmpty()]
	[string] $PackageLocation=$(throw "PackageLocation is mandatory, please provide a value")
)

$ErrorActionPreference ="Stop"

$DynamicsPackageLocation = (Resolve-Path $DynamicsPackageLocation).ProviderPath
Write-Host "DynamicsPackageLocation $DynamicsPackageLocation"

$WebsitePackageLocation = (Resolve-Path $WebsitePackageLocation).ProviderPath
Write-Host "WebsitePackageLocation $WebsitePackageLocation"

$ScriptsLocation = (Resolve-Path $ScriptsLocation).ProviderPath
Write-Host "ScriptsLocation $ScriptsLocation"

$PackageLocation = (Resolve-Path $PackageLocation).ProviderPath
Write-Host "PackageLocation $PackageLocation"

$scriptBinFiles = @(
	"$DynamicsPackageLocation\Bin\Microsoft.Diagnostics.Tracing.EventSource.dll",
    "$DynamicsPackageLocation\Bin\Microsoft.Dynamics.ApplicationPlatform.Deployment.Instrumentation.dll" ,
    "$DynamicsPackageLocation\Bin\Microsoft.Dynamics.ApplicationPlatform.Development.Instrumentation.dll" ,
    "$DynamicsPackageLocation\Bin\Microsoft.Dynamics.ApplicationPlatform.PerformanceCounters.dll" ,
    "$DynamicsPackageLocation\Bin\Microsoft.Dynamics.ApplicationPlatform.Services.Instrumentation.dll", 
    "$DynamicsPackageLocation\Bin\Microsoft.Dynamics.ApplicationPlatform.SSRSReportRuntime.Instrumentation.dll" ,
    "$DynamicsPackageLocation\Bin\Microsoft.Dynamics.ApplicationPlatform.Workflow.Instrumentation.dll" ,
    "$DynamicsPackageLocation\Bin\Microsoft.Dynamics.ApplicationPlatform.XppServices.Instrumentation.dll", 
    "$DynamicsPackageLocation\Bin\Microsoft.Dynamics.AX.Xpp.AxShared.dll" ,
    "$DynamicsPackageLocation\Bin\Microsoft.Dynamics.Performance.Instrumentation.dll" ,
    "$DynamicsPackageLocation\Bin\Microsoft.Dynamics.ProductConfiguration.Instrumentation.dll" ,
    "$DynamicsPackageLocation\Bin\Microsoft.Dynamics.Retail.Diagnostics.dll" ,
    "$DynamicsPackageLocation\Bin\Microsoft.Dynamics.Retail.Diagnostics.Sinks.dll", 
    "$DynamicsPackageLocation\Bin\netstandard.dll",
    "$DynamicsPackageLocation\Bin\Microsoft.Dynamics.SourceDocumentation.Instrumentation.dll" ,
    "$DynamicsPackageLocation\Bin\Microsoft.Dynamics.Subledger.Instrumentation.dll" ,
    "$DynamicsPackageLocation\Bin\Microsoft.Dynamics.Tax.Instrumentation.dll"
)

$scriptFiles = @(
	"$ScriptsLocation\RegisterRetailPerfCounters.ps1",
    "$ScriptsLocation\Register-PerfCounters.ps1",
    "$ScriptsLocation\InitializePerfCounters.ps1",
    "$ScriptsLocation\AosCommon.psm1"
)

$codeFiles = @(
	"$WebsitePackageLocation\bin\Microsoft.Dynamics.AX.Framework.EncryptionEngine.dll",
	"$WebsitePackageLocation\bin\Microsoft.Dynamics.BusinessPlatform.SharedTypes.dll",
	"$WebsitePackageLocation\bin\Microsoft.Dynamics.AX.Configuration.Base.dll"
)

if (!(Test-Path "$PackageLocation\AXBootstrapperPkg\Code\Scripts\Bin"))
{
    [system.io.directory]::CreateDirectory("$PackageLocation\AXBootstrapperPkg\Code\Scripts\Bin\");
}

Write-Host "Copying AXBootstrapperPkg script files"
foreach($file in $scriptFiles)
{
    if(Test-Path $file)
    {
        
        $file | Copy-Item -Destination "$PackageLocation\AXBootstrapperPkg\Code\Scripts\" -Force

    }
}

foreach($file in $scriptBinFiles)
{
	if(Test-Path $file)
	{
		$file | Copy-Item -Destination "$PackageLocation\AXBootstrapperPkg\Code\Scripts\Bin\" -Force
	}
}
Write-Host "Done copying AXBootstrapperPkg script bin files"

Write-Host "Copying AXDiagnosticsPkg code files"
$codeFiles | Copy-Item -Destination $PackageLocation\AXDiagnosticsPkg\Code -Force
Write-Host "Done copying AXDiagnosticsPkg code files"
# SIG # Begin signature block
# MIIkiAYJKoZIhvcNAQcCoIIkeTCCJHUCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCCW8HKQlKqSn29b
# 7WHPcfExGt/J6c+UpD3A4IvYt9iU1aCCDYUwggYDMIID66ADAgECAhMzAAABUptA
# n1BWmXWIAAAAAAFSMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMTkwNTAyMjEzNzQ2WhcNMjAwNTAyMjEzNzQ2WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQCxp4nT9qfu9O10iJyewYXHlN+WEh79Noor9nhM6enUNbCbhX9vS+8c/3eIVazS
# YnVBTqLzW7xWN1bCcItDbsEzKEE2BswSun7J9xCaLwcGHKFr+qWUlz7hh9RcmjYS
# kOGNybOfrgj3sm0DStoK8ljwEyUVeRfMHx9E/7Ca/OEq2cXBT3L0fVnlEkfal310
# EFCLDo2BrE35NGRjG+/nnZiqKqEh5lWNk33JV8/I0fIcUKrLEmUGrv0CgC7w2cjm
# bBhBIJ+0KzSnSWingXol/3iUdBBy4QQNH767kYGunJeY08RjHMIgjJCdAoEM+2mX
# v1phaV7j+M3dNzZ/cdsz3oDfAgMBAAGjggGCMIIBfjAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQU3f8Aw1sW72WcJ2bo/QSYGzVrRYcw
# VAYDVR0RBE0wS6RJMEcxLTArBgNVBAsTJE1pY3Jvc29mdCBJcmVsYW5kIE9wZXJh
# dGlvbnMgTGltaXRlZDEWMBQGA1UEBRMNMjMwMDEyKzQ1NDEzNjAfBgNVHSMEGDAW
# gBRIbmTlUAXTgqoXNzcitW2oynUClTBUBgNVHR8ETTBLMEmgR6BFhkNodHRwOi8v
# d3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NybC9NaWNDb2RTaWdQQ0EyMDExXzIw
# MTEtMDctMDguY3JsMGEGCCsGAQUFBwEBBFUwUzBRBggrBgEFBQcwAoZFaHR0cDov
# L3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9jZXJ0cy9NaWNDb2RTaWdQQ0EyMDEx
# XzIwMTEtMDctMDguY3J0MAwGA1UdEwEB/wQCMAAwDQYJKoZIhvcNAQELBQADggIB
# AJTwROaHvogXgixWjyjvLfiRgqI2QK8GoG23eqAgNjX7V/WdUWBbs0aIC3k49cd0
# zdq+JJImixcX6UOTpz2LZPFSh23l0/Mo35wG7JXUxgO0U+5drbQht5xoMl1n7/TQ
# 4iKcmAYSAPxTq5lFnoV2+fAeljVA7O43szjs7LR09D0wFHwzZco/iE8Hlakl23ZT
# 7FnB5AfU2hwfv87y3q3a5qFiugSykILpK0/vqnlEVB0KAdQVzYULQ/U4eFEjnis3
# Js9UrAvtIhIs26445Rj3UP6U4GgOjgQonlRA+mDlsh78wFSGbASIvK+fkONUhvj8
# B8ZHNn4TFfnct+a0ZueY4f6aRPxr8beNSUKn7QW/FQmn422bE7KfnqWncsH7vbNh
# G929prVHPsaa7J22i9wyHj7m0oATXJ+YjfyoEAtd5/NyIYaE4Uu0j1EhuYUo5VaJ
# JnMaTER0qX8+/YZRWrFN/heps41XNVjiAawpbAa0fUa3R9RNBjPiBnM0gvNPorM4
# dsV2VJ8GluIQOrJlOvuCrOYDGirGnadOmQ21wPBoGFCWpK56PxzliKsy5NNmAXcE
# x7Qb9vUjY1WlYtrdwOXTpxN4slzIht69BaZlLIjLVWwqIfuNrhHKNDM9K+v7vgrI
# bf7l5/665g0gjQCDCN6Q5sxuttTAEKtJeS/pkpI+DbZ/MIIHejCCBWKgAwIBAgIK
# YQ6Q0gAAAAAAAzANBgkqhkiG9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNV
# BAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jv
# c29mdCBDb3Jwb3JhdGlvbjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlm
# aWNhdGUgQXV0aG9yaXR5IDIwMTEwHhcNMTEwNzA4MjA1OTA5WhcNMjYwNzA4MjEw
# OTA5WjB+MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UE
# BxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSgwJgYD
# VQQDEx9NaWNyb3NvZnQgQ29kZSBTaWduaW5nIFBDQSAyMDExMIICIjANBgkqhkiG
# 9w0BAQEFAAOCAg8AMIICCgKCAgEAq/D6chAcLq3YbqqCEE00uvK2WCGfQhsqa+la
# UKq4BjgaBEm6f8MMHt03a8YS2AvwOMKZBrDIOdUBFDFC04kNeWSHfpRgJGyvnkmc
# 6Whe0t+bU7IKLMOv2akrrnoJr9eWWcpgGgXpZnboMlImEi/nqwhQz7NEt13YxC4D
# dato88tt8zpcoRb0RrrgOGSsbmQ1eKagYw8t00CT+OPeBw3VXHmlSSnnDb6gE3e+
# lD3v++MrWhAfTVYoonpy4BI6t0le2O3tQ5GD2Xuye4Yb2T6xjF3oiU+EGvKhL1nk
# kDstrjNYxbc+/jLTswM9sbKvkjh+0p2ALPVOVpEhNSXDOW5kf1O6nA+tGSOEy/S6
# A4aN91/w0FK/jJSHvMAhdCVfGCi2zCcoOCWYOUo2z3yxkq4cI6epZuxhH2rhKEmd
# X4jiJV3TIUs+UsS1Vz8kA/DRelsv1SPjcF0PUUZ3s/gA4bysAoJf28AVs70b1FVL
# 5zmhD+kjSbwYuER8ReTBw3J64HLnJN+/RpnF78IcV9uDjexNSTCnq47f7Fufr/zd
# sGbiwZeBe+3W7UvnSSmnEyimp31ngOaKYnhfsi+E11ecXL93KCjx7W3DKI8sj0A3
# T8HhhUSJxAlMxdSlQy90lfdu+HggWCwTXWCVmj5PM4TasIgX3p5O9JawvEagbJjS
# 4NaIjAsCAwEAAaOCAe0wggHpMBAGCSsGAQQBgjcVAQQDAgEAMB0GA1UdDgQWBBRI
# bmTlUAXTgqoXNzcitW2oynUClTAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTAL
# BgNVHQ8EBAMCAYYwDwYDVR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBRyLToCMZBD
# uRQFTuHqp8cx0SOJNDBaBgNVHR8EUzBRME+gTaBLhklodHRwOi8vY3JsLm1pY3Jv
# c29mdC5jb20vcGtpL2NybC9wcm9kdWN0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFf
# MDNfMjIuY3JsMF4GCCsGAQUFBwEBBFIwUDBOBggrBgEFBQcwAoZCaHR0cDovL3d3
# dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFf
# MDNfMjIuY3J0MIGfBgNVHSAEgZcwgZQwgZEGCSsGAQQBgjcuAzCBgzA/BggrBgEF
# BQcCARYzaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9kb2NzL3ByaW1h
# cnljcHMuaHRtMEAGCCsGAQUFBwICMDQeMiAdAEwAZQBnAGEAbABfAHAAbwBsAGkA
# YwB5AF8AcwB0AGEAdABlAG0AZQBuAHQALiAdMA0GCSqGSIb3DQEBCwUAA4ICAQBn
# 8oalmOBUeRou09h0ZyKbC5YR4WOSmUKWfdJ5DJDBZV8uLD74w3LRbYP+vj/oCso7
# v0epo/Np22O/IjWll11lhJB9i0ZQVdgMknzSGksc8zxCi1LQsP1r4z4HLimb5j0b
# pdS1HXeUOeLpZMlEPXh6I/MTfaaQdION9MsmAkYqwooQu6SpBQyb7Wj6aC6VoCo/
# KmtYSWMfCWluWpiW5IP0wI/zRive/DvQvTXvbiWu5a8n7dDd8w6vmSiXmE0OPQvy
# CInWH8MyGOLwxS3OW560STkKxgrCxq2u5bLZ2xWIUUVYODJxJxp/sfQn+N4sOiBp
# mLJZiWhub6e3dMNABQamASooPoI/E01mC8CzTfXhj38cbxV9Rad25UAqZaPDXVJi
# hsMdYzaXht/a8/jyFqGaJ+HNpZfQ7l1jQeNbB5yHPgZ3BtEGsXUfFL5hYbXw3MYb
# BL7fQccOKO7eZS/sl/ahXJbYANahRr1Z85elCUtIEJmAH9AAKcWxm6U/RXceNcbS
# oqKfenoi+kiVH6v7RyOA9Z74v2u3S5fi63V4GuzqN5l5GEv/1rMjaHXmr/r8i+sL
# gOppO6/8MO0ETI7f33VtY5E90Z1WTk+/gFcioXgRMiF670EKsT/7qMykXcGhiJtX
# cVZOSEXAQsmbdlsKgEhr/Xmfwb1tbWrJUnMTDXpQzTGCFlkwghZVAgEBMIGVMH4x
# CzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRt
# b25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01p
# Y3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTECEzMAAAFSm0CfUFaZdYgAAAAA
# AVIwDQYJYIZIAWUDBAIBBQCggdowGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQw
# HAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIG3P
# 1YdspB7kxAgsf1OPcjNCGQdhDBGt7cWnvvhAq56ZMG4GCisGAQQBgjcCAQwxYDBe
# oECAPgBBAHUAdABvAFUAcABnAHIAYQBkAGUAQwBvAG4AZgBpAGcAQQBvAHMAUwBl
# AHIAdgBpAGMAZQAuAHAAcwAxoRqAGGh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbTAN
# BgkqhkiG9w0BAQEFAASCAQBRXQrCLltZXUeIBn+MJZcRaojsyFXsjIn03Q1ShVNf
# Rk+Q1B/lsBnEB+5HqKWHyuODIVwjXZq49PFwsJZAAjyN7U/tO+AXXqT+OLLKqg2P
# fsl2m+h6h2xpSwCrGnlPRorm92bWzgYvnsdmnAOk9HY2YEQLrDFlVl3fl0rwrXQm
# vPQrQo3NaKHrxmMF3IvAWZuNkK8DmuPxMn4esL/pgv20hmZebXJMmCWyrFfkgvh4
# KDD7aCfVseJGiZ89oH/gcBwVE5PRd3D0bRrMhoosAmP43+CrGrKIjXbBDyHvs7Pk
# 0iQeSi8yDc25f7Yzx8eG1k+utHxdIIgOEncN2JbjgQUsoYITtzCCE7MGCisGAQQB
# gjcDAwExghOjMIITnwYJKoZIhvcNAQcCoIITkDCCE4wCAQMxDzANBglghkgBZQME
# AgEFADCCAVgGCyqGSIb3DQEJEAEEoIIBRwSCAUMwggE/AgEBBgorBgEEAYRZCgMB
# MDEwDQYJYIZIAWUDBAIBBQAEIBM4Z8ePxgCY9aPZFOclaMYEpJYt3pWZ1SPi4Exe
# YSCIAgZdr3Y9uUcYEzIwMTkxMjAzMDMyMzQ4LjkxNFowBwIBAYACAfSggdSkgdEw
# gc4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKTAnBgNVBAsT
# IE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1ZXJ0byBSaWNvMSYwJAYDVQQLEx1UaGFs
# ZXMgVFNTIEVTTjpCMUI3LUY2N0YtRkVDMjElMCMGA1UEAxMcTWljcm9zb2Z0IFRp
# bWUtU3RhbXAgU2VydmljZaCCDx8wggT1MIID3aADAgECAhMzAAABA+pOK3i2KieT
# AAAAAAEDMA0GCSqGSIb3DQEBCwUAMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpX
# YXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQg
# Q29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAy
# MDEwMB4XDTE5MDkwNjIwNDExN1oXDTIwMTIwNDIwNDExN1owgc4xCzAJBgNVBAYT
# AlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYD
# VQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKTAnBgNVBAsTIE1pY3Jvc29mdCBP
# cGVyYXRpb25zIFB1ZXJ0byBSaWNvMSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVTTjpC
# MUI3LUY2N0YtRkVDMjElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgU2Vy
# dmljZTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBALCRV96uFMhQPoee
# fQrvxbzOW3Y7LKElUOxYoMR9HW2+DOgS3ECplmsQJZbcXZJ1686/7CV7skdSO95r
# G7k9cnI9tvX4OW0WDRjtcaFOvmDdENyBUYmIf+kuPHwA8Edbzeg7OPkBCtvM5nUJ
# 5xVnQuiT9R5NF9axjwoYkHaIcaj9GWQgW5h+awLofbWyY0rWyXYk8GndPVK3MkT3
# FnFPWLGY6OB2lRMEgpBLw1uKpCUHqp4Fpff5gnvb93EVSliLr11lwfYwEF5RjNDe
# gi9P39MjpnuXGwI2LjGKUsF66VGaVw4rdaUKQlPKJ0P/h/b9LCcVZyBVfwAD/Xap
# Woo2JEsCAwEAAaOCARswggEXMB0GA1UdDgQWBBTiNi2Y/aGPja1lJu2PPODMEW9a
# CDAfBgNVHSMEGDAWgBTVYzpcijGQ80N7fEYbxTNoWoVtVTBWBgNVHR8ETzBNMEug
# SaBHhkVodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2NybC9wcm9kdWN0cy9N
# aWNUaW1TdGFQQ0FfMjAxMC0wNy0wMS5jcmwwWgYIKwYBBQUHAQEETjBMMEoGCCsG
# AQUFBzAChj5odHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Rp
# bVN0YVBDQV8yMDEwLTA3LTAxLmNydDAMBgNVHRMBAf8EAjAAMBMGA1UdJQQMMAoG
# CCsGAQUFBwMIMA0GCSqGSIb3DQEBCwUAA4IBAQB8Naig5oqAZfKHIUhs99mL2pqt
# Va6yca9TwUyeM9yC/Soduk4CXbtGtn+/j7yMpQldXXFefBh9PIg3bdlLchCtL8RX
# VxdmxDQYcjyxYtEmxCxxS+6EOBfl9I1ouXDj8Aq8wGZZ9PbAraJDeqxgVqd9W/YC
# rC4la3tg4HzF1hot6L0oxNlTnu+RyXmZ7f6f/Vq6KZAZPyaKbI5P6qHBG3REPAgr
# 45+GySpbWAQhZjUNZ9pJ3NcePbuaa8N2xiIJsc9t8/FTSCj1xoiK9q2YvXoA64/h
# kyUIn/fBFY3BD6meMnQCG500ruiAm0GujHYOmZxAbosMOxtLPahmQUkcbQCPMIIG
# cTCCBFmgAwIBAgIKYQmBKgAAAAAAAjANBgkqhkiG9w0BAQsFADCBiDELMAkGA1UE
# BhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAc
# BgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEyMDAGA1UEAxMpTWljcm9zb2Z0
# IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5IDIwMTAwHhcNMTAwNzAxMjEzNjU1
# WhcNMjUwNzAxMjE0NjU1WjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGlu
# Z3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBv
# cmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDCC
# ASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAKkdDbx3EYo6IOz8E5f1+n9p
# lGt0VBDVpQoAgoX77XxoSyxfxcPlYcJ2tz5mK1vwFVMnBDEfQRsalR3OCROOfGEw
# WbEwRA/xYIiEVEMM1024OAizQt2TrNZzMFcmgqNFDdDq9UeBzb8kYDJYYEbyWEeG
# MoQedGFnkV+BVLHPk0ySwcSmXdFhE24oxhr5hoC732H8RsEnHSRnEnIaIYqvS2SJ
# UGKxXf13Hz3wV3WsvYpCTUBR0Q+cBj5nf/VmwAOWRH7v0Ev9buWayrGo8noqCjHw
# 2k4GkbaICDXoeByw6ZnNPOcvRLqn9NxkvaQBwSAJk3jN/LzAyURdXhacAQVPIk0C
# AwEAAaOCAeYwggHiMBAGCSsGAQQBgjcVAQQDAgEAMB0GA1UdDgQWBBTVYzpcijGQ
# 80N7fEYbxTNoWoVtVTAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8E
# BAMCAYYwDwYDVR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBTV9lbLj+iiXGJo0T2U
# kFvXzpoYxDBWBgNVHR8ETzBNMEugSaBHhkVodHRwOi8vY3JsLm1pY3Jvc29mdC5j
# b20vcGtpL2NybC9wcm9kdWN0cy9NaWNSb29DZXJBdXRfMjAxMC0wNi0yMy5jcmww
# WgYIKwYBBQUHAQEETjBMMEoGCCsGAQUFBzAChj5odHRwOi8vd3d3Lm1pY3Jvc29m
# dC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dF8yMDEwLTA2LTIzLmNydDCBoAYD
# VR0gAQH/BIGVMIGSMIGPBgkrBgEEAYI3LgMwgYEwPQYIKwYBBQUHAgEWMWh0dHA6
# Ly93d3cubWljcm9zb2Z0LmNvbS9QS0kvZG9jcy9DUFMvZGVmYXVsdC5odG0wQAYI
# KwYBBQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AUABvAGwAaQBjAHkAXwBTAHQAYQB0
# AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAAfmiFEN4sbgmD+BcQM9
# naOhIW+z66bM9TG+zwXiqf76V20ZMLPCxWbJat/15/B4vceoniXj+bzta1RXCCtR
# gkQS+7lTjMz0YBKKdsxAQEGb3FwX/1z5Xhc1mCRWS3TvQhDIr79/xn/yN31aPxzy
# mXlKkVIArzgPF/UveYFl2am1a+THzvbKegBvSzBEJCI8z+0DpZaPWSm8tv0E4XCf
# Mkon/VWvL/625Y4zu2JfmttXQOnxzplmkIz/amJ/3cVKC5Em4jnsGUpxY517IW3D
# nKOiPPp/fZZqkHimbdLhnPkd/DjYlPTGpQqWhqS9nhquBEKDuLWAmyI4ILUl5WTs
# 9/S/fmNZJQ96LjlXdqJxqgaKD4kWumGnEcua2A5HmoDF0M2n0O99g/DhO3EJ3110
# mCIIYdqwUB5vvfHhAN/nMQekkzr3ZUd46PioSKv33nJ+YWtvd6mBy6cJrDm77MbL
# 2IK0cs0d9LiFAR6A+xuJKlQ5slvayA1VmXqHczsI5pgt6o3gMy4SKfXAL1QnIffI
# rE7aKLixqduWsqdCosnPGUFN4Ib5KpqjEWYw07t0MkvfY3v1mYovG8chr1m1rtxE
# PJdQcdeh0sVV42neV8HR3jDA/czmTfsNv11P6Z0eGTgvvM9YBS7vDaBQNdrvCScc
# 1bN+NR4Iuto229Nfj950iEkSoYIDrTCCApUCAQEwgf6hgdSkgdEwgc4xCzAJBgNV
# BAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4w
# HAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKTAnBgNVBAsTIE1pY3Jvc29m
# dCBPcGVyYXRpb25zIFB1ZXJ0byBSaWNvMSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVT
# TjpCMUI3LUY2N0YtRkVDMjElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAg
# U2VydmljZaIlCgEBMAkGBSsOAwIaBQADFQBrXDo2eDr68GRJRlXYVs3aqGzas6CB
# 3jCB26SB2DCB1TELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAO
# BgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEp
# MCcGA1UECxMgTWljcm9zb2Z0IE9wZXJhdGlvbnMgUHVlcnRvIFJpY28xJzAlBgNV
# BAsTHm5DaXBoZXIgTlRTIEVTTjo0REU5LTBDNUUtM0UwOTErMCkGA1UEAxMiTWlj
# cm9zb2Z0IFRpbWUgU291cmNlIE1hc3RlciBDbG9jazANBgkqhkiG9w0BAQUFAAIF
# AOGPwLEwIhgPMjAxOTEyMDMwMDU2MTdaGA8yMDE5MTIwNDAwNTYxN1owdDA6Bgor
# BgEEAYRZCgQBMSwwKjAKAgUA4Y/AsQIBADAHAgEAAgILvjAHAgEAAgIXiDAKAgUA
# 4ZESMQIBADA2BgorBgEEAYRZCgQCMSgwJjAMBgorBgEEAYRZCgMBoAowCAIBAAID
# FuNgoQowCAIBAAIDB6EgMA0GCSqGSIb3DQEBBQUAA4IBAQB09Ks+oNkYOuE+ElOh
# z5swr/mHZpLUPbGM8farJwCGiZ/CNSV2iUSHjkK8iqDlV20tVMXqq5u44ONgvNth
# 7MG9gvvsevWyfVvrr9HkuCWkahAOPmmpgaMs6Wnm0udV/azRnW7oBRoV8uHZKEW7
# Kt0gvaVbMotbQh0YxhfIpGZlATIACtXm2X/S2eZwMCPy7IjIcDDP9jGzsEH9enDS
# joPMB8s+kymSeXSkdr2yZutoi1UHCRPfhZf5KsAa7c2EIOXyyWZNbrp0DftI+Shs
# EZH1f9/6ITR03MG2EU/VBWqmR+2pLTJX42RAojlyQeBKLWt82PWmjqxtX6nuWXZr
# sN52MYIC9TCCAvECAQEwgZMwfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hp
# bmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jw
# b3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAC
# EzMAAAED6k4reLYqJ5MAAAAAAQMwDQYJYIZIAWUDBAIBBQCgggEyMBoGCSqGSIb3
# DQEJAzENBgsqhkiG9w0BCRABBDAvBgkqhkiG9w0BCQQxIgQgDU+OsxI1eXqnqgEf
# ZgLyp+nAc0zez8lrUhnxZJxSTzAwgeIGCyqGSIb3DQEJEAIMMYHSMIHPMIHMMIGx
# BBRrXDo2eDr68GRJRlXYVs3aqGzaszCBmDCBgKR+MHwxCzAJBgNVBAYTAlVTMRMw
# EQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVN
# aWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0
# YW1wIFBDQSAyMDEwAhMzAAABA+pOK3i2KieTAAAAAAEDMBYEFC8O2BxunzwjaiWF
# X47t/8merNACMA0GCSqGSIb3DQEBCwUABIIBABTNqSX8fDhjL3Altw/SXR5vE0yJ
# OvTYyXoL657iV2uMlA7IkaluAUx1Q7IVTU0FwwjdbhOlYUCnkccsLx0zDvrfFxSc
# FnCQcJGly69F8M8rJXZZu4jUFSJBGzgrnRox3wwnwLJVy++u07a0xEqaoY6bAaVG
# WVJpHdq7ZGnO1BxFAdmLDnBkAyzpAVCjakyaX4cihJg917V40jj6cRs5oeExQ+r+
# z467JfdCOpEk/84YyvfWINRwoGcguzhZSsZLsxdvU/1EPC6gg0SFpSOUvkbo+jNP
# U6PyQ4TaXQt97OjrCUDNQ/VhCv1tjKu+ZBOSKU8MeB/BnwGjmXGVOKufhS8=
# SIG # End signature block
