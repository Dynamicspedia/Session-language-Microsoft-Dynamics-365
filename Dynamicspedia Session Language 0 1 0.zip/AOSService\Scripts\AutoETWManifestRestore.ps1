﻿<#
.SYNOPSIS
    Restore the ETW manifest files in the instrumentation folder from a backup.

.DESCRIPTION
    The script will stop the Monitoring Agent, unregister the existing ETW manifest files in the
    instrumentation folder, restore the ETW manifests from a previous backup, and run the
    MonitoringInstall scheduled task to register the updated ETW manifests and start the Monitoring
    Agent. MonitoringInstall-Servicing.psm1 must exist in the script folder.

    Exit codes:
       0: Success.
       2: Monitoring PowerShell module could not be initialized.
       4: Monitoring Agent could not be stopped.
       8: Monitoring Agent could not be started.
      16: One or more manifest files could not be removed.
      32: One or more manifest files could not be restored.
    1024: Unknown error.

    Copyright © 2019 Microsoft. All rights reserved.
#>
[CmdletBinding()]
Param(
    [Parameter(Mandatory = $false, HelpMessage = "The maximum number of seconds to wait for the stop tasks to complete.")]
    [int]$StopTaskMaxWaitSec = 300,
    [Parameter(Mandatory = $false, HelpMessage = "The maximum number of seconds to wait for the start task to complete. Set to 0 to not wait.")]
    [int]$StartTaskMaxWaitSec = 300,
    [Parameter(Mandatory = $false, HelpMessage = "The path to the log directory in which output should be written.")]
    [string]$LogDir
)

# Initialize exit code.
[int]$ExitCode = 0

# Initialize Monitoring module and logging.
[string]$LogPath = $null
try
{
    if ($LogDir)
    {
        # Add log file name.
        $LogPath = Join-Path -Path $LogDir -ChildPath "Monitoring-EtwRestore_$([DateTime]::UtcNow.ToString("yyyyMMddHHmmss")).log"

        if ([System.IO.Path]::IsPathRooted($LogPath))
        {
            # Ensure that the directory exists.
            $LogParentPath = Split-Path -Path $LogPath -Parent
            if (!(Test-Path -Path $LogParentPath -ErrorAction SilentlyContinue))
            {
                New-Item -Path $LogParentPath -ItemType "Directory" | Out-Null
            }
        }
        else
        {
            # Resolve relative path under current directory.
            $LogPath = Join-Path -Path $PSScriptRoot -ChildPath $LogPath
        }
    }

    $MonitoringModulePath = Join-Path -Path $PSScriptRoot -ChildPath "MonitoringInstall-Servicing.psm1"
    if (!(Test-Path -Path $MonitoringModulePath -ErrorAction SilentlyContinue))
    {
        throw "Monitoring servicing module not found at: $($MonitoringModulePath)"
    }

    # Import Monitoring module.
    Import-Module -Name $MonitoringModulePath

    # For Monitoring Write-Message - Set log file path.
    Set-WriteMessageLogFilePath -Path $LogPath
}
catch
{
    $ExitCode = 2
    $ErrorMessage = "Error initializing Monitoring PowerShell module from '$($MonitoringModulePath)': $($_)"

    # Use Write-Output since Write-Message is defined in module that could not be loaded.
    Write-Output "$([DateTime]::UtcNow.ToString("yyyy-MM-dd HH:mm:ss")): $($ErrorMessage)"
    Write-Output "$($_.ScriptStackTrace)"
    Write-Output "$($_.Exception)"

    # If a log path was defined, also write error message to it.
    if ($LogPath)
    {
        "$([DateTime]::UtcNow.ToString("yyyy-MM-dd HH:mm:ss")): $($ErrorMessage)" | Out-File -FilePath $LogPath -Append
        "$($_.ScriptStackTrace)" | Out-File -FilePath $LogPath -Append
        "$($_.Exception)" | Out-File -FilePath $LogPath -Append
        "ETW restore script failed with exit code: $($ExitCode)." | Out-File -FilePath $LogPath -Append
    }

    # Use throw to indicate error to AXUpdateInstaller.
    # In case of exceptions, the output is not captured, so only the error message and
    # log file contents will be available for diagnostics.
    throw "$($ErrorMessage) [Log: $($LogPath)]"
}

try
{
    Write-Message "Script to restore Monitoring ETW manifest files starting..."
    Write-Message "Command: $(@([Environment]::GetCommandLineArgs()) -join " ")" -Vrb

    # Set backup path. If the RunbookBackupFolder variable is not set, use ManualETWManifestBackup folder.
    $BackupFolder = $RunbookBackupFolder
    if (!$BackupFolder)
    {
        $BackupFolder = Join-Path -Path $PSScriptRoot -ChildPath "ManualETWManifestBackup"
    }

    Write-Message "ETW manifest backup path: $($BackupFolder)"

    # Check if there are any files to restore.
    [bool]$RestoreApplicable = $true
    if (Test-Path -Path $BackupFolder -ErrorAction SilentlyContinue)
    {
        $BackupFiles = @(Get-ChildItem -Path $BackupFolder -File)
        if ($BackupFiles.Count -eq 0)
        {
            $RestoreApplicable = $false
            Write-Message "ETW manifest backup path does not contain any files. Skipping ETW manifest restore step."
        }
    }
    else
    {
        $RestoreApplicable = $false
        Write-Message "ETW manifest backup path does not exist. Skipping ETW manifest update step."
    }

    # If applicable, unregister ETW events, stop agent, restore manifest files, register ETW events, and start agent.
    if ($RestoreApplicable)
    {
        # Stop the Monitoring Agent ETW sessions and agent processes.
        try
        {
            Write-Message "Stopping Monitoring Agent..."
            Stop-MonitoringAgent -MaxWaitSec $StopTaskMaxWaitSec -LogPath $LogDir -SkipIfNotInstalled
        }
        catch
        {
            # Set exit code to indicate Monitoring Agent could not be stopped.
            $ExitCode = 4

            # Throw to terminate script.
            throw
        }

        $ErrorMessages = @()

        # Restarting the EventLog service can prevent some locked file issues.
        Write-Message "Restarting EventLog service..." -Vrb
        try
        {
            Restart-Service -Name "EventLog" -Force
        }
        catch
        {
            Write-Message "Warning: Failed to restart EventLog service: $($_)" -Vrb
        }

        # Get Monitoring manifest path.
        $MonManifestPath = Get-MonitoringManifestPath
        if (!$MonManifestPath)
        {
            $MonManifestPath = Get-MonitoringManifestPathDefault
            Write-Message "Warning: No Monitoring Manifest path found in registry. Using default: $($MonManifestPath)" -Vrb
        }

        Write-Message "Monitoring manifest path: $($MonManifestPath)"

        if (!(Test-Path -Path $MonManifestPath -ErrorAction SilentlyContinue))
        {
            Write-Message "Monitoring manifest path was not found. Creating new directory: $($MonManifestPath)" -Vrb
            New-Item -ItemType Directory -Path $MonManifestPath | Out-Null
        }

        # Remove files from Monitoring manifest folder.
        $RemoveFiles = @(Get-ChildItem -Path $MonManifestPath -File)
        $RemoveErrors = @()
        Write-Message "Removing $($RemoveFiles.Count) files from Monitoring manifest folder..."
        foreach ($File in $RemoveFiles)
        {
            Write-Message "- [Removing] $($File.Name)" -Vrb

            [int]$Attempt = 1
            [int]$MaxAttempts = 3
            while ($Attempt -le $MaxAttempts)
            {
                try
                {
                    Remove-Item -Path $($File.FullName) -Force
                }
                catch
                {
                    if ($Attempt -lt $MaxAttempts)
                    {
                        Write-Message "- [Warning - $($Attempt)]: Failed to remove $($File.Name): $($_.Exception.Message)." -Vrb
                        Start-Sleep -Second 1
                    }
                    else
                    {
                        Write-Message "- [Error]: Failed all attempts to remove $($File.FullName): $($_.Exception.Message)." -Vrb
                        $RemoveErrors += $File
                    }
                }

                $Attempt++
            }
        }

        if ($RemoveErrors.Count -gt 0)
        {
            Write-Message "Error: Failed to remove $($RemoveErrors.Count) files from Monitoring manifest folder."
            $ErrorMessages += "Failed to remove $($RemoveErrors.Count) files from Monitoring manifest folder."
            $ExitCode = $ExitCode -bor 16
        }
        else
        {
            Write-Message "Manifest files were all removed from: $($MonManifestPath)"
        }

        # Restore Monitoring manifest folder from backup (no subfolders).
        $RestoreFiles = @(Get-ChildItem -Path $BackupFolder -File)
        $RestoreErrors = @()
        Write-Message "Restoring $($RestoreFiles.Count) files to Monitoring manifest folder..."
        foreach ($File in $RestoreFiles)
        {
            $DestinationFilePath = Join-Path -Path $MonManifestPath -ChildPath $($File.Name)
            Write-Message "- [Restoring] $($File.Name)" -Vrb

            [int]$Attempt = 1
            [int]$MaxAttempts = 3
            while ($Attempt -le $MaxAttempts)
            {
                try
                {
                    Copy-Item -Path $($File.FullName) -Destination $DestinationFilePath -Force
                }
                catch
                {
                    if ($Attempt -lt $MaxAttempts)
                    {
                        Write-Message "- [Warning - $($Attempt)]: Failed to restore $($File.Name): $($_.Exception.Message)." -Vrb
                        Start-Sleep -Second 1
                    }
                    else
                    {
                        Write-Message "- [Error]: Failed all attempts to restore $($File.FullName): $($_.Exception.Message)." -Vrb
                        $RestoreErrors += $File
                    }
                }

                $Attempt++
            }
        }

        if ($RestoreErrors.Count -gt 0)
        {
            Write-Message "Error: Failed to restore $($RestoreErrors.Count) files to Monitoring manifest folder."
            $ErrorMessages += "Failed to restore $($RestoreErrors.Count) files to Monitoring manifest folder."
            $ExitCode = $ExitCode -bor 32
        }
        else
        {
            Write-Message "Manifest files were all restored to: $($MonManifestPath)"
        }

        # Start the MonitoringInstall task.
        try
        {
            Write-Message "Starting Monitoring Agent..."
            Start-MonitoringAgent -MaxWaitSec $StartTaskMaxWaitSec -SkipIfNotInstalled
        }
        catch
        {
            Write-Message "Error: Failed to start Monitoring Agent: $($_)"
            $ErrorMessages += "Failed to start Monitoring Agent: $($_)"

            # Set exit code to indicate Monitoring Agent could not be started.
            $ExitCode = $ExitCode -bor 8
        }

        # Throw exception with error messages.
        if ($ErrorMessages.Count -gt 0)
        {
            $ErrorMessage = [string]::Join("; ", $ErrorMessages)
            throw $ErrorMessage
        }
    }
}
catch
{
    # Ensure non-zero exit code if an exception is caught and no exit code set.
    if ($ExitCode -eq 0)
    {
        $ExitCode = 1024
    }

    $ErrorMessage = "Error during ETW restore: $($_)"

    Write-Message $ErrorMessage
    Write-Message "$($_.ScriptStackTrace)" -Vrb
    Write-Message "$($_.Exception)" -Vrb
    Write-Message "ETW restore script failed with exit code: $($ExitCode)."

    # Use throw to indicate error to AXUpdateInstaller.
    # In case of exceptions, the output is not captured, so only the error message and
    # log file contents will be available for diagnostics.
    throw "$($ErrorMessage) [Log: $($LogPath)]"
}

Write-Message "ETW restore script completed with exit code: $($ExitCode)."
exit $ExitCode
# SIG # Begin signature block
# MIIjtgYJKoZIhvcNAQcCoIIjpzCCI6MCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCAHz+5SSboXAEZV
# zSTaIoAePy/zGqPVCH4TlJOInRDgVqCCDYUwggYDMIID66ADAgECAhMzAAABUptA
# n1BWmXWIAAAAAAFSMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMTkwNTAyMjEzNzQ2WhcNMjAwNTAyMjEzNzQ2WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQCxp4nT9qfu9O10iJyewYXHlN+WEh79Noor9nhM6enUNbCbhX9vS+8c/3eIVazS
# YnVBTqLzW7xWN1bCcItDbsEzKEE2BswSun7J9xCaLwcGHKFr+qWUlz7hh9RcmjYS
# kOGNybOfrgj3sm0DStoK8ljwEyUVeRfMHx9E/7Ca/OEq2cXBT3L0fVnlEkfal310
# EFCLDo2BrE35NGRjG+/nnZiqKqEh5lWNk33JV8/I0fIcUKrLEmUGrv0CgC7w2cjm
# bBhBIJ+0KzSnSWingXol/3iUdBBy4QQNH767kYGunJeY08RjHMIgjJCdAoEM+2mX
# v1phaV7j+M3dNzZ/cdsz3oDfAgMBAAGjggGCMIIBfjAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQU3f8Aw1sW72WcJ2bo/QSYGzVrRYcw
# VAYDVR0RBE0wS6RJMEcxLTArBgNVBAsTJE1pY3Jvc29mdCBJcmVsYW5kIE9wZXJh
# dGlvbnMgTGltaXRlZDEWMBQGA1UEBRMNMjMwMDEyKzQ1NDEzNjAfBgNVHSMEGDAW
# gBRIbmTlUAXTgqoXNzcitW2oynUClTBUBgNVHR8ETTBLMEmgR6BFhkNodHRwOi8v
# d3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NybC9NaWNDb2RTaWdQQ0EyMDExXzIw
# MTEtMDctMDguY3JsMGEGCCsGAQUFBwEBBFUwUzBRBggrBgEFBQcwAoZFaHR0cDov
# L3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9jZXJ0cy9NaWNDb2RTaWdQQ0EyMDEx
# XzIwMTEtMDctMDguY3J0MAwGA1UdEwEB/wQCMAAwDQYJKoZIhvcNAQELBQADggIB
# AJTwROaHvogXgixWjyjvLfiRgqI2QK8GoG23eqAgNjX7V/WdUWBbs0aIC3k49cd0
# zdq+JJImixcX6UOTpz2LZPFSh23l0/Mo35wG7JXUxgO0U+5drbQht5xoMl1n7/TQ
# 4iKcmAYSAPxTq5lFnoV2+fAeljVA7O43szjs7LR09D0wFHwzZco/iE8Hlakl23ZT
# 7FnB5AfU2hwfv87y3q3a5qFiugSykILpK0/vqnlEVB0KAdQVzYULQ/U4eFEjnis3
# Js9UrAvtIhIs26445Rj3UP6U4GgOjgQonlRA+mDlsh78wFSGbASIvK+fkONUhvj8
# B8ZHNn4TFfnct+a0ZueY4f6aRPxr8beNSUKn7QW/FQmn422bE7KfnqWncsH7vbNh
# G929prVHPsaa7J22i9wyHj7m0oATXJ+YjfyoEAtd5/NyIYaE4Uu0j1EhuYUo5VaJ
# JnMaTER0qX8+/YZRWrFN/heps41XNVjiAawpbAa0fUa3R9RNBjPiBnM0gvNPorM4
# dsV2VJ8GluIQOrJlOvuCrOYDGirGnadOmQ21wPBoGFCWpK56PxzliKsy5NNmAXcE
# x7Qb9vUjY1WlYtrdwOXTpxN4slzIht69BaZlLIjLVWwqIfuNrhHKNDM9K+v7vgrI
# bf7l5/665g0gjQCDCN6Q5sxuttTAEKtJeS/pkpI+DbZ/MIIHejCCBWKgAwIBAgIK
# YQ6Q0gAAAAAAAzANBgkqhkiG9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNV
# BAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jv
# c29mdCBDb3Jwb3JhdGlvbjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlm
# aWNhdGUgQXV0aG9yaXR5IDIwMTEwHhcNMTEwNzA4MjA1OTA5WhcNMjYwNzA4MjEw
# OTA5WjB+MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UE
# BxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSgwJgYD
# VQQDEx9NaWNyb3NvZnQgQ29kZSBTaWduaW5nIFBDQSAyMDExMIICIjANBgkqhkiG
# 9w0BAQEFAAOCAg8AMIICCgKCAgEAq/D6chAcLq3YbqqCEE00uvK2WCGfQhsqa+la
# UKq4BjgaBEm6f8MMHt03a8YS2AvwOMKZBrDIOdUBFDFC04kNeWSHfpRgJGyvnkmc
# 6Whe0t+bU7IKLMOv2akrrnoJr9eWWcpgGgXpZnboMlImEi/nqwhQz7NEt13YxC4D
# dato88tt8zpcoRb0RrrgOGSsbmQ1eKagYw8t00CT+OPeBw3VXHmlSSnnDb6gE3e+
# lD3v++MrWhAfTVYoonpy4BI6t0le2O3tQ5GD2Xuye4Yb2T6xjF3oiU+EGvKhL1nk
# kDstrjNYxbc+/jLTswM9sbKvkjh+0p2ALPVOVpEhNSXDOW5kf1O6nA+tGSOEy/S6
# A4aN91/w0FK/jJSHvMAhdCVfGCi2zCcoOCWYOUo2z3yxkq4cI6epZuxhH2rhKEmd
# X4jiJV3TIUs+UsS1Vz8kA/DRelsv1SPjcF0PUUZ3s/gA4bysAoJf28AVs70b1FVL
# 5zmhD+kjSbwYuER8ReTBw3J64HLnJN+/RpnF78IcV9uDjexNSTCnq47f7Fufr/zd
# sGbiwZeBe+3W7UvnSSmnEyimp31ngOaKYnhfsi+E11ecXL93KCjx7W3DKI8sj0A3
# T8HhhUSJxAlMxdSlQy90lfdu+HggWCwTXWCVmj5PM4TasIgX3p5O9JawvEagbJjS
# 4NaIjAsCAwEAAaOCAe0wggHpMBAGCSsGAQQBgjcVAQQDAgEAMB0GA1UdDgQWBBRI
# bmTlUAXTgqoXNzcitW2oynUClTAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTAL
# BgNVHQ8EBAMCAYYwDwYDVR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBRyLToCMZBD
# uRQFTuHqp8cx0SOJNDBaBgNVHR8EUzBRME+gTaBLhklodHRwOi8vY3JsLm1pY3Jv
# c29mdC5jb20vcGtpL2NybC9wcm9kdWN0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFf
# MDNfMjIuY3JsMF4GCCsGAQUFBwEBBFIwUDBOBggrBgEFBQcwAoZCaHR0cDovL3d3
# dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFf
# MDNfMjIuY3J0MIGfBgNVHSAEgZcwgZQwgZEGCSsGAQQBgjcuAzCBgzA/BggrBgEF
# BQcCARYzaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9kb2NzL3ByaW1h
# cnljcHMuaHRtMEAGCCsGAQUFBwICMDQeMiAdAEwAZQBnAGEAbABfAHAAbwBsAGkA
# YwB5AF8AcwB0AGEAdABlAG0AZQBuAHQALiAdMA0GCSqGSIb3DQEBCwUAA4ICAQBn
# 8oalmOBUeRou09h0ZyKbC5YR4WOSmUKWfdJ5DJDBZV8uLD74w3LRbYP+vj/oCso7
# v0epo/Np22O/IjWll11lhJB9i0ZQVdgMknzSGksc8zxCi1LQsP1r4z4HLimb5j0b
# pdS1HXeUOeLpZMlEPXh6I/MTfaaQdION9MsmAkYqwooQu6SpBQyb7Wj6aC6VoCo/
# KmtYSWMfCWluWpiW5IP0wI/zRive/DvQvTXvbiWu5a8n7dDd8w6vmSiXmE0OPQvy
# CInWH8MyGOLwxS3OW560STkKxgrCxq2u5bLZ2xWIUUVYODJxJxp/sfQn+N4sOiBp
# mLJZiWhub6e3dMNABQamASooPoI/E01mC8CzTfXhj38cbxV9Rad25UAqZaPDXVJi
# hsMdYzaXht/a8/jyFqGaJ+HNpZfQ7l1jQeNbB5yHPgZ3BtEGsXUfFL5hYbXw3MYb
# BL7fQccOKO7eZS/sl/ahXJbYANahRr1Z85elCUtIEJmAH9AAKcWxm6U/RXceNcbS
# oqKfenoi+kiVH6v7RyOA9Z74v2u3S5fi63V4GuzqN5l5GEv/1rMjaHXmr/r8i+sL
# gOppO6/8MO0ETI7f33VtY5E90Z1WTk+/gFcioXgRMiF670EKsT/7qMykXcGhiJtX
# cVZOSEXAQsmbdlsKgEhr/Xmfwb1tbWrJUnMTDXpQzTGCFYcwghWDAgEBMIGVMH4x
# CzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRt
# b25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01p
# Y3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTECEzMAAAFSm0CfUFaZdYgAAAAA
# AVIwDQYJYIZIAWUDBAIBBQCggdowGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQw
# HAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEILVO
# OlplbcaP3AeV0zYfdpYrjdtyE9FmRycuOev3nvDUMG4GCisGAQQBgjcCAQwxYDBe
# oECAPgBBAHUAdABvAFUAcABnAHIAYQBkAGUAQwBvAG4AZgBpAGcAQQBvAHMAUwBl
# AHIAdgBpAGMAZQAuAHAAcwAxoRqAGGh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbTAN
# BgkqhkiG9w0BAQEFAASCAQAjPVjaPbM5p93+Fy+HsIosUmK3v6Ud1nCEjKY392OF
# LaVX6x3GaqoXrErGT5J7bxqspx1dQ45MoVbofOeRa+nBcEeGxrm/VMyNscy3cEv1
# fgB7SiqtujBR4o+qWjQCDIZ5KLTn39EV5N8mdXQHMKrXZy+1YRZLMGUMAfMjRnSd
# oC0TtzqPEI0MH5BOTx9LA1szHO+8WWwrD08Z4KCWw2ayOf54EJfOaPWuPDbWUUCT
# 1sCx4qCshGYX9a2TysghJGDGBq7krFcHbF1UMPaDav3Benp++ZoHh3bMSBaOohlM
# CWYnhEJqOT7B2D0DCHSXsMYuJ5bUPndonVBnyRCtNANRoYIS5TCCEuEGCisGAQQB
# gjcDAwExghLRMIISzQYJKoZIhvcNAQcCoIISvjCCEroCAQMxDzANBglghkgBZQME
# AgEFADCCAVEGCyqGSIb3DQEJEAEEoIIBQASCATwwggE4AgEBBgorBgEEAYRZCgMB
# MDEwDQYJYIZIAWUDBAIBBQAEIBQYIfwGxGrggbK75x16rUhVG8OCRBCDzsgQOe2G
# Nt73AgZdqcm5mqQYEzIwMTkxMjAzMDMyMzQ3LjQwMVowBIACAfSggdCkgc0wgcox
# CzAJBgNVBAYTAlVTMQswCQYDVQQIEwJXQTEQMA4GA1UEBxMHUmVkbW9uZDEeMBwG
# A1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMS0wKwYDVQQLEyRNaWNyb3NvZnQg
# SXJlbGFuZCBPcGVyYXRpb25zIExpbWl0ZWQxJjAkBgNVBAsTHVRoYWxlcyBUU1Mg
# RVNOOkUwNDEtNEJFRS1GQTdFMSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFt
# cCBzZXJ2aWNloIIOPDCCBPEwggPZoAMCAQICEzMAAAEHfjdomIdaN9YAAAAAAQcw
# DQYJKoZIhvcNAQELBQAwfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0
# b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3Jh
# dGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwHhcN
# MTkxMDA4MTczODM1WhcNMjEwMTAzMTczODM1WjCByjELMAkGA1UEBhMCVVMxCzAJ
# BgNVBAgTAldBMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQg
# Q29ycG9yYXRpb24xLTArBgNVBAsTJE1pY3Jvc29mdCBJcmVsYW5kIE9wZXJhdGlv
# bnMgTGltaXRlZDEmMCQGA1UECxMdVGhhbGVzIFRTUyBFU046RTA0MS00QkVFLUZB
# N0UxJTAjBgNVBAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIHNlcnZpY2UwggEiMA0G
# CSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQDUuqOUlbaeWirgwbCwhhNIOqTshpo+
# QdSYxAt9JnkeulQFeKrQ6rOSECXxwgOjL/TNMIXtkig1MaifFON6si/Ri+AsV8Gu
# rQp4fylJzLDMFdJcGSpV3CGRdpDb0au8kNQLmnZuxLxAL91R7//3mH2QDQI20w3G
# 06s+Xv8+js9wQksXAfclXX1TJoBIx1Pi1FGqCnY3KlW81+Plhz0T4yStm1MgnqH4
# RKYyPdcempCYC/BI04Ph2EJL+uQQfAfYdbf9vGqpKYjsuktnWr5uowD3H5At+x3l
# YH5rz4JCleKjeLpB/j74H7VZ0I5eTEbls9e2lEKaUzb9o0wjnjDc+t4BAgMBAAGj
# ggEbMIIBFzAdBgNVHQ4EFgQUNOHjlxlIJXMcP9n/0ogYdX8p6HcwHwYDVR0jBBgw
# FoAU1WM6XIoxkPNDe3xGG8UzaFqFbVUwVgYDVR0fBE8wTTBLoEmgR4ZFaHR0cDov
# L2NybC5taWNyb3NvZnQuY29tL3BraS9jcmwvcHJvZHVjdHMvTWljVGltU3RhUENB
# XzIwMTAtMDctMDEuY3JsMFoGCCsGAQUFBwEBBE4wTDBKBggrBgEFBQcwAoY+aHR0
# cDovL3d3dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0cy9NaWNUaW1TdGFQQ0FfMjAx
# MC0wNy0wMS5jcnQwDAYDVR0TAQH/BAIwADATBgNVHSUEDDAKBggrBgEFBQcDCDAN
# BgkqhkiG9w0BAQsFAAOCAQEAGN3/7XWSzHGKjk444w+2q1D3k7Bh/ZahUvWHFJ6E
# UKU5vLzEGsdsgJSvWXHZDRrpf5rcUGQyjnlo1hAY1mDteNKFushS6bedxcxPHJje
# lVZ9N2/e5+/7zLu18YjnKw5bFu7dWqYBMI3J0FOr56XJOJ1KTtMiJhpxuib+FWy+
# pyhVVgHGTUHuUdbE09dY9WxuRsbpb4DdWAWNrPDB6VAOO50QfEj+0tW+zF6h3RhB
# TI0ilj0+AzgXE+6DyJ7/br6aVvCEvNRJzE6akJnMyn/kzmC32LxvRZWKEwWDR0Fn
# zeXj5ynSStZ6iifTBP7gqiDsidguxh+BFX7HxhN1eHf7jTCCBnEwggRZoAMCAQIC
# CmEJgSoAAAAAAAIwDQYJKoZIhvcNAQELBQAwgYgxCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xMjAwBgNVBAMTKU1pY3Jvc29mdCBSb290IENlcnRp
# ZmljYXRlIEF1dGhvcml0eSAyMDEwMB4XDTEwMDcwMTIxMzY1NVoXDTI1MDcwMTIx
# NDY1NVowfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNV
# BAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQG
# A1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwggEiMA0GCSqGSIb3
# DQEBAQUAA4IBDwAwggEKAoIBAQCpHQ28dxGKOiDs/BOX9fp/aZRrdFQQ1aUKAIKF
# ++18aEssX8XD5WHCdrc+Zitb8BVTJwQxH0EbGpUdzgkTjnxhMFmxMEQP8WCIhFRD
# DNdNuDgIs0Ldk6zWczBXJoKjRQ3Q6vVHgc2/JGAyWGBG8lhHhjKEHnRhZ5FfgVSx
# z5NMksHEpl3RYRNuKMYa+YaAu99h/EbBJx0kZxJyGiGKr0tkiVBisV39dx898Fd1
# rL2KQk1AUdEPnAY+Z3/1ZsADlkR+79BL/W7lmsqxqPJ6Kgox8NpOBpG2iAg16Hgc
# sOmZzTznL0S6p/TcZL2kAcEgCZN4zfy8wMlEXV4WnAEFTyJNAgMBAAGjggHmMIIB
# 4jAQBgkrBgEEAYI3FQEEAwIBADAdBgNVHQ4EFgQU1WM6XIoxkPNDe3xGG8UzaFqF
# bVUwGQYJKwYBBAGCNxQCBAweCgBTAHUAYgBDAEEwCwYDVR0PBAQDAgGGMA8GA1Ud
# EwEB/wQFMAMBAf8wHwYDVR0jBBgwFoAU1fZWy4/oolxiaNE9lJBb186aGMQwVgYD
# VR0fBE8wTTBLoEmgR4ZFaHR0cDovL2NybC5taWNyb3NvZnQuY29tL3BraS9jcmwv
# cHJvZHVjdHMvTWljUm9vQ2VyQXV0XzIwMTAtMDYtMjMuY3JsMFoGCCsGAQUFBwEB
# BE4wTDBKBggrBgEFBQcwAoY+aHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraS9j
# ZXJ0cy9NaWNSb29DZXJBdXRfMjAxMC0wNi0yMy5jcnQwgaAGA1UdIAEB/wSBlTCB
# kjCBjwYJKwYBBAGCNy4DMIGBMD0GCCsGAQUFBwIBFjFodHRwOi8vd3d3Lm1pY3Jv
# c29mdC5jb20vUEtJL2RvY3MvQ1BTL2RlZmF1bHQuaHRtMEAGCCsGAQUFBwICMDQe
# MiAdAEwAZQBnAGEAbABfAFAAbwBsAGkAYwB5AF8AUwB0AGEAdABlAG0AZQBuAHQA
# LiAdMA0GCSqGSIb3DQEBCwUAA4ICAQAH5ohRDeLG4Jg/gXEDPZ2joSFvs+umzPUx
# vs8F4qn++ldtGTCzwsVmyWrf9efweL3HqJ4l4/m87WtUVwgrUYJEEvu5U4zM9GAS
# inbMQEBBm9xcF/9c+V4XNZgkVkt070IQyK+/f8Z/8jd9Wj8c8pl5SpFSAK84Dxf1
# L3mBZdmptWvkx872ynoAb0swRCQiPM/tA6WWj1kpvLb9BOFwnzJKJ/1Vry/+tuWO
# M7tiX5rbV0Dp8c6ZZpCM/2pif93FSguRJuI57BlKcWOdeyFtw5yjojz6f32WapB4
# pm3S4Zz5Hfw42JT0xqUKloakvZ4argRCg7i1gJsiOCC1JeVk7Pf0v35jWSUPei45
# V3aicaoGig+JFrphpxHLmtgOR5qAxdDNp9DvfYPw4TtxCd9ddJgiCGHasFAeb73x
# 4QDf5zEHpJM692VHeOj4qEir995yfmFrb3epgcunCaw5u+zGy9iCtHLNHfS4hQEe
# gPsbiSpUObJb2sgNVZl6h3M7COaYLeqN4DMuEin1wC9UJyH3yKxO2ii4sanblrKn
# QqLJzxlBTeCG+SqaoxFmMNO7dDJL32N79ZmKLxvHIa9Zta7cRDyXUHHXodLFVeNp
# 3lfB0d4wwP3M5k37Db9dT+mdHhk4L7zPWAUu7w2gUDXa7wknHNWzfjUeCLraNtvT
# X4/edIhJEqGCAs4wggI3AgEBMIH4oYHQpIHNMIHKMQswCQYDVQQGEwJVUzELMAkG
# A1UECBMCV0ExEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBD
# b3Jwb3JhdGlvbjEtMCsGA1UECxMkTWljcm9zb2Z0IElyZWxhbmQgT3BlcmF0aW9u
# cyBMaW1pdGVkMSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVTTjpFMDQxLTRCRUUtRkE3
# RTElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgc2VydmljZaIjCgEBMAcG
# BSsOAwIaAxUAwwu+tfgG3rC7RZrxuFO2CmZSfPiggYMwgYCkfjB8MQswCQYDVQQG
# EwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwG
# A1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQg
# VGltZS1TdGFtcCBQQ0EgMjAxMDANBgkqhkiG9w0BAQUFAAIFAOGQQ9wwIhgPMjAx
# OTEyMDMxMDE1NTZaGA8yMDE5MTIwNDEwMTU1NlowdzA9BgorBgEEAYRZCgQBMS8w
# LTAKAgUA4ZBD3AIBADAKAgEAAgIebAIB/zAHAgEAAgIRwTAKAgUA4ZGVXAIBADA2
# BgorBgEEAYRZCgQCMSgwJjAMBgorBgEEAYRZCgMCoAowCAIBAAIDB6EgoQowCAIB
# AAIDAYagMA0GCSqGSIb3DQEBBQUAA4GBABeTP88N6AgIrdyM3Zn8bFMcAfFvwR+A
# 5XczLvgYojlkP15YT8XdX3KcqUyfT371BPdzZkDuS97tmdZcZubQXHUAXFLMMywM
# 7txNjYDab8LNqwI+c++tb0a97NbvQHT0q5VYuxITshHltrDjbqZ+O52tVPoZizPs
# QChQDB+PFz+qMYIDDTCCAwkCAQEwgZMwfDELMAkGA1UEBhMCVVMxEzARBgNVBAgT
# Cldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29m
# dCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENB
# IDIwMTACEzMAAAEHfjdomIdaN9YAAAAAAQcwDQYJYIZIAWUDBAIBBQCgggFKMBoG
# CSqGSIb3DQEJAzENBgsqhkiG9w0BCRABBDAvBgkqhkiG9w0BCQQxIgQgJ5nNGkOa
# Qt5iUCwh/1ROXKdedrCzUq0epWakrlUW+gowgfoGCyqGSIb3DQEJEAIvMYHqMIHn
# MIHkMIG9BCBBYvCj4pFkwhumagATn0gLh9fdDNzImQkKNeOtRj/LHjCBmDCBgKR+
# MHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMT
# HU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwAhMzAAABB343aJiHWjfWAAAA
# AAEHMCIEID38qyRQHvnSSjN1KUicyg7BWtnET7TpkwW/PdzAwo9iMA0GCSqGSIb3
# DQEBCwUABIIBAAErNG1apnchzfO1phN/ONzpUfyVCEvfIBcuUxFgQZFnCbRpiB7f
# g/lc4Gvf5MJZpqmpn/pocQ9WPNlKKJeCqxy5lYsSFW7IVgxLLYxm1frvllAK3oRd
# a+2RxMge7ALMJFqBZ7IJQcqNYHQaPIZMe6yplkECUXsQpuhmH+g/s9hIhNarwYIb
# OI0tdnAy1nQyTn0F7Jo1zdSEWtycjWWY/+0iTf4hZ1efuwNNpdNcQtMlb1tWzC6E
# 4WxaDpnwrI5nIcTTPUKsVGHumdrADtA9O9AEChbrF4gqdh2rgo3kbsqtz0YtDBlt
# KWq7urlx298Xyfxb5lEsVWyJvZwoAEo0BD0=
# SIG # End signature block
